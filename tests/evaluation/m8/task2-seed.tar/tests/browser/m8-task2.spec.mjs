// SPDX-License-Identifier: Apache-2.0
import { expect, test } from "@playwright/test";

for (const layout of ["side", "stack"]) {
  test(layout + " adds validated email and saves only the changed row", async ({ page }) => {
    const errors = [];
    const saves = [];
    page.on("pageerror", error => errors.push(error));
    page.on("request", request => {
      if (new URL(request.url()).pathname === "/api/employees/save") {
        saves.push(request.postDataJSON());
      }
    });

    await page.goto("/m4/" + layout + ".html");
    const screen = page.locator('[data-page="employees"]').first();
    await expect(screen.locator("tbody tr")).toHaveCount(3);
    await screen.locator("tbody tr").filter({ hasText: "Ada" })
      .locator("[data-select-row]").click();
    await expect(screen.locator('[data-role="selected"]')).toHaveText("Selected: Ada");

    const detail = screen.locator('[data-role="detail"]');
    const email = detail.locator('[data-field="email"]');
    await expect(email).toHaveCount(1);
    await expect(email).toHaveAttribute("type", "email");
    await expect(email).toHaveAttribute("required", "");
    expect(JSON.parse((await email.getAttribute("data-validate")) ?? "null"))
      .toEqual([["email"], ["companyEmail"]]);
    await expect(email).toHaveValue("ada@example.com");

    const salary = detail.locator('[data-field="salary"]');
    await salary.fill("125000");
    await salary.blur();
    await expect(salary).toHaveValue("125,000");

    const save = screen.locator('[data-action="save"]');
    await email.fill("invalid-address");
    await save.click();
    await expect(email).toHaveAttribute("aria-invalid", "true");
    await expect(screen.locator('[data-role="error"]')).not.toBeEmpty();
    expect(saves).toHaveLength(0);

    await email.fill("ada@outside.test");
    await save.click();
    await expect(email).toHaveAttribute("aria-invalid", "true");
    await expect(screen.locator('[data-role="error"]'))
      .toContainText("Use a company email.");
    expect(saves).toHaveLength(0);

    await email.fill("ada.updated@example.com");
    const request = page.waitForRequest(candidate =>
      new URL(candidate.url()).pathname === "/api/employees/save");
    await save.click();
    const payload = (await request).postDataJSON();
    const fixture = await import("../../examples/vite/m4/employees.json", {
      with: { type: "json" }
    });
    expect(payload).toEqual([{
      status: "update",
      value: { ...fixture.default[0], email: "ada.updated@example.com", salary: 125000 }
    }]);
    expect(saves).toHaveLength(1);
    await expect(screen.locator('[data-role="status"]')).toHaveText("Saved");
    expect(errors).toEqual([]);
  });
}
