import { test, expect } from "@playwright/test";

test("a delayed response cannot update a removed CVC page or its replacement", async ({ page }) => {
  const pageErrors = [];
  page.on("pageerror", error => pageErrors.push(error.message));
  let startedFirst;
  const firstStarted = new Promise(resolve => { startedFirst = resolve; });
  let releaseFirst;
  const firstGate = new Promise(resolve => { releaseFirst = resolve; });

  await page.route("**/m8-task3/profile.json?*", async route => {
    const cycle = Number(new URL(route.request().url()).searchParams.get("cycle"));
    if (cycle === 1) {
      startedFirst();
      await firstGate;
    }
    try {
      await route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({ name: "Profile " + cycle })
      });
    } catch {
      // The correct implementation may abort the pending request before release.
    }
  });

  await page.goto("/m8-task3/index.html");
  const panel = page.locator("[data-panel]");
  const result = page.locator("[data-panel] [data-result]");
  await page.locator("[data-open]").click();
  await firstStarted;
  const removedRoot = await panel.elementHandle();
  expect(removedRoot).not.toBeNull();
  await expect(result).toHaveText("Loading");

  await page.locator("[data-close]").click();
  await expect(panel).toHaveCount(0);
  await page.locator("[data-open]").click();
  await expect(panel).toHaveAttribute("data-cycle", "2");
  await expect(result).toHaveText("Profile 2");

  releaseFirst();
  await page.waitForTimeout(100);
  const oldText = await removedRoot.evaluate(root =>
    root.querySelector("[data-result]")?.textContent
  );
  expect(oldText).toBe("Loading");
  await expect(result).toHaveText("Profile 2");

  const ids = await page.locator("[id]").evaluateAll(elements =>
    elements.map(element => element.id)
  );
  expect(new Set(ids).size).toBe(ids.length);
  expect(pageErrors).toEqual([]);
});

test("repeated CVC close and reopen does not retain document listeners", async ({ page }) => {
  const pageErrors = [];
  page.on("pageerror", error => pageErrors.push(error.message));
  const requests = [];
  await page.route("**/m8-task3/profile.json?*", async route => {
    const cycle = Number(new URL(route.request().url()).searchParams.get("cycle"));
    requests.push(cycle);
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({ name: "Profile " + cycle })
    });
  });

  await page.goto("/m8-task3/index.html");
  const panel = page.locator("[data-panel]");
  const result = page.locator("[data-panel] [data-result]");
  for (let cycle = 1; cycle <= 8; cycle++) {
    await page.locator("[data-open]").click();
    await expect(panel).toHaveAttribute("data-cycle", String(cycle));
    await expect(result).toHaveText("Profile " + cycle);
    if (cycle < 8) {
      await page.locator("[data-close]").click();
      await expect(panel).toHaveCount(0);
    }
  }

  const beforeRefresh = requests.length;
  await page.locator("[data-refresh]").click();
  await expect.poll(() => requests.length).toBeGreaterThan(beforeRefresh);
  await page.waitForTimeout(50);
  expect(requests.length - beforeRefresh).toBe(1);
  await expect(result).toHaveText("Profile 8");

  await page.locator("[data-close]").click();
  await expect(panel).toHaveCount(0);
  const afterClose = requests.length;
  await page.locator("[data-refresh]").click();
  await page.waitForTimeout(50);
  expect(requests.length).toBe(afterClose);
  expect(pageErrors).toEqual([]);
});
