// SPDX-License-Identifier: Apache-2.0
import { createCommunicator } from "@bbalganjjm/natural_js/comm";
import { mountPage } from "@bbalganjjm/natural_js/page";
import type { PageDefinition, PageHandle } from "@bbalganjjm/natural_js/page";

interface Profile { name: string }
interface PageInput { cycle: number }

function find<ElementType extends Element>(root: ParentNode, selector: string): ElementType {
  const element = root.querySelector<ElementType>(selector);
  if (!element) throw new Error("The delayed profile example needs " + selector);
  return element;
}

const host = find<HTMLElement>(document, "[data-host]");
const view = find<HTMLTemplateElement>(document, "template[data-view]");
const comm = createCommunicator();
let cycle = 0;
let current: PageHandle | null = null;

const profile: PageDefinition<PageInput> = {
  view: () => view.content.firstElementChild!.cloneNode(true) as HTMLElement,
  controller({ root, input }) {
    root.dataset.cycle = String(input.cycle);
    const result = find<HTMLOutputElement>(root, "[data-result]");
    async function load(): Promise<void> {
      const data = await comm.request<Profile>({
        url: "/m8-task3/profile.json?cycle=" + input.cycle
      });
      result.textContent = data.name;
    }
    return {
      init() {
        document.addEventListener("m8-task3:refresh", load);
        void load();
      }
    };
  }
};

find<HTMLButtonElement>(document, "[data-open]").addEventListener("click", () => {
  if (current) return;
  current = mountPage(host, profile, { cycle: ++cycle });
  void current.ready.catch(() => {});
});

find<HTMLButtonElement>(document, "[data-close]").addEventListener("click", () => {
  const closing = current;
  current = null;
  if (closing) void closing.dispose();
});

find<HTMLButtonElement>(document, "[data-refresh]").addEventListener("click", () => {
  document.dispatchEvent(new Event("m8-task3:refresh"));
});
