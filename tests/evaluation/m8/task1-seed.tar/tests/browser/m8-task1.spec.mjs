import { expect, test } from "@playwright/test";

for (const layout of ["side", "stack"]) {
  test(`${layout} authored directory supports keyboard search, selection, and nested detail`, async ({ page }) => {
    const errors = [];
    page.on("pageerror", error => errors.push(error));
    await page.goto(`/m8-task1/${layout}.html`);
    const first = page.locator("section[data-screen]").first();
    const list = first.locator("[data-role=list]");
    await expect(list.locator("[data-select-row]")).toHaveCount(3);
    const query = first.getByRole("searchbox", { name: "Search name" });
    await query.fill("li");
    await query.press("Enter");
    await expect(list.locator("[data-select-row]")).toHaveCount(1);
    const lin = list.getByRole("button", { name: "Lin" });
    await lin.focus();
    await lin.press("Enter");
    await expect(lin).toHaveAttribute("aria-pressed", "true");
    await expect(first.locator('[data-role="detail"] [data-field="name"]')).toHaveValue("Lin");
    const team = first.locator('[data-role="detail"] [data-field="profile.team"]');
    await expect(team).toHaveValue("Research");
    await expect(list.locator("select[data-options=a]")).toHaveValue("22");
    await expect(list.locator("select[data-options=a] option")).toHaveCount(2);
    await team.fill("Core");
    await expect(list.locator('li:not([data-empty]) [data-field="profile.team"]')).toHaveText("Core");
    await expect(first.locator("[data-status]")).toContainText("Lin");
    await query.fill("");
    await query.press("Enter");
    await expect(list.locator("[data-select-row]")).toHaveCount(3);

    await page.getByRole("button", { name: "Open another screen" }).click();
    const second = page.locator("section[data-screen]").last();
    await expect(second.locator("[data-role=list] [data-select-row]")).toHaveCount(3);
    const secondQuery = second.getByRole("searchbox", { name: "Search name" });
    await secondQuery.fill("ma");
    await secondQuery.press("Enter");
    await expect(second.locator("[data-role=list] [data-select-row]")).toHaveCount(1);
    await expect(list.locator("[data-select-row]")).toHaveCount(3);
    await second.locator("[data-role=list]").getByRole("button", { name: "May" }).press("Enter");
    await expect(second.locator('[data-role="detail"] [data-field="name"]')).toHaveValue("May");
    await first.getByRole("button", { name: "Close screen" }).click();
    await expect(page.locator("section[data-screen]")).toHaveCount(1);
    await expect(second.locator('[data-role="detail"] [data-field="name"]')).toHaveValue("May");
    const duplicates = await page.locator("[id]").evaluateAll(elements => {
      const ids = elements.map(element => element.id);
      return ids.filter((id, index) => ids.indexOf(id) !== index);
    });
    expect(duplicates).toEqual([]);
    expect(errors).toEqual([]);
  });
}
