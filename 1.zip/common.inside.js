var PT = {
	pages : {
		SPOCMI00101 : undefined,
		SPOCMI00102 : undefined,
		SPOCMI00103 : undefined,
		SPOCMI00201 : undefined
	},
	// Natural-LIVE
	liveInst : null,
	initNEPTLive : function() {
		this.liveInst = N.live("app")
			// 전체
			.subscribe("notify")
			// 쪽지
			.subscribe("/queue/slipOfPaper." + PT.globalVars.userId, function(msg) {
				$(".alarm.update").click();
				N().notify().add("쪽지가 도착 했습니다.<br><br>" + msg.body, function() {
					PT.utils.url.open({
						cmd: "menu",
						mId: "M000102",
						tIdx: 1
					});
				});
			});
	},
	init : function() {
		// Natural-LIVE
		PT.initNEPTLive();

		// Portal 다국어 처리
		N.context.attr("core").locale = {
			"ko" : "ko_KR",
			"en" : "en_US"
		}[PT.globalVars.locale];

		// SaaS 다국어 처리
		if( typeof i18n !== 'undefined' ) {
			i18n.loadResource("cm","/cm/s/i18n","common", PT.globalVars.locale );
		}
		PT.utils.url.init();
		$(window).click(function(e){
			if ( PT.js.popup.view ) {
				PT.js.popup.hide();
			}
		});

		$(window).resize(function(e){
			PT.js.popup.hide();
			PT.events.NotificationCenter.postNotification('WindowResized', e );
		}).scroll(function(e){
			PT.events.NotificationCenter.postNotification('WindowScroll', $(window).scrollLeft(), $(window).scrollTop() );
		}).mousemove(function(e){
			if ( e.which != 1 || !PT.js.dragObject ) return;
			PT.js.dragObject.dragging(e.clientX, e.clientY, e);
			return false;
		}).mouseup(function(e){
			if ( !PT.js.dragObject ) return;
			if ( PT.js.dragObject._isDragging )
			{
				PT.js.dragObject.dragDone(e.clientX,e.clientY, e);
				e.stopPropagation();
				e.stopImmediatePropagation();
			}
			PT.js.dragObject = undefined;
			return false;
		});

//		localStorage.nepRedirect = false;

		$.fn.mouseclick = function(data,callback) {
			var pressDT;
			if ( arguments.length == 1 ) {
				callback = data;
				data = undefined;
			}
			var clickfunc = function(e){
				if ( Date.now() - pressDT  < 500 ) {
					PT.js.dragObject = undefined;
					e.data = data;
					return callback(e) || false;
				}
			};
			$(this).mousedown( function(e){
				if ( e.which == 1 ) {
					pressDT = Date.now();
				}
			}).mouseup(function(e){
				if ( ( !PT.js.dragObject || !PT.js.dragObject._isDragging ) && e.which == 1 ) {
					return clickfunc(e);
				}
			}).click(function(e){
				e.preventDefault();
				e.stopPropagation();
				e.stopImmediatePropagation();
				return false;
			})
			return $(this);
		};

		PT.pages.SPOCMI00101.init(); // header
		PT.pages.SPOCMI00103.init(); // footer
		PT.utils.url.go();

	    var effects = {};
		$.easingOptions = { x: 1.8 };

		for (var i = 2 ; i <= 6; i++) {
			effects['pow' + i] = (function (i) {
				return function (p) {
					return Math.pow(p, i);
				}
			})(i);
		}

		effects.back = function (p) {
			return Math.pow(p, 2) * (($.easingOptions.x + 1) * p - $.easingOptions.x);
		}

		effects.elastic = function (p) {
			return Math.pow(2, 10 * (p - 1)) * Math.cos(20 * Math.PI * $.easingOptions.x / 3 * p);
		}

		effects.bounce = function (p) {
			for (var a = 0, b = 1 ; 1; a += b, b /= 2) {
				if (p >= (7 - 4 * a) / 11) {
					return -Math.pow((11 - 6 * a - 11 * p) / 4, 2) + Math.pow(b, 2);
				}
			}
		}

		// $.easing에 in,out,inout을 각각 등록합니다.

	    $.each(effects, function (name, fn) {
			$.easing[name + 'In'] = fn;
			$.easing[name + 'Out'] = function (p) {
				return 1 - fn(1 - p);
			};
			$.easing[name + 'InOut'] = function (p) {
				return (2 - fn(2 * (1 - p))) / 2;
			};
		});

		$.easing.keyframe = function(p) {
			if ( p == 1 ) return p;
			var kf = $.easingOptions.keyframe;
			var pF = kf.length * p;
			var p1Idx = Math.floor(pF);
			var kf2 = Math.ceil(pF) >= kf.length ? 1 : kf[p1Idx+1];
			var v =  kf2 - kf[p1Idx];
			v =  v * ( pF - p1Idx ) + kf[p1Idx];
			return v;
		}

		$.easing.shake = function(p) {
			return Math.exp( 1-p ) * Math.sin(4*Math.PI * p);
		};

		PT.admin.theme.load();
	},
	globalVars : {
		userId : undefined,
		naunvId : "999",
		userName : undefined,
		menu : undefined,
		locale : undefined,
		settings : undefined
	},
	consts : {
		context : '/nep',
		isMobile : false,
		TreeTraversalOrder : {
			Pre : 0,
			In : 1,
			Post : 2
		},
		ArrowDirection : {
			Top : 'arrowTop',
			Right : 'arrowRight',
			Bottom : 'arrowBottom',
			Left : 'arrowLeft',
			Auto : 'auto',
			None : null
		},
		Align : {
			Auto : 0,
			Top : 1,
			Left : 2,
			Center : 4,
			Right : 8,
			Bottom : 16,
			Middle : 32
		},
		Orientation : {
			Horizontal : 'horizontal',
			Vertical : 'vertical'
		},
	},
	data : {
		Tree : undefined,
		TreeNode : undefined,
		Menu : undefined,
		MenuItem : undefined,
		Size : undefined,
		Rectangle : undefined,
		Point : undefined,
	},
	text : {
		Search : undefined,
		Password : undefined
	},
	events: {
		NotificationCenter : {
			_callbacks : {},
			_observers : {},
			addObserver : function(obs, msg, callback) {
				if (!this._callbacks[msg]) {
					this._callbacks[msg] = $.Callbacks('stopOnFalse');
					this._observers[msg] = {};
				}
				this._callbacks[msg].add(callback);
				if (!obs.__notifications) {
					obs.__notifications = {};
				}
				obs.__notifications[msg] = callback;
			},
			removeObserver : function(obs, msg) {
				if (!obs.__notifications)
					return;
				switch (arguments.length) {
				case 1:
					for ( var msg in this._callbacks) {
						var cb = obs.__notifications[msg];
						if (cb) {
							this._callbacks[msg].remove(cb);
						}
					}
					delete obs.__notifications;
					break;
				case 2:
					if (!this._callbacks[msg])
						return;
					var cb = this.__notifications[msg];
					if (cb) {
						this._callbacks[msg].remove(cb);
						delete obs.__notifications[msg];
					}
					break;
				}
			},
			postNotification : function(msg) {
				if (!this._callbacks[msg]) {
					return;
				}
				var args = Array.prototype.slice.call(arguments, 1);
				this._callbacks[msg].fire.apply(this, args);
			}
		}
	},
	js : undefined,

	views : {
		PopoverController : undefined,
		ScrollBarView : undefined,
		ScrollView : undefined,
		Drag : undefined,
		View : undefined,
		TabBarView : undefined,
		TabView : undefined,
		TreeBase : undefined,
		TreeView : undefined,
		PagingScrollView : undefined
	},
	admin: {
		theme: {
			load : function() {
				PT.admin.theme.apply(PT.globalVars.settings.colors.main,
						PT.globalVars.settings.colors.sub,
						PT.globalVars.settings.colors.menu,
						PT.globalVars.settings.colors.etc);
			},
			updateCssRule : function(selector, name, value, url) {
				for ( var m in document.styleSheets) {
					var sheet = document.styleSheets[m];
					if (url && sheet.href && sheet.href.indexOf(url) == -1) {
						continue;
					}
					var rules = sheet.cssRules || sheet.rules;
					if (!rules)
						continue;
					for (var n = 0; n < rules.length; n++) {
						if (!rules[n].selectorText) {
							continue;
						}
						var i;
						var matchCount = 0;
						for (i = 0; i < selector.length; i++) {
							if (rules[n].selectorText.indexOf(selector[i]) >= 0) {
								matchCount++;
							}
						}
						if (matchCount == selector.length) {
							if (arguments.length > 2) {
								rules[n].style[name] = value;
							}
							return rules[n].style[name];
						}
					}
				}
			},
			colors : {
				bg1 : '#741834',
				bg2 : '#8C1A4D',
				menuColors : [ '#741834', '#620D26' ],
				noticeBg : '#393f48',
				noticeFg : 'white'
			},
			refresh : function() {
				PT.admin.theme.updateCssRule([
						'#__SPOCMI0020101__ .__subMenuTree', '.item', '.leaf',
						'.selected' ], 'background', PT.admin.theme.colors.bg2);
				PT.admin.theme.updateCssRule([ '#__SPOCSM001__ .submenu',
						'.depth1' ], 'color',
						PT.globalVars.settings.colors.main[0]);
			},
			apply : function(main, sub, menuColors, etc) {
				var bgColor = null;
				var filter;
				if (menuColors) {
					PT.admin.theme.colors.menuColors = menuColors;
					if (window.webkitRequestAnimationFrame
							|| window.WebKitAnimationEvent) {
						if (navigator.appVersion.indexOf('Chrome') != -1) {
							bgColor = "linear-gradient(%s, %s)";
						} else {
							bgColor = "-webkit-linear-gradient(top,%s, %s)";
						}
					} else if (window.msRequestAnimationFrame) {
						bgColor = "linear-gradient(to top,%s, %s)";
					} else if (window.mozRequestAnimationFrame) {
						bgColor = "-moz-linear-gradient(top,%s, %s)";
					} else if (navigator.userAgent.indexOf('MSIE') > 0) {
						filter = "progid:DXImageTransform.Microsoft.gradient(startColorstr='%s', endColorstr='%s', GradientType=0)";
					} else {
						bgColor = "linear-gradient(%s, %s)";
					}

					PT.admin.theme.updateCssRule([ '.__neptheme',
							'.__menuBackground' ], bgColor ? 'background'
							: 'filter', bgColor ? bgColor.sprintf(
							menuColors[0], menuColors[1]) : filter.sprintf(
							menuColors[0], menuColors[1]), 'base.css');
				}
				if (main) {
					PT.admin.theme.colors.bg1 = main[0];
					PT.admin.theme.updateCssRule([ '.__neptheme',
							'.__backgroundColor1' ], "backgroundColor",
							main[0], 'base.css');
					PT.admin.theme.updateCssRule([ '.__neptheme',
							'.__menuFontColor' ], "color", main[0], 'base.css');
					PT.admin.theme.updateCssRule([ '.__neptheme',
							'.__mainFontColor' ], "color", main[1], 'base.css');
					PT.admin.theme.updateCssRule([ '.submenu', '.multicolumn',
							'.leaf:hover', '.title' ], "color", main[0], null);
					PT.admin.theme.updateCssRule([ '#__SPOCSM001__ .submenu',
							'.depth1' ], 'color', main[0], null);
					PT.admin.theme.updateCssRule([ '.__neptheme',
							'.__mainBorderColor' ], "borderColor", main[0],
							'base.css');
				}
				if (sub) {
					PT.admin.theme.colors.bg2 = sub[0];
					PT.admin.theme.updateCssRule([ '.__neptheme',
							'.__backgroundColor2' ], "backgroundColor", sub[0]);

					PT.admin.theme.updateCssRule([
							'#__SPOCMI0020101__ .__subMenuTree', '.item',
							'.leaf', '.selected' ], 'background', sub[0]);
					PT.admin.theme.updateCssRule([
							'#__SPOCMI0020101__ .__subMenuTree', '.item',
							'.leaf', '.selected' ], 'color', sub[1]);
					PT.admin.theme.updateCssRule([ '.__neptheme',
							'.__borderColor' ], "borderColor", sub[0]);
				}

				if (etc) {
					PT.admin.theme.colors.noticeBg = etc[0];
					PT.admin.theme.updateCssRule([ '.__neptheme',
							'.__noticeColors' ], "backgroundColor", etc[0],
							'base.css');
					PT.admin.theme.colors.noticeFg = etc[1];
					PT.admin.theme.updateCssRule([ '.__neptheme',
							'.__noticeColors' ], "color", etc[1], 'base.css');
				}
			},
			redTheme: function() {
				PT.admin.theme.apply(['#741834', 'white'], ['#8C1A4D', 'white'], ['#741834','#620D26'], ['#393f48', 'white']);
			},
			greenTheme: function() {
				PT.admin.theme.apply(['#009170', 'white'], ['#05A985', 'white'], ['#009170', '#028667'], ['darkred', 'gold']);
			},
			blueTheme: function() {
				PT.admin.theme.apply(['#1D50A2', 'white'], ['#3563AC', 'white'], ['#1D50A2', '#1A4B9C'], ['darkgreen', 'tomato']);
			}
		}
	},
	utils : {
		loading : {
			showScreenBlock : function() {
				if (this._screenblock)
					return;
				this._screenblock = $('<div/>').addClass('__screenblock')
						.appendTo($('body'));
			},
			hideScreenBlock : function() {
				if (this._screenblock) {
					this._screenblock.remove();
					delete this._screenblock;
				}
			},
			show : function(element, screenblock, message) {
				if ($("[id='__loadingView']").length === 0) {
					element = element || window;
					var self = this;
					this.element = $(element);
					this.hide();
					if (screenblock) {
						this._screenblock = $('<div/>').addClass(
								'__screenblock').appendTo($('body'));
					}

					this._body = $('<div/>', {
						id : '__loadingView'
					}).appendTo('body').css({
						position : element == window ? 'fixed' : 'absolute'
					});
					$(
							'<img/>',
							{
								src : message ? '/nep/images/waiting.gif'
										: '/nep/images/loading.gif',
								alt : '로딩 이미지'
							}).appendTo(this._body);
					if (message) {
						$('<div/>').html(message).appendTo(this._body);
					}
				}
			},
			hide : function() {
				if (this._screenblock) {
					this._screenblock.remove();
					delete this._screenblock;
				}
				if (this._body) {
					this._body.remove();
					delete this._body;
				}
			}
		},
		menu : {
			getMenuPath : function(menuNo) {
				menuNo = menuNo || PT.globalVars.selectedMenu.menuNo;
				var mItem = PT.globalVars.menu[menuNo];
				if (!mItem)
					return undefined;
				return mItem.nodePath().map(function(v) {
					return v.properties;
				});
			},
			getMenuTop : function(menuNo) {
				menuNo = menuNo || PT.globalVars.selectedMenu.menuNo;
				var mItem = PT.globalVars.menu[menuNo];
				if (!mItem)
					return undefined;
				return mItem.getTop().properties;
			}
		},
		tabbar : {
			openMenuItem : function(mId) {
				PT.pages.SPOCMI00102.hide();
				var item = PT.globalVars.menu[mId];
				if (item) {
					if (arguments.length > 1) {
						item._arguments = Array.prototype.slice.call(arguments,
								1);
					} else if (item._arguments) {
						delete item._arguments;
					}
					PT.pages.SPOCMI00201.openMenuItem(item);
				}
			},
			selectedMenuItem : function() {
				var bodyInsideView = $('#__SPOCMI00201__');
				var iframe = bodyInsideView.instance('cont').ContentVC.selectedIframe;
				return iframe != null ? iframe.data('item').properties : null;
			}
		},
		nexacro : {
			loaded : function() {
				var nexacroIframe = $('#nexaIfm');
				nexacroIframe.data('loaded', true)
				nexacro_call(nexacroIframe.data('args'));
				nexacroIframe.data('args', undefined);
			},
			invoke : function(args) {
				var nexa = document.getElementById("nexaIfm").contentWindow;
				if (nexa && nexa.application
						&& nexa.application.application_Call) {
					nexa.application.application_Call(args);
				}
			},
			scrollTop : function(y) {
				var nexa = document.getElementById("nexaIfm").contentWindow;
				if (nexa && nexa.application
						&& nexa.application.application_Pos) {
					nexa.application.application_Pos(y);
				}
			},
			portalCall : function(objParam) {
				if (objParam.formHeight !== undefined) {
					PT.utils.nexacro.resize(objParam.formHeight);
				}
				if (objParam.msg !== undefined) {
					PT.utils.portal.notifyMessage(objParam.msg);
				}
			},
			resize : function(h) {
				var iframe = $('#nexaIfm');
				PT.utils.portal.resizeContentFrameBlock(h, iframe);
			},
			dispatch : function(data) {
				var iframe = document.getElementById("nexaIfm");
				if (iframe == null)
					return;
				var nexa = iframe.contentWindow;
				data.method = 'dispatch';
				nexa.application.application_Call(data);
			}
		},
		SaaS : {
			openForm : function(menu, url, args, callback) {
				var iframe = $('#__SPOCMI00201__ .__SaaSForm');
				iframe.get(0).contentWindow.App.MDI.DoForms(menu, url, args,
						function() {
							PT.utils.portal.resizeContentFrameBlock();
							if (callback) {
								callback();
							}
						});
			},
			closeForm : function(menu) {
				var iframe = $('#__SPOCMI00201__ .__SaaSForm');
				iframe.get(0).contentWindow.App.MDI.DoFormsClose(menu);
			}
		},
		portal : {
			init : function() {
				try {
					this.noticePopupInstance = N().popup({
						url : PT.utils.portal.pageURL('P000181'),
						width : 600,
						modaless : false,
						onOpen : 'onOpen'
					});
					if (PT.utils.url.params.cmd != 'menu'
							&& PT.globalVars.settings.mode != 'edit') {
						if (localStorage && localStorage.lastNoticePopupDT) {
							var now = new Date();
							now.setHours(0);
							now.setMinutes(0);
							now.setSeconds(0);
							var last = new Date(
									parseInt(localStorage.lastNoticePopupDT));
							last.setHours(0);
							last.setMinutes(0);
							last.setSeconds(0);
							var diff = Math.round((now - last)
									/ (24 * 60 * 60 * 1000));
							if (diff >= 1) {
								this.openNotice();
							} else {
								this
										.openNotice(
												undefined,
												new Date(
														parseInt(localStorage.lastNoticePopupDT)))
							}
						} else {
							this.openNotice();
						}
					}

					// Ajax 요청 시 페이지 블록
					this.appendPageBlockEle();

				} catch (ex) {

				}
			},
			openNotice: function(data,lastDate) {
				var self = this;
				if ( data ) {
					if ( !this.noticePopupInstance ) {
						this.noticePopupInstance =  N().popup({
							url :  PT.utils.portal.pageURL('P000181'),
							width : 500,
							modaless: false,
							onOpen: 'onOpen'
						});
					}
					self.noticePopupInstance.options.context.parentsUntil('.popup__').parent().find('.msg_title__').text( "공지사항" );
					this.noticePopupInstance.open(data);
				} else if ( sessionStorage && !sessionStorage.alreadyPopupped) {
					N().comm(PT.consts.context + "/bd/NoticeCtr/getNoticeInfo.json").submit(function(data) {
						if ( data && data.length ) {
							var list = [];
							if ( lastDate ) {
								for( var i = 0 ; i < data.length; i++ ) {
									if ( data[i].frstRegistDt ) {
										var dt = new Date(data[i].frstRegistDt);
										if ( dt > lastDate ) {
											list.push(data[i]);
										}
									}
								}
								if ( list.length == 0 ) return;
								data = list;
								localStorage.lastNoticePopupDT = Date.now();
							}
							sessionStorage.alreadyPopupped = true;
							self.noticePopupOpened = true;
							if ( data.length > 1 ){
								self.noticePopupInstance.options.title= "공지사항 " + data.length + '개';
							}
							self.noticePopupInstance.open(data);
						}
					});
				}
			},
			removeNotice : function() {
				if (this.noticePopupInstance) {
					if (this.noticePopupOpened) {
						this.noticePopupInstance.options.context.remove();
						this.noticePopupInstance.remove();
					}
					delete this.noticePopupInstance;
				}
			},

			pageURL : function(pId) {
				return PT.consts.context + "/mi/MenuCtr/getProgrm.do?progrmId=" + pId;
			},
			pops : [],
			resizeContentFrameBlock : function(h, iframe) {
				var bodyPage = $('body .__SPOCMI00201_page');
				var bodyInsideView = $('#__SPOCMI00201__');
				if (bodyInsideView.length == 0)
					return;
				var contentVC = bodyInsideView.instance('cont').ContentVC;
				if (contentVC == null)
					return;
				var headerPage = $('body .__SPOCMI00101_page');
				var footerPage = $('body .__SPOCMI00103_page');

				var tabBarH = bodyInsideView.find('.__renderingModeButtons')
						.outerHeight()
						+ bodyInsideView.find('.__tabBarRegion').outerHeight();
				if (!iframe) {
					iframe = contentVC.selectedIframe;
					if (iframe == null)
						return;
				}
				var item = iframe.data('item');
				if (!h) {
					if (iframe[0].nodeName == 'IFRAME') {
						var iframeElement = iframe.get(0);
						var content = iframeElement.contentWindow
								|| iframeElement.contentDocument;
						if (iframe.hasClass('__SaaSForm')) {
							h = content.document.body ? content.document.body.scrollHeight
									: 680;
						} else {
							h = iframe.height();
						}
					} else {
						h = undefined;
					}
				} else {
					h = Math.max(680, parseInt(h));
				}
				if (h) {
					iframe.height(h);
				} else if (iframe.hasClass('__nepForm')) {
					h = iframe.outerHeight() + 40;
				}

				h = Math.max($(window).height() - headerPage.outerHeight()
						- footerPage.outerHeight(), h + tabBarH);
				bodyPage.height(h);
				var cont = bodyInsideView.instance('cont');
				cont.layoutSubviews();
				$('#__SPOCMI00101__').instance('cont').layoutSubviews();
			},
			statusbar : undefined,
			showStatusBar : function(hover) {
				var self = this;
				if (this.messageTimer) {
					clearTimeout(this.messageTimer);
					delete this.messageTimer;
				}
				this.statusbar.stop().show().css({
					opacity : 1
				});
				if (!hover) {
					this.messageTimer = setTimeout(function() {
						self.statusbar.animate({
							opacity : 0.2
						}, {
							duration : 1000
						});
						delete self.messageTimer;
					}, 3000);
				}
			},

			hideStatusBar : function(hover, forcefully) {
				if (forcefully) {
					if (this.messageTimer) {
						clearTimeout(this.messageTimer);
						delete this.messageTimer;
					}
				}
				if (hover) {
					var self = this;
					if (this.messageTimer) {
						clearTimeout(this.messageTimer);
						delete this.messageTimer;
					}
					this.statusbar.animate({
						opacity : 0.2
					}, {
						duration : 1000
					});
				} else if (!this.messageTimer) {
					this.statusbar.css({
						opacity : 0.2
					}, {
						duration : 500
					})
				}
			},

			notifyMessage : function(msg, forcefully) {
				if(N.string.trimToNull(msg) !== null) {
					N().notify().add(msg);
				}
			},

			menus : {},
			selectedMenu : null,
			openForm : function(item, body) {
				if (this.selectedMenu != null) {
					this.selectedMenu.hide();
					this.selectedMenu.removeClass('selected');
				}

				if (!this.menus[item.properties.menuNo]) {
					var self = this;
					this.menus[item.properties.menuNo] = $('<div/>', {
						id : '__nepForm_' + item.properties.menuNo,
					}).data('item', item).appendTo(body).comm(PT.consts.context
						+ "/mi/MenuCtr/getProgrm.do?progrmId="
						+ item.properties.programId + "&sysMenuNo="
						+ item.properties.sysMenuNo).submit(function() {
						PT.utils.portal.resizeContentFrameBlock();
					});
					this.selectedMenu = this.menus[item.properties.menuNo]
				} else {
					this.selectedMenu = this.menus[item.properties.menuNo];
					this.selectedMenu.show();
					PT.utils.portal.resizeContentFrameBlock();
					this.selectedMenu.children("[id]").trigger('form.appeared');
				}
				this.selectedMenu.addClass('selected');
			},
			closeForm : function(item) {
				var view = this.menus[item.properties.menuNo];
				PT.utils.editor.destroyHTMLEditor(view);
				if (view) {
					if (view == this.selectedMenu) {
						this.selectedMenu = null;
					}
					view.removeClass('selected');
					view.children().trigger('form.closed');
					view.remove();
					delete this.menus[item.properties.menuNo];
				}
			},
			disappearForm : function(menuNo) {
				var view = this.menus[menuNo];
				if (view) {
					view.children("[id]").trigger('form.disappeared');
				}
			},
			getAccessRight : function(mId) {
				var item = PT.globalVars.menu[mId];
				if (item) {
					return item.properties.authority;
				}
				return null;
			},
			closeSelectedTab : function() {
				var cont = $('#__SPOCMI0020102__').instance('cont');
				if (cont) {
					cont.closeSelectedTab();
				}
			},
			appendPageBlockEle : function() {
				if ($("#progressBar__").length === 0) {
					$('<div id="progressBar__"></div>')
						.css({
							position : "fixed",
							top : 0,
							left : 0,
							height : $(window).height(),
							width : $(window).width(),
							display : "none",
							margin : "0 auto",
							"z-index" : 99999999
						})
						.appendTo("body")
						.append('<img src="../../images/loading.gif" alt="처리중입니다">')
						.find("img").css({
							position : "fixed",
							top : $(window).height() / 2 - 60,
							left : $(window).width() / 2 - 64
						});
					$(window).resize(function() {
						$("#progressBar__").css({
							height : $(window).height(),
							width : $(window).width()
						}).find("img").css({
							top : $(window).height() / 2 - 60,
							left : $(window).width() / 2 - 64,
						});
					});
				}
			},
		   	nexacroRequestXml: function( params, dataset ) {
		   		var xml = '<?xml version="1.0" encoding="UTF-8"?><Root xmlns="http://www.nexacroplatform.com/platform/dataset">';
		   		if ( params ) {
		   			var xmlParams = '<Parameters>';
		   			for( var key in params) {
		   				xmlParams += '<Parameter id="%s">%s</Parameter>'.sprintf(key, params[key]);
		   			}
		   			xmlParams += '</Parameters>';
		   			xml += xmlParams;
		   		}
		   		if (dataset) {
		   			var xmlDataSet = '<Dataset id="%s">'.sprintf(dataset.id);
		   			if ( dataset.columns ){
		   				xmlDataSet += "<ColumnInfo>";
		   				for( var key in dataset.columns ) {
		   					var col = dataset.columns[key];
		   					xmlDataSet += '<Column id="%s" type="%s" size="%d"/>'.sprintf( key, col.type || "STRING", col.size );
		   				}
		   				xmlDataSet += "</ColumnInfo>"
		   				if ( dataset.rows ) {
		   					xmlDataSet += "<Rows>";
		   					for ( var i = 0 ; i < dataset.rows.length; i++ ) {
		   						var row = dataset.rows[i];
		   						xmlDataSet += "<Row>";
		   						for( var key in row )
		   						{
			   						xmlDataSet += '<Col id="%s">%s</Col>'.sprintf(key, row[key]);
		   						}
		   						xmlDataSet += "</Row>";
		   					}
		   					xmlDataSet += "</Rows>";
		   				}
		   			}
		   			xmlDataSet += "</Dataset>";
		   			xml += xmlDataSet;
		   		}
		   		xml += '</Root>';
		   		return xml;
		   	},
		   	popup : function(url, params, name, options) {
				options = $.extend({
					fullscreen : 'no',
					status : 'no',
					toolbar : 'no',
					titlebar : 'yes',
					location : 'no',
					scrollbar : 'yes'
				}, options);

				var strOpts = Object.keys(options).map(function(k) {
					return k + "=" + options[k];
				}).join(",");

				var url = PT.consts.context + "/etc/popup.jsp?__url="
						+ encodeURIComponent(url);
				if (params) {
					url += '&';
					url += Object.keys(params).map(function(k) {
						var p = params[k].toString();
						return "%s=%s".sprintf(k, encodeURIComponent(p));
					}).join('&');
				}
				return window.open(url, name, strOpts);
			}
		},
		url : {
			params: {},
			extra: {},
			_v: undefined,
			init : function() {
				var self = this;
				window.onhashchange = function() {
					self.parse();
					$('body').trigger('hashChanged');
					self.go();
				};
			},
			parse : function() {
				this.extra = {};
				var q = location.hash.substr(1);
				var args = q.length > 0 ? JSON.parse('{"' + q.replace(/&/g, '","').replace(/=/g,'":"') + '"}',
						   function(key, value) { return key===""?value:decodeURIComponent(value); }) : {} ;
				this._v = args['_v'];
				if ( args['_v'] && sessionStorage[args['_v']] )
				{
					var q = sessionStorage[args['_v']];
					var vargs = q.length > 0 ? JSON.parse('{"' + q.replace(/&/g, '","').replace(/=/g,'":"') + '"}',
							   function(key, value) { return key===""?value:decodeURIComponent(value); }) : {} ;
					args = $.extend( vargs, args);
				}
				for( var k in args ){
					args[k] = decodeURIComponent(args[k]);
				}
				delete args['_v'];
				this.params = args;
			},
			deleteParamKey : function(key) {
				if ( this._v && sessionStorage[this._v] ) {
					var q = sessionStorage[this._v];
					var args = q.length > 0 ? JSON.parse('{"' + q.replace(/&/g, '","').replace(/=/g,'":"') + '"}',
							   function(key, value) { return key===""?value:decodeURIComponent(value); }) : {} ;
					delete args[key];
					sessionStorage[this._v] = Object.keys(args).map(function(k){
						return k + '=' + args[k];
					}).join('&');
					delete this.params[key];
				}
			},
			clearParamKeys : function() {
				var args = {
					cmd : this.params.cmd,
					mId : this.params.mId
				};
				if (this._v && sessionStorage[this._v]) {
					sessionStorage[this._v] = Object.keys(args).map(function(k) {
						return k + '=' + args[k];
					}).join('&');
				}
			},
			openUrl: function(cmd,args) {
				var sessionOut = false;
				var url;
				var marker = '#';
				var width = 1260;
				var height = undefined;
				switch( cmd ) {
					case 'main':
						url = PT.consts.context + '/mi/IndxCtr/indx.do';
						break;
					case 'sessionOut':
						sessionOut = true;
					case 'login':
						url = PT.consts.context + '/uf/LoginCtr/lginView.do&locale=' +  PT.globalVars.userInfo.locale;
						break;
					default:
						url = PT.consts.context + '/mi/IndxCtr/indx.do';
						break;
				}
				if ( args ) {
					var keys = Object.keys(args);
					if ( keys.length > 0 ) {
						url += marker + keys.map(function(k){
							var p = args[k].toString();
							return "%s=%s".sprintf(k, ( p.indexOf('&') >= 0 || p.indexOf('%') >= 0  ) ? encodeURIComponent( p ) : p);
						}).join('&');
					}
				}
				if ( sessionOut ) {
					N(window).alert({
						msg: N.message.get(PT.messages, "sessionOut"),
						onOk : function() {
							window.location.href = url;
						}
					}).show();
				} else {
					if ( cmd == 'td' ||  cmd == 'help' || cmd == 'itsm' || cmd == 'video' || cmd == 'userguide' || cmd == "eams"){
						var win = '_window_' + cmd;
						if ( !this[win]|| this[win].closed ) {
							var opts = 'toolbar=no,location=no,titlebar=no,menubar=no,directories=no,resizable=yes';
							if ( width ) {
								opts += ',width=' + width;
							}
							if ( height ) {
								opts  += ',height=' + height;
							}
							if ( cmd == 'help' || cmd == 'video' || cmd == 'userguide' ) opts += ',scrollbars=yes';
							this[win] = window.open(url, "_blank", opts );
						} else {
							this[win].location.href = url;
							this[win].focus();
						}
					} else {
						location.href = url;
					}
				}
			},
			open : function(args, notExtend, viewMode) {
				// $.extend ignore null and undefined
				for ( var key in args ) {
					if ( this.params[key] !== undefined && args[key] === undefined ) {
						delete this.params[key];
					}
				}
				if ( !notExtend ) {
					args = $.extend( {}, this.params, args );
				}
				if ( args.cmd == 'menu' && !args.mId ) {
					alert(N.message.get(PT.messages, "noMenuId"));
					return;
				}
				var keys = args ? Object.keys(args) : null;
				var hash = '';
				if ( keys && keys.length > 0 ) {
					switch( viewMode ) {
						case 'window':
						case 'tab':
							args.size = 'window';
							keys.push('size');
							break;
					}
					var data = keys.filter(function(v){
						return args[v] !== undefined;
					}).map(function(k){
						var p = args[k].toString();
						return "%s=%s".sprintf(k, ( p.indexOf('&') >= 0 || p.indexOf('%') >= 0  ) ? encodeURIComponent( p ) : p);
					}).join("&");
					hash = parseInt(Math.random() * 1000).toString(32) + Date.now().toString(32);
					sessionStorage.setItem(hash, data);
				}
				switch ( viewMode ) {
					case 'window':
						return window.open(location.origin + PT.consts.context + '/mi/IndxCtr/indx.do#_v=' + hash, "_blank", 'toolbar=no,location=no');
						break;
					case 'tab':
						return window.open(location.origin + PT.consts.context + '/mi/IndxCtr/indx.do#_v=' + hash, "_blank");
						break;
					default:
						location.hash = '#_v=' + hash;
						break;
				}
			},
			goMenu: function() {
				if ( PT.utils.portal.pops && PT.utils.portal.pops.length  ) {
					for ( var i = 0 ; i < PT.utils.portal.pops.length ; i++ ) {
						var inst = PT.utils.portal.pops[i];
	    	    		inst.options.context.remove();
	    	    		inst.remove();
					}
					PT.utils.portal.pops = [];
				}

				var item = PT.globalVars.menu[this.params.mId];
				if ( !item ) {
					alert(N.message.get(PT.messages, "noMenuId"));
					return;
				}
				// popup
				if ( item.properties.resplProgrmSeCode == 'NCMA0043N00020') {
					var win = '_window_' + item.properties.id;
					if ( !this[win]|| this[win].closed ) {
						this[win] = window.open(item.properties.menuUrl, "_blank", 'toolbar=no,location=no,titlebar=no,menubar=no,directories=no,resizable=yes,scrollbars=yes');
					} else {
						this[win].focus();
					}
					if( !$('body .panel').hasClass('content') ) {
						PT.pages.SPOCMI00102.show();
						var obj = N('#__SPOCMI00101__').instance('cont');
						if ( obj ) {
							obj.layoutSubviews(1260);
						}
					}
					return;
				}

				PT.pages.SPOCMI00102.hide();
				if (this.params.size == 'window') {
					$('body > .__SPOCMI00101_page').hide();
					$('body > .__SPOCMI00103_page').hide();

					var bodyView = $('#__SPOCMI00201__');

					if (bodyView.length) {
						var subMenuView = bodyView.find('.__subMenuPage');
						var contentView = bodyView.find('.__contentViewRegion');
						subMenuView.hide();
						contentView.children(':not(.__contentContainer)').hide();
						contentView.css({
							width : $('body').width(),
							left : 0
						});
					}
				} else {
					$('body > .__SPOCMI00101_page').show();
					$('body > .__SPOCMI00103_page').show();
				}


				if ( item ) {
					if( !$('body .panel').hasClass('content') ) {
						$('body .panel').addClass('content');
						$('.multicolumn.submenu').addClass('content');
					}
					PT.pages.SPOCMI00201.openMenuItem(item);
				} else {
					alert( N.message.get(PT.messages, "menuNotFound"));
				}
			},
			go : function() {
				this.parse();

				if (this.params.cmd == 'menu' && this.params.mId) {
					var self = this;
					if (PT.globalVars.menu == null) {
						$('body').bind('menuLoaded', function() {
							self.goMenu();
						});
					} else {
						self.goMenu();
					}
				} else {

					if (this.params.size == 'window') {
						$('body > .__SPOCMI00101_page').hide();
						$('body > .__SPOCMI00103_page').hide();

						var bodyView = $('#__SPOCMI00201__');

						if (bodyView.length) {
							var subMenuView = bodyView.find('.__subMenuPage');
							var contentView = bodyView .find('.__contentViewRegion');
							subMenuView.hide();
							contentView.children(':not(.__contentContainer)') .hide();
							contentView.css({
								width : $('body').width(),
								left : 0
							});
						}
					} else {
						$('body > .__SPOCMI00101_page').show();
						$('body > .__SPOCMI00103_page').show();
					}

					PT.pages.SPOCMI00102.show();
					var obj = N('#__SPOCMI00101__').instance('cont');
					if (obj) {
						obj.layoutSubviews(1260);
					}
				}
			}
		},
		portlet : {
			alarms : {
				objects : undefined
			},
			blocks : {
				objects : undefined
			},
		},
		file : {
			list : undefined,

			init : function(args, isPoe) {
				var params = {
					upload : true,
					download : true,
					remove : true,
					maxupload : 10
				};

				if (args) {
					for ( var k in params) {
						if (args[k] !== undefined) {
							params[k] = args[k];
							delete args[k];
						}
					}
				}

				args = $.extend({
					width : 700,
					onOpen : "onOpen",
				}, args);
				args.isPoe = isPoe;
				args.url = PT.consts.context + "/cm/CmmnCtr/filepop.do?" + Object.keys(params).map(function(k) {
					return k + '=' + params[k];
				}).join("&");

				var callback = args.onClose;
				args.onClose = function(data) {
					if (data) {
						if (data.length == 0) {
							popupInstance.filename = '';
						} else if (data.length == 1) {
							popupInstance.filename = data[0].orginlFileNm;
						} else {
							popupInstance.filename = N.message.get(PT.messages, "ext1").sprintf(data[0].orginlFileNm, data.length - 1);
						}
					} else {
						popupInstance.filename = '';
					}
					popupInstance.files = data;
					if (callback)
						callback(data, popupInstance.filename);
				};
				var popupInstance = N().popup(args);
				popupInstance.isPoe = isPoe;
				return popupInstance;
			},
			getFileList : function(targetEle, attfgNo, callback, isPoe) {
				var cmd = isPoe ? 'nonSessionGetFileList.do'  : 'getFileList.do';
		   		N.comm({
		   			url : "/cm/c/cm/FileCtr/" + cmd + "?attfgNo=" + attfgNo + "&menuPID=" + PT.globalVars.selectedMenu.progrmId,
		   			dataType : "json"
		   		}).submit(function(data) {
		   			targetEle.empty();
		 			if ( data  && data.rows ) {
			   			var fileCont = $('<ul class="fileCont file_list"></ul>').appendTo(targetEle);
			   			var url;
			   			if ( isPoe ) {
			   				url = "/cm/c/cm/FileCtr/nonSessionDownloadPoe.do";
			   			} else {
			   				url = "/cm/c/cm/FileCtr/download.do";
			   			}
			   			$(data.rows.fileList).each(function(i, rowData) {
			   				var downloadFileEle = $('<li></li>').appendTo(fileCont);
			   				$('<a></a>', {
			   					"class": "fileName",
			   					"target": "fileDownFrame",
			   					"href": url + "?menuPID=" + PT.globalVars.selectedMenu.progrmId + "&attfgNo=" + attfgNo + "&attflNo=" + rowData.attflNo,
			   					"text": rowData.orginlFileNm
			   				}).appendTo(downloadFileEle);
			   			});
			   			if($("iframe[name='fileDownFrame']").length === 0) {
			   				fileCont.after('<iframe name="fileDownFrame" height="0" width="0" style="display: none;"></iframe>');
			   			}
		 			}
	   				if ( callback ) {
	   					callback(data);
	   				}
		   		});
		   	},

		   	getFiles: function(attfgNo,callback,programId, isPoe) {
		   		programId = programId || PT.globalVars.selectedMenu.progrmId;
				var cmd = isPoe ? 'nonSessionGetFileList.do'  : 'getFileList.do';
		   		N.comm({
		   			url : "/cm/c/cm/FileCtr/" + cmd + "?attfgNo=" + attfgNo + "&menuPID=" + programId,
		   			dataType : "json"
		   		}).submit(function(data) {
		   			if ( data ) {
			   			var url;
			   			if ( isPoe ) {
			   				url = "/cm/c/cm/FileCtr/nonSessionDownloadPoe.do";
			   			} else {
			   				url = "/cm/c/cm/FileCtr/download.do";
			   			}
			   			$(data.rows.fileList).each(function(idx,rowData){
			   				rowData.href = url + "?menuPID=" + programId + "&attfgNo=" + attfgNo + "&attflNo=" + rowData.attflNo;
			   			});
			   			callback( data.rows.fileList );
		   			} else {
		   				callback( );
		   			}
		   		});
		   	},


		},
		pki : {
			_initialized : false,
			_context : undefined,
			init : function(callbacks, context) {
				this.callbacks = callbacks || {};
				this._context = context || this;
				setTimeout(function() {
					PT.utils.loading.show(undefined, true);
				}, 0);
				if (!this._initialized) {
					CheckClient(true, this.messages);
					Init();
					this._initialized = true;
				} else if (this.callbacks.StartAgent) {
					setTimeout(function() {
						PT.utils.loading.showScreenBlock();
					}, 10);
					this.callbacks.StartAgent();
				}
			},
			messages : function(funcName, returnValue, errNum, errMsg) {
				if (funcName == "StartAgent") {
					var optionArr = new Array();

					var params1 = new Object();
					params1.fieldname = "PWDFail_Limit";
					params1.value = "3";

					var params2 = new Object();
					params2.fieldname = "Set_Ubikey";
					params2.value = UBIKEY_SERVICE_DATA;

					var params3 = new Object();
					params3.fieldname = "Set_AOS";
					params3.value = EPKI_SECURE_OPTION_SBFWAK;

					optionArr[0] = params1;
					optionArr[1] = params2;
					// optionArr[2] = params3;

					WaitForSocketConnection(CALLBACK_SetProperty, optionArr);
					PT.utils.loading.hide();
					PT.utils.loading.showScreenBlock();
				}
				if (PT.utils.pki.callbacks[funcName]) {
					PT.utils.loading.hide();
					if (returnValue == '' && errNum && errMsg) {
						if (PT.utils.pki.callbacks.error) {
							PT.utils.pki.callbacks.error(errNum, errMsg);
						}
					} else {
						PT.utils.pki.callbacks[funcName].call(
								PT.utils.pki._context, returnValue, errNum,
								errMsg);
					}
				}
			},
			/*
			err : -1 network error
			err : 1  error occured
			err : 100 expired
			PT.utils.pki.invokePKI(function(data,err){
				console.log(data,err)
			});
			*/
			invokePKI : function(callback) {
				this._iframeCallback = callback;
				var iframe = $('#__pkiIframe');
				var callbackPKI = function(iframe) {
					var content = iframe.get(0).contentWindow
							|| iframe.contentDocument;
					content.launch();
				}
				if (iframe.length == 0) {
					iframe = $('<iframe/>', {
						id : '__pkiIframe',
						src : PT.consts.context + '/etc/pki.jsp'
					}).appendTo('body').hide().load(function() {
						callbackPKI(iframe);
					});
				} else {
					callbackPKI(iframe);
				}
			},

			iframeCallback : function(data, error) {
				this._iframeCallback(data, error);
			}
		}
	}, // utils
	messages : {
    	ko_KR : {
    		"ext1" : "%s 외 %d건" ,
    		weeks: ['일','월', '화', '수', '목', '금', '토' ],
    		portletAccessRightMsg: '권한 설정에서 한개 이상은 선택하셔야 합니다.',
    		sessionOut: '세션이 만료되었거나 로그인 하지 않았습니다.<br><br>로그인 화면으로 이동 하겠습니까?',
    		noMenuId: '잘못된 요청입니다. 메뉴 ID 부재',
    		menuNotFound: '메뉴가 존재하지 않습니다.',
    		surveyOptionMsg: '문구를 작성해 주세요',
    		error: '오류',
    		yes: '사용',
    		no: '사용불가'
    	},
    	en_US : {
    		"ext1" : "%s 외 %d건",
    		weeks: ['Sun','Mon', 'Tue', 'Wed', 'Thr', 'Fri', 'Sat' ],
    		portletAccessRightMsg: '권한 설정에서 한개 이상은 선택하셔야 합니다.',
    		sessionOut: '세션이 만료되었거나 로그인 하지 않았습니다.<br><br>로그인 화면으로 이동 하겠습니까?',
        	noMenuId: '잘못된 요청입니다. 메뉴 ID 부재',
        	menuNotFound: '메뉴가 존재하지 않습니다.',
        	surveyOptionMsg: '문구를 작성해 주세요',
        	error: '오류',
        	yes:'Yes',
        	no: 'No'
    	}
    }
};

/* Header */
PT.pages.SPOCMI00101 = {
	view : null,
	init : function() {
		this.view = N('body > .__SPOCMI00101_page');
		this.view.comm(PT.utils.portal.pageURL('P000205')).submit();
	},
	openMenuItem : function(item) {
		PT.pages.SPOCMI00102.hide();
		PT.pages.SPOCMI00201.openMenuItem(item);
	}
};

/* Portlet */
PT.pages.SPOCMI00102 = {
	view : null,
	init : function(cb) {
		this.view = N('body .__SPOCMI00102_page').empty();
		this.view.comm(PT.utils.portal.pageURL('P000212')).submit(
				function() {
					cb();
				});
	},
	hide : function() {
		if (this.view == null || this.view.css('display') == 'none')
			return;
		if (PT.utils.portlet.blocks.objects) {
			PT.utils.portlet.blocks.objects.forEach(function(v) {
				v.remove();
			});
			delete PT.utils.portlet.blocks.objects;
		}
		$('body .panel').addClass('content');
		$('.multicolumn.submenu').addClass('content');
		this.view.empty();
		delete this.view;
	},
	show : function() {
		if (PT.pages.SPOCMI00201.view) {
			if (PT.utils.portlet.blocks.objects) {
				PT.utils.portlet.blocks.objects.forEach(function(v) {
					v.remove();
				});
				delete PT.utils.portlet.blocks.objects;
			}
			PT.pages.SPOCMI00201.hide();
		}
		if (PT.utils.portal.selectedMenu) {
			PT.utils.portal.selectedMenu = null;
			delete PT.globalVars.selectedMenu;
		}
		if (!this.view) {
			var self = this;
			this.init(function() {
				self.show();
			});
			return;
		}
		$('body .panel.content').removeClass('content');
		$('.multicolumn.submenu').removeClass('content');
		var cont = $('#__SPOCMI00102__', this.view).instance('cont');
		cont.show();
		this.view.show();
		N({
			status : 'delete'
		}).comm(PT.consts.context + '/mi/MenuCtr/saveSelectedMenuInfo.json').submit();
	}
};

/* Footer */
PT.pages.SPOCMI00103 = {
	view: null,
	init: function() {
		this.view = N('body > .__SPOCMI00103_page');
		this.view.comm(PT.utils.portal.pageURL('P000213')).submit();
	}
};

/* Content */
PT.pages.SPOCMI00201 = {
	init : function(cb) {
		var self = this;
		this.view = N('body .__SPOCMI00201_page').bind('pageLoaded', cb);
		this.headerController = $('#__SPOCMI00101__').instance('cont');
		this.menuController = $('#__SPOCMI0010102__').instance('cont').MenuVC.MenuView;
		this.view.comm(PT.utils.portal.pageURL('P000217')).submit(function() {
			self.controller = $('#__SPOCMI00201__').instance('cont');
			self.view.hide();
		});
	},
	hide : function() {
		if (PT.utils.portal.selectedMenu) {
			PT.utils.portal.selectedMenu = null;
			delete PT.globalVars.selectedMenu;
		}
		if (PT.utils.portal.menus) {
			for ( var k in PT.utils.portal.menus) {
				PT.utils.portal.menus[k].remove();
			}
			PT.utils.portal.menus = {};
		}
		if (!this.view)
			return;
		var cont = $('#__SPOCMI0020101__').instance('cont');
		if (cont && cont.treeView) {
			cont.treeView.reset(true);
		}
		this.view.empty().hide();
		this.controller.hide();
		delete this.view;
	},
	show : function() {
		if (this.view.css('display') != 'none')
			return;
		this.view.show();
		this.controller.show();
	},

	openMenuItem : function(item, cb) {
		var self = this;
		if (!this.view) {
			if (PT.utils.portal.selectedMenu) {
				PT.utils.portal.selectedMenu = null;
				delete PT.globalVars.selectedMenu;
			}
			this.init(function() {
				self.openMenuItem(item, cb);
				self.headerController.layoutSubviews();
			});
		} else {
			this.show();
			this.controller.openMenuItem(item);
			self.headerController.layoutSubviews();
			self.menuController.contentOffset(self.menuController.contentOffset());
			if (cb)
				cb();
		}
	}
};

PT.js = {
	plugins : {
		menu : {},
		listview : {},
		slideshow : {}
	},
	dragObject : undefined,
	popup : {
		view : undefined,
		show : function(obj, animated) {
			if (PT.js.popup.view != obj) {
				PT.js.popup.hide(animated);
				PT.js.popup.view = obj;
			}
			$('body').append(obj);
			if (animated) {
				obj.stop();
				obj.css({
					opacity : 0
				});
				obj.animate({
					opacity : 1
				}, {
					duration : 400
				})
			}
		},
		hide : function(animated) {
			if (PT.js.popup.view) {
				if (animated) {
					PT.js.popup.view.finish();
					PT.js.popup.view.animate({
						opacity : 0
					}, {
						duration : 400,
						complete : function() {
							if (PT.js.popup.view.data('object')) {
								PT.js.popup.view.data('object').dismiss();
							} else {
								PT.js.popup.view.detach();
								PT.js.popup.view.trigger('dismiss');
							}
							PT.js.popup.view = null;
						}
					});
				} else {
					if (PT.js.popup.view.data('object')) {
						PT.js.popup.view.data('object').dismiss();
					} else {
						PT.js.popup.view.detach();
						PT.js.popup.view.trigger('dismiss');
					}
					PT.js.popup.view = null;
				}
			}
		}
	},
	tooltip : {
		view : $('<div/>').addClass('nepview tooltip'),
		show : function(element, loc) {
			loc.top = element.offset().top + element.outerHeight() + 5;
			$('body').append($.js.tooltip.view);
			$.js.tooltip.view.show().css(loc);
		},
		hide : function() {
			$.js.tooltip.view.detach();
		}
	}
};

/*******************************************************************************
 * Utils - Portlets
 ******************************************************************************/
PT.utils.portlet.validate = function() {

}

PT.utils.portlet.save = function(callback) {
	var programId = PT.globalVars.settings.type == 'univ' ? 'P000152' : 'P000252' ;
	var alarms = this.alarms.objects.slice(1).filter(function(p,idx){
		if ( p.element ) {
			p.properties.prtletOrdr = idx;
		}
		return p.element;
	}).sort(function(p1,p2){
		return p1.element.offset().left - p2.element.offset().left;
	});
	alarms = this.alarms.objects.filter(function(p){
		return !p.element
	}).concat(alarms).map(function(p,idx){
		if ( !p.properties.rowStatus && p.properties.prtletOrdr != idx ) {
			p.properties.rowStatus = 'update';
		} else if ( p.properties.rowStatus ) {
			p.properties.rowStatus = p.properties.rowStatus == 'new' ? 'insert' : p.properties.rowStatus;
		}
		return p.properties.rowStatus ? {
			rowStatus: p.properties.rowStatus,
			prtletId: p.properties.prtletId,
			prtletSz: '0000',
			prtletOrdr: idx,
			frstRegistProgrmId: programId,
			lastUpdtProgrmId: programId
		} : undefined;
	}).filter(function(p){
		return p;
	});
	for ( var pId in this.alarms.removedObjects ) {
		var p = this.alarms.removedObjects[pId];
		alarms.unshift( {
			rowStatus: 'delete',
			prtletId: p.properties.prtletId,
		});
	}

	var cnt = 0;
	var blocks = this.blocks.objects.filter(function(p,idx){
		if( p.element && !(p instanceof PT.views.PortletEmptyView) )
		{
			p.properties.prtletOrdr = cnt++;
			return true;
		}
		return false;
	}).sort(function(p1,p2){
		return p1.positionIndex(4) - p2.positionIndex(4);
	});
	blocks = blocks.concat(this.blocks.objects.filter(function(p){
		return !p.element;
	})).map(function(p,idx){
		if ( !p.properties.rowStatus && p.properties.prtletOrdr != idx ) {
			p.properties.rowStatus = 'update';
		} else if ( p.properties.rowStatus ) {
			p.properties.rowStatus = p.properties.rowStatus == 'new' ? 'insert' : p.properties.rowStatus;
		}
		var size = p._position ? (1<<(p._position.width-1)).toString(2).pad('0',4) : (p.properties.prtletBassSz || p.properties.prtletSz);
		if ( !p.properties.rowStatus && p.properties.prtletSz != size ) {
			p.properties.rowStatus = 'update';
		}
		return p.properties.rowStatus ? {
			rowStatus: p.properties.rowStatus,
			prtletId: p.properties.prtletId,
			prtletSz: size,
			prtletOrdr: idx,
			frstRegistProgrmId: programId,
			lastUpdtProgrmId: programId
		} : undefined;
	}).filter(function(p){
		return p;
	});

	for ( var pId in this.blocks.removedObjects) {
		var p = this.blocks.removedObjects[pId];
		blocks.unshift({
			rowStatus : 'delete',
			prtletId : p.properties.prtletId,
		});
	}

	var cmd = PT.globalVars.settings.type == 'univ' ? "saveUnivPrtletLayout.json" :  "saveUnivUserPrtletLayout.json";
	N({
		portlets: alarms.concat(blocks),
		frstRegistProgrmId: programId,
		lastUpdtProgrmId: programId
	}).comm(PT.consts.context + '/pt/PrtletCtr/' + cmd).submit(function(data){
		if ( callback ) callback();
	});
}

PT.utils.portlet.alarms.refresh = function(){
	var cont = $('#__SPOCMI00101__').instance('cont');
	cont.NoticeBar.refresh();
},

PT.utils.portlet.alarms._init = function(callback,forMobile,taskAlarms) {
	var isEditMode = PT.globalVars.settings.mode == 'edit';
	var cmd = PT.globalVars.settings.type == 'univ' ? "getUnivPrtletList.json" :  "getUnivUserPrtletList.json";
	var self = this;
	this._tasks = {};
	if ( taskAlarms ) {
		for( var k in taskAlarms ){
			taskAlarms[k] = parseInt(taskAlarms[k]);
		}
	}
	N({
		type: 'alarm',
		mobileUseAt: forMobile ? '1' : undefined
	}).comm(PT.consts.context + '/pt/PrtletCtr/' + cmd).submit(function(data){
		if ( data == null || data.length == 0 ) {
			callback([],0);
			return;
		};
		bgcount = 0;
		if (isEditMode) {
			var ep = new PT.views.PortletAlarmEmptyView($('<div/>'), null);
			self.objects.push(ep);
		}
		for( var i = 0; i < data.length; i++ ) {
			if ( PT.globalVars.settings.type != 'univ') {
				if ( data[i].sysMenuNo && !PT.globalVars.menu[ data[i].sysMenuNo ] ) {
					continue;
				}
				var prtletId = data[i].prtletId;
				if ( !isEditMode ) {
					if (( !PT.globalVars.settings.constants.bmsEnabled
							|| ( PT.globalVars.userInfo.userOriginSeCode == 'NCMB0023N00020' && PT.globalVars.userInfo.clsfCode != 'NCMA0037N00110'	) )
						&& ( prtletId == 'PT00000003' || prtletId == 'PT00000004' || prtletId == 'PT00000005'
							|| prtletId == 'PT00000006' || prtletId == 'PT00000007' || prtletId == 'PT00000008' ) )  {
						continue;
					}
				}
			}
			var p = PT.views.PortletView.createFactory(data[i]);
			if ( p.properties.sysMenuNo ) {
				p.properties.link = {
						cmd: 'menu',
						mId: p.properties.sysMenuNo
					};
				if ( p.properties.sysMenuNo == 'M000102' )
				{
					p.properties.link.tIdx = 1;
				}
			} else {
				switch (p.properties.prtletId) {
				case "PT00000003": // 결재대기
					p.properties.link = {
						IS_POPUP : 'Y',
						DOC_TYPE : 'BMSPAGE',
						VIEW_TYPE : 'FULL',
						VIEW_PAGE : 'MGRP_ONLINE',
						INITIAL_MENU : 'DCT_PROCREPORT',
					};
					p.properties.badge = taskAlarms.apprwait || 0;
					self._tasks['apprwait'] = p;
					break;
				case "PT00000004": // 발송대기
					p.properties.link = {
						IS_POPUP : 'Y',
						DOC_TYPE : 'BMSPAGE',
						VIEW_TYPE : 'FULL',
						VIEW_PAGE : 'MGRP_ONLINE',
						INITIAL_MENU : 'DCT_DCH_WIL',
					}
					p.properties.badge = taskAlarms.examproc || 0;
					self._tasks['examproc'] = p;
					break;
				case "PT00000005": // 접수대기
					p.properties.link = {
						IS_POPUP : 'Y',
						DOC_TYPE : 'BMSPAGE',
						VIEW_TYPE : 'FULL',
						VIEW_PAGE : 'MGRP_ONLINE',
						INITIAL_MENU : 'DCT_ACT_WIL',
					};
					p.properties.badge = taskAlarms.recvwait || 0;
					self._tasks['recvwait'] = p;
					break;
				case "PT00000006": // 공람대기
					p.properties.link = {
						IS_POPUP : 'Y',
						DOC_TYPE : 'BMSPAGE',
						VIEW_TYPE : 'FULL',
						VIEW_PAGE : 'MGRP_ONLINE',
						INITIAL_MENU : 'DCT_SHARE_RECEIVE',
					};
					p.properties.badge = taskAlarms.publicwait || 0;
					self._tasks['publicwait'] = p;
					break;
				case "PT00000007": // 처리할 메모
					p.properties.link = {
						IS_POPUP : 'Y',
						DOC_TYPE : 'BMSPAGE',
						VIEW_TYPE : 'FULL',
						VIEW_PAGE : 'MGRP_MEM',
					}
					p.properties.badge = taskAlarms.todomemocnt || 0;
					self._tasks['todomemocnt'] = p;
					break;
				case "PT00000008": // 내부업무메일
					p.properties.link = {
						IS_POPUP : 'Y',
						DOC_TYPE : 'BMSPAGE',
						VIEW_TYPE : 'FULL',
						VIEW_PAGE : 'MGRP_WCM',
					};
					p.properties.badge = taskAlarms.listCntNotRead || 0;
					self._tasks['listCntNotRead'] = p;
					break;
				}
			}
			if (parseInt(p.properties.badge) == -1)
				continue;

			self.objects.push(p);

			bgcount += p.properties.badge || 0;
			p.element.mouseclick(p, function(e) {
				PT.utils.url.open(e.data.properties.link);
			});
		}
		callback(self.objects,bgcount);
		PT.events.NotificationCenter.postNotification('AlarmPortletsLoaded', self.objects, bgcount );
	});
}

PT.utils.portlet.alarms.load = function(callback, forMobile, bmsArgs) {
	var self = this;
	this.objects = [];
	this.removedObjects = {};
	self._init(callback, forMobile, {});
}

PT.utils.portlet.alarms.refreshBadges = function(sysMenuNo) {
	if ( sysMenuNo ) {
		for( var i = 0 ; i < this.objects.length; i++ ){
			if ( this.objects[i].properties.sysMenuNo == sysMenuNo ) {
				var cont = N(this.objects[i].element.children('[id]')).instance('cont');
				if ( cont && cont.refresh ) {
					cont.refresh();
				}
				break;
			}
		}
	} else {
		var self = this;
		var cnt = 0;
		var total = 0;
		for( var i = 0 ; i < this.objects.length; i++ ){
			var cont = N(this.objects[i].element.children('[id]')).instance('cont');
			total++;
			cont.refresh(function(){
				cnt++;
				if ( cnt >= total ) {
					PT.events.NotificationCenter.postNotification("AlarmPortletsLoaded");
				}
			});
		}
	}
}

PT.utils.portlet.alarms.remove = function(p) {
	var idx = -1;
	for (var i = 0; i < this.objects.length; i++) {
		if (this.objects[i].properties.prtletId == p.properties.prtletId) {
			idx = i;
			break;
		}
	}
	if (idx >= 0) {
		var p = this.objects.splice(idx, 1)[0];
		if (p.properties.rowStatus != 'new') {
			this.removedObjects[p.properties.prtletId] = p;
			p.properties.rowStatus = 'delete';
		}
		p.element.remove();
	}
}


PT.utils.portlet.alarms.insert = function(list, callback) {
	for (var i = 0; i < list.length; i++) {
		var pId = list[i].prtletId;
		p = {
			properties : list[i]
		}
		if (this.removedObjects[pId]) {
			p.properties.rowStatus = "update";
			delete this.removedObjects[pId];
		} else {
			p.properties.rowStatus = "insert";
		}
		this.objects.push(p);
	}
	PT.utils.portlet.save(callback);
}

PT.utils.portlet.blocks.load = function(callback,forMobile) {
	this.objects = [];
	this.removedObjects = {};
	var isEditMode = PT.globalVars.settings.mode  == 'edit';
	var cmd = PT.globalVars.settings.type  == 'univ' ? "getUnivPrtletList.json" :  "getUnivUserPrtletList.json";
	var self = this;
	N({
		type: 'portlet',
		mobileUseAt: forMobile ? '1' : undefined
	}).comm(PT.consts.context + '/pt/PrtletCtr/' + cmd).submit(function(data){
		if ( data == null ||  data.length == 0 ) {
			callback([]);
			return;
		}
		for( var i = 0; i < data.length; i++ ) {
			if (  PT.globalVars.settings.type != 'univ' ) {
				if ( data[i].sysMenuNo == 'HRHFBDB00101' ) { // 근무상황
					var mId = PT.globalVars.userInfo.sklstfSeCode == 'NHRA0013N00010' ? 'HRHFBDB00101' : 'HRHFCDB00101';
					if ( mId == 'HRHFCDB00101' && PT.globalVars.userInfo.hrUnitSeCode == 'NHRB0114N00020'  ) {
						mId = 'HRHFDDB00101';
					}
					data[i].sysMenuNo  = mId;
				} else if ( data[i].sysMenuNo == 'HRHFCDC00101' ) { // 초과근무
					var mId = PT.globalVars.userInfo.sklstfSeCode == 'NHRA0013N00010' ? '__nomenu__' : 'HRHFCDC00101';
					if ( mId == 'HRHFCDC00101' && PT.globalVars.userInfo.hrUnitSeCode == 'NHRB0114N00020'  ) {
						mId = 'HRHFDDC00101';
					}
					data[i].sysMenuNo  = mId;
				}
				if ( data[i].sysMenuNo && !PT.globalVars.menu[ data[i].sysMenuNo ] ) {

					continue;
				}
				else if ( !isEditMode && ( !PT.globalVars.settings.constants.bmsEnabled
						|| (PT.globalVars.userInfo.userOriginSeCode == 'NCMB0023N00020' && PT.globalVars.userInfo.clsfCode != 'NCMA0037N00110'	 ) )
						&& ( data[i].prtletId == 'PT00000018' ||  data[i].prtletId == 'PT00000019' ) ) {
					continue;
				}
			}
			var p = PT.views.PortletView.createFactory(data[i]);
			self.objects.push(p);
		}
		callback(self.objects);
	});
}

PT.utils.portlet.blocks.remove = function(p) {
	var idx = -1;
	for (var i = 0; i < this.objects.length; i++) {
		if (this.objects[i].properties.prtletId == p.properties.prtletId) {
			idx = i;
			break;
		}
	}
	if (idx >= 0) {
		var p = this.objects.splice(idx, 1)[0];
		if (p.properties.rowStatus != 'new') {
			this.removedObjects[p.properties.prtletId] = p;
			p.properties.rowStatus = 'delete';
		}
		p.remove();
		p.hide();
	}
}

PT.utils.portlet.blocks.insert = function(list, callback) {
	for (var i = 0; i < list.length; i++) {
		var pId = list[i].prtletId;
		p = {
			properties : list[i]
		}
		if (this.removedObjects[pId]) {
			p.properties.rowStatus = "update";
			delete this.removedObjects[pId];
		} else {
			p.properties.rowStatus = "insert";
		}
		this.objects.push(p);
	}
	PT.utils.portlet.save(callback);
}

/*******************************************************************************
 * Search
 ******************************************************************************/

PT.text.Search = function() {
	this._koDicTable = {};
	var values = ['ㄱ','ㄲ','ㄴ','ㄷ','ㄸ','ㄹ','ㅁ','ㅂ','ㅃ','ㅅ','ㅆ','ㅇ','ㅈ','ㅉ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
	var valueList = ['가','까','나','다','따','라','마','바','빠','사','싸','아','자','짜','차','카','타','파','하'];
	var code = '가'.charCodeAt(0);
	for ( var i = 0 ; i < values.length; i++ ) {
		var c = values[i];
		var begin = valueList[i];
		code = begin.charCodeAt(0);
		var until = String.fromCharCode(code + 588 - 1);
		this._koDicTable[c] = '[' + begin + "-" + until + ']';
		for( var j = 0 ; j < 21 ; j++ ) {
			begin = String.fromCharCode(code);
			until = String.fromCharCode(code+27);
			this._koDicTable[begin] = '[' + begin + '-' + until + ']';
			code+=28;
		}
	}
	this._koDicTable['ㄳ'] = this._koDicTable['ㄱ'] + this._koDicTable['ㅅ'];
	this._koDicTable['ㄵ'] = this._koDicTable['ㄴ'] + this._koDicTable['ㅈ'];
	this._koDicTable['ㅄ'] = this._koDicTable['ㅂ'] + this._koDicTable['ㅅ'];
	this._koDicTable['ㄺ'] = this._koDicTable['ㄹ'] + this._koDicTable['ㄱ'];
	this._koDicTable['ㄻ'] = this._koDicTable['ㄹ'] + this._koDicTable['ㅁ'];
	this._koDicTable['ㄼ'] = this._koDicTable['ㄹ'] + this._koDicTable['ㅂ'];
	this._koDicTable['ㄽ'] = this._koDicTable['ㄹ'] + this._koDicTable['ㅅ'];
	this._koDicTable['ㄾ'] = this._koDicTable['ㄹ'] + this._koDicTable['ㅌ'];
	this._koDicTable['ㄿ'] = this._koDicTable['ㄹ'] + this._koDicTable['ㅍ'];
	this._koDicTable['ㅀ'] = this._koDicTable['ㄹ'] + this._koDicTable['ㅎ'];
	this._koDicTable['ㅄ'] = this._koDicTable['ㅂ'] + this._koDicTable['ㅅ'];
	this._lastCharList  = [null, "ㄱ", "ㄲ", "ㄳ", "ㄴ", "ㄵ", "ㄶ", "ㄷ", "ㄹ", "ㄺ", "ㄻ", "ㄼ", "ㄽ",
					"ㄾ", "ㄿ", "ㅀ", "ㅁ", "ㅂ", "ㅄ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ"];
	this._lastCharOffsets = [undefined, undefined, [1,'ㄱ'], [2,'ㅅ'], undefined, [1,'ㅈ'], [2,'ㅎ'],
					undefined, undefined,
					[1,'ㄱ'], [2,'ㅁ'],[3,'ㅂ'],[4,'ㅅ'], [5,'ㅌ'],[6,'ㅍ'],[7,'ㅎ'],
					undefined,undefined,[1, 'ㅅ'],undefined, [1, 'ㅅ']];
	if ( arguments.length == 1 ) {
		this.compile(arguments[0]);
	}
}

PT.text.Search.prototype._decomposeKoreanChar = function(c) {
	var code = c.charCodeAt(0) - '가'.charCodeAt(0);
	if (code > 0) {
		var idx = code % 28;
		if (this._lastCharList[idx] == null) {
			return this._koDicTable[c];
		}
		var append;
		var p;
		if (this._lastCharOffsets[idx]) {
			append = this._lastCharOffsets[idx][1];
			idx = this._lastCharOffsets[idx][0];
			append = this._koDicTable[append];
			p = this._koDicTable[String.fromCharCode(c.charCodeAt(0) - code
					% 28)];
		} else {
			append = this._koDicTable[this._lastCharList[idx]] + '?';
			p = '[' + String.fromCharCode(c.charCodeAt(0) - idx) + '-' + c
					+ ']';
		}
		return p + append;
	}
	return this._koDicTable[c] ? this._koDicTable[c] : c;
}

PT.text.Search.prototype.compile = function(query, options) {
	if (!query || query.length == 0) {
		delete this._regexp;
		return;
	}
	var q;
	var pattern = '';
	var hasPattern = false;

	if (arguments.length < 2) {
		options = "g";
	}

	for (var i = 0; i < query.length - 1; i++) {
		if (this._koDicTable[query[i]]) {
			pattern += this._koDicTable[query[i]];
			hasPattern = true;
		} else {
			pattern += query[i];
		}
	}
	var lastChar = query[query.length - 1];
	var p = this._decomposeKoreanChar(lastChar);
	hasPattern = hasPattern || p != lastChar;
	pattern += p;
	this._regexp = new RegExp(pattern, options);
	return this;
}

PT.text.Search.prototype.regexp = function() {
	return this._regexp;
}

PT.text.Search.prototype.test = function(value) {
	return this._regexp.test(value);
}

PT.text.Search.prototype.replace = function(value, cb) {
	return value.replace(this._regexp, cb);
}


/*******************************************************************************
 * View
 ******************************************************************************/
PT.views.View = function(element, props) {
	if (arguments.length == 0)
		return;
	this.properties = $.extend(true, {
		enabled : true,
		animated : false
	}, props);
	this.element = $(element);
	this.element.addClass('nepview');
	this.children = [];

	var self = this;
	this.element.click(function(e) {
		if (!self.properties.enabled) {
			e.stopImmediatePropagation();
			return false;
		}
	});

	if (this.properties.tooltip) {
		this.element.bind('mouseenter', function(e) {
			self._tooltipTimer = setTimeout(function() {
				self.showTooltip(e);
				self._tooltipTimer = null;
			}, 500);
		}).bind('mouseleave', function(e) {
			if (self._tooltipTimer) {
				clearTimeout(self._tooltipTimer);
			}
			self.hideTooltip();
		});
	}
	if (!this.properties.enabled) {
		this.enabled(false);
	}
};

PT.views.View.prototype.destroy = function() {

};

PT.views.View.prototype.enabled = function(value) {
	this.properties.enabled = value;
	if (value) {
		this.element.removeClass('disabled');
	} else {
		this.element.addClass('disabled');
	}
};

PT.views.View.prototype.appear = function(animated) {
	$('body').append(this.element);
	this.element.show();
};

PT.views.View.prototype.dismiss = function(animated) {
	this.element.detach();
	this.element.trigger('dismiss');
};

PT.views.View.prototype.frame = function(value) {
	if (arguments.length) {
		var css;
		if (arguments[0] instanceof PT.data.Rectangle
				|| arguments[0] instanceof PT.data.Point
				|| arguments[0] instanceof PT.data.Size) {
			css = value.css();
		} else {
			css = {};
			var keys = [ 'left', 'top', 'width', 'height' ];
			for (var i = 0; i < arguments.length; i++) {
				css[keys[i]] = arguments[i];
			}
		}
		this.element.css(css);
		this._layoutSubviews(true);
		this._draw();
		return;
	}
	var off = this.element.position();
	return new PT.data.Rectangle(off.left, off.top, this.element.outerWidth(),
			this.element.outerHeight());
};

["width", "height", "css", "offset", "addClass", "removeClass", "hasClass", "position",
 "insertAfter", "after", "before", "insertBefore", "remove", "empty",
 "data", "bind", "show", "hide", "appendTo", "append", "prepend", "prependTo",
 "animate", "outerWidth", "outerHeight", "parent"].forEach(function(v){
	PT.views.View.prototype[v] = function() {
		return this.element[v].apply(this.element, arguments);
	}
 });

PT.views.View.prototype._layoutSubviews = function() {

};

PT.views.View.prototype._draw = function() {

};

PT.views.View.prototype.showTooltip = function(e) {
	$.js.tooltip.view.empty();
	switch (typeof this.properties.tooltip) {
	case 'string':
		PT.js.tooltip.view.html(this.properties.tooltip);
		break;
	case 'function':
		PT.js.tooltip.view.append(this.properties.tooltip(this));
		break;
	default:
		PT.js.tooltip.view.append(this.properties.tooltip);
		break;
	}
	PT.js.tooltip.show(this.element, {
		left : e.clientX,
		top : e.clientY
	});
};

PT.views.View.prototype.hideTooltip = function() {
	$.js.tooltip.hide();
};

/******************************************************************************
 * PopoverController
******************************************************************************/
PT.views.PopoverController = function(element, props) {
	this.element = element;
	this.properties = $.extend({
		arrowDirection : PT.consts.ArrowDirection.Top,
		borderWidth : 10,
		padding : 5,
		arrowWidth : 0,
		arrowHeight : 0,
		arrowPadding : 0,
		marginTop : 0,
		marginLeft : 0,
		widthAdjust : 0,
		heightAdjust : 0,
		minHeight : 0,
		minWidth : 0,
		deleteChildAfterDismiss : false,
		align : PT.consts.Align.Auto
	// align against arrow
	}, props);
	this.element.addClass('nepview popover').css({
		borderWidth : this.properties.borderWidth,
		padding : this.properties.padding
	});
	this.children = {};
	this.children.container = $('<div/>').addClass('container').width('100%')
			.height('100%').appendTo(this.element);
	if (this.properties.arrow) {
		if (this.properties.arrow) {
			switch (typeof this.properties.arrow) {
			case 'function':
				this.children.arrow = this.properties.arrow();
				break;
			default:
				this.children.arrow = $(this.properties.arrow);
				break;
			}
			this.children.arrow.css({
				position : 'absolute'
			}).appendTo(this.element);
		}
	} else if (this.properties.arrowDirection && !this.children.arrow) {
		this.children.arrow = $('<div/>').appendTo(this.element);
		if (this.properties.arrowWidth) {
			this.children.arrow.width(this.properties.arrowWidth);
		}
	}
	this.element.click(function(e) {
		return false;
	});
};

PT.views.PopoverController.prototype._setPosition = function(target) {
	if ( !this.properties.arrow && this.children.arrow ) {
		this.children.arrow.attr('class', '');
	}
	var padding = ( this.properties.borderWidth + this.properties.padding );
	var off = target.offset();
	off.left -= this.properties.borderWidth;
	var width = this._maxWidth;
	var height = this._maxHeight;
	var eWidth = Math.max( this.properties.minWidth, this._contentView.width(), this.element.width() ) + padding * 2;
	var eHeight = Math.max( this.properties.minHeight, this._contentView.height(), this.element.height() ) +  padding * 2;
	var elementCSS = {};
	var arrowCSS = {};
	var arrowWidth = this.children.arrow ? (this.children.arrow.width() || this.properties.arrowWidth) : 0;
	var arrowHeight = this.children.arrow ? (this.children.arrow.height() || this.properties.arrowHight) : 0;
	var scrollTop = $(window).scrollTop();
	var scrollLeft = $(window).scrollLeft();

	if (!arrowHeight) {
		arrowHeight = arrowWidth;
	}
	var arrowDirection = PT.consts.ArrowDirection;
	var selectedArrowDirection = this.properties.arrowDirection;
	if ( this.properties.arrowDirection == arrowDirection.Auto ) {
		var space = [
		    [ off.top - $(window).scrollTop(), arrowDirection.Bottom ],
		    [ $(window).width() - (off.left + eWidth - $(window).scrollLeft()), arrowDirection.Left ],
		    [ $(window).height() - (off.top + eHeight - $(window).scrollTop()), arrowDirection.Top ],
		    [ off.left - $(window).scrollLeft(), arrowDirection.Right ]
		];
		var mIdx = 0;
		for (var i = 1; i < space.length; i++) {
			if (space[i][0] > space[mIdx][0]) {
				mIdx = i;
			}
		}
		selectedArrowDirection = space[mIdx][1];
	}
	if ( !this.properties.arrow && this.children.arrow ) {
		this.children.arrow.addClass( selectedArrowDirection );
	}
	switch (selectedArrowDirection) {
	case arrowDirection.Top:
		elementCSS.top = off.top + target.outerHeight(true);
		if (arrowHeight && !(this.properties.align & PT.consts.Align.Top)) {
			elementCSS.top += arrowHeight;
		}
		break;
	case arrowDirection.Bottom:
		elementCSS.top = off.top - eHeight - arrowHeight;
		break;
	case arrowDirection.Left:
		elementCSS.left = off.left + target.outerWidth(true) + arrowWidth / 2;
		break;
	case arrowDirection.Right:
		elementCSS.left = off.left - eWidth - arrowWidth / 2;
		break;
	default:
		elementCSS.top = off.top + target.outerHeight(true);
		break;
	}
	if ( selectedArrowDirection == arrowDirection.Top
	  || selectedArrowDirection == arrowDirection.Bottom ) {
		if ( this.properties.percent !== undefined || this.properties.align == PT.consts.Align.Auto || (this.properties.align & PT.consts.Align.Center) ) {
			elementCSS.left = off.left + target.outerWidth(true)/2
				- ( this.properties.percent !== undefined ? (1-this.properties.percent) : 0.5 ) * eWidth;
			if ( elementCSS.left + eWidth > width ) {
				elementCSS.left = width - eWidth;
				arrowCSS.left = Math.min( eWidth, off.left - elementCSS.left + target.outerWidth()/2 - padding * 2);
			} else if ( elementCSS.left - scrollLeft < arrowWidth ) {
				elementCSS.left = this.properties.borderWidth + scrollLeft;
				arrowCSS.left = Math.max(arrowWidth, off.left - elementCSS.left + target.outerWidth()/2 - padding * 2);
			} else {
				arrowCSS.left = ( this.properties.percent !== undefined ? this.properties.percent : 0.5 ) * eWidth - padding*2;
			}
			arrowCSS.left -= arrowWidth/2;
			arrowCSS.left += this.properties.arrowPadding;
		} else if ( this.properties.align & PT.consts.Align.Left ) {
			elementCSS.left = off.left + this.properties.marginLeft;
			elementCSS.top += this.properties.marginTop;
			arrowCSS.left = this.properties.arrowPadding;
		}
		arrowCSS.top = '';
	} else {
		if ( this.properties.percent !== undefined || this.properties.align == PT.consts.Align.Auto || (this.properties.align & PT.consts.Align.Middle)  )
		{
			elementCSS.top = off.top + target.outerHeight(true)/2
				- ( this.properties.percent !== undefined ? 1-this.properties.percent : 0.5 ) * eHeight;
			if ( elementCSS.top + eHeight > height ) {
				elementCSS.top = height - eHeight - padding;
				arrowCSS.top = Math.min( eHeight, off.top - elementCSS.top + target.outerHeight()/2 - padding );
			} else if ( elementCSS.top - scrollTop < arrowHeight ) {
				elementCSS.top = this.properties.borderWidth + scrollTop;
				arrowCSS.top = Math.max(arrowHeight, off.top - elementCSS.top + target.outerHeight()/2 - padding * 2);
			} else {
				arrowCSS.top = ( this.properties.percent !== undefined ? this.properties.percent : 0.5 ) * eHeight-padding*2;
			}
			arrowCSS.top -= arrowHeight/2;
			arrowCSS.top += this.properties.arrowPadding;
		}
		else if ( this.properties.align & PT.consts.Align.Top )
		{
			elementCSS.top = off.top + arrowHeight;
			arrowCSS.top = this.properties.arrowPaddingLeft;
		}
		arrowCSS.left = '';
	}
	this.element.css(elementCSS);
	if (this.children.arrow) {
		this.children.arrow.css(arrowCSS);
	}
};

PT.views.PopoverController.prototype.contentView = function(content,button,arrowDir) {
	if( arguments.length ) {
		if ( this._contentView && !this.properties.deleteChildAfterDismiss ) {
			this._contentView.appendTo('body').hide();
		}

		if ( this.properties.width > 0 ) {
			this.element.width( this.properties.width + this.properties.widthAdjust  );
		} else {
			this.element.width( $(content).width() + this.properties.padding*2 + this.properties.widthAdjust );
		}
		this._maxWidth =  $(window).width() + $(window).scrollLeft(); // Math.max( $(document).width(), $(window).width());
		this._maxHeight = $(window).height() + $(window).scrollTop(); // Math.max( $(document).height(), $(window).height());
		if (typeof content == 'string') {
			this._contentView = $(content);
		} else {
			this._contentView = content;
		}
		this.children.container.empty().append(this._contentView.show());
		if (arrowDir) {
			this.properties.arrowDirection = arrowDir;
		}
		this.element.show();
		var self = this;
		self.element.data('object', self);
		self._setPosition(button);
		PT.js.popup.show(self.element, self.properties.animated);
		return;
	}
	return this._contentView;
};

PT.views.PopoverController.prototype.appear = function(animated) {
	$('body').append(this.element);
	this.element.show();
	if (animated) {
		this.element.stop();
		this.element.css({
			opacity : 0
		}).animate({
			opacity : 1
		}, {
			duration : 400
		});
	} else {
		this.element.css({
			opacity : 1
		}).show();
	}
};

PT.views.PopoverController.prototype.dismiss = function(animated) {
	var self = this;
	if (animated) {
		this.element.css({
			opacity : 1
		}).animate({
			opacity : 0
		}, {
			duration : 400,
			complete : function() {
				if (self.properties.deleteChildAfterDismiss) {
					if (this._contentView) {
						this._contentView.remove();
						delete this._contentView;
					}
				} else {
					this._contentView.appendTo('body').hide();
				}
				self.element.detach();
				self.element.trigger('dismiss');
			}
		});
	} else {
		this.element.hide();
		if (self.properties.deleteChildAfterDismiss) {
			if (this._contentView) {
				this._contentView.remove();
				delete this._contentView;
			}
		} else if (this._contentView) {
			this._contentView.appendTo('body').hide();
		}
		this.element.detach();
		this.element.trigger('dismiss');
	}
};


/******************************************************************************
 * Drag
******************************************************************************/
PT.views.Drag = function(element, props) {
	this.element = element;
	this.properties = $.extend(true, {
		threshold : 10,
		binding : true,
		enabled : true,
		horizontalEnabled : true,
		verticalEnabled : true,
		copy : false
	}, props);
	var self = this;
	this.target = this.element;

	this.target.addClass('draggable');
	this.element.mousedown(function(e) {
		if (!self.properties.enabled)
			return;
		if (e.which != 1)
			return;
		if ($(e.target).hasClass('draggable') && e.target != e.currentTarget)
			return true;
		self.resetDrag(e.clientX, e.clientY);
	});
	if (this.properties.binding) {
		this.element.bind('dragging', function(e, ptr, delta, position) {
			self.target.css(position);
			if (self._group) {
				self._group.forEach(function(v) {
					var off = v.offset();
					v.css({
						left : off.left + delta.x,
						top : off.top + delta.y
					});
				});
			}
		}).bind('dragDone', function(e, ptr, delta, position, lastDelta) {

		});
	}
};

PT.views.Drag.prototype.enabled = function(value) {
	if (arguments.length) {
		this.properties.enabled = value;
		if (!value) {
			PT.js.dragObject = null;
			this._startPoint = null;
			this._lastPoint = null;
			this._isDragging = false;
		}
		return;
	}
	return this.properties.enabled;
};

PT.views.Drag.prototype.group = function(value) {
	this._group = value;
};

PT.views.Drag.prototype.resetDrag = function(x, y) {
	PT.js.dragObject = this;
	this._startPoint = new PT.data.Point(x, y);
	this._lastPoint = null;
	this._isDragging = false;
};

PT.views.Drag.prototype.dragDone = function(x, y) {
	if (this._lastPoint) {
		var ptr = new PT.data.Point(x, y);
		var off = this.target.position();
		var delta = ptr['-'](this._lastPoint);
		var startDelta = ptr['-'](this._startPoint);
		var position = {
			left : off.left + delta.x,
			top : off.top + delta.y
		};
		this.element.trigger('dragDone', [ ptr, startDelta, position, delta ]);
		if (this.properties.copy) {
			this.target.remove();
			this.target = null;
		}
	}
	this._startPoint = null;
	this._lastPoint = null;
	this._isDragging = false;
};

PT.views.Drag.prototype.dragging = function(x, y) {
	if (!this.properties.enabled)
		return;
	var ptr = new PT.data.Point(x, y);
	if (!this._isDragging) {
		if (this._startPoint.distance(ptr) > this.properties.threshold) {
			this._lastPoint = new PT.data.Point(this._startPoint);
			this._isDragging = true;
			if (this.properties.copy) {
				if (typeof this.properties.copy == 'function') {
					this.target = this.properties.copy(this.element);
				} else if (this.properties.copy) {
					this.target = this.element.clone();
				}
				this.target.appendTo(this.element.parent());
				var pos = this.element.position();
				this.target.css({
					position : 'absolute',
					left : pos.left,
					top : pos.top
				});
			}
			this.element.trigger('dragStart', [ ptr, this.target ]);
		} else {
			return;
		}
	}
	var off = this.target.position();
	var delta = ptr['-'](this._lastPoint);
	delta.x = this.properties.horizontalEnabled ? delta.x : 0;
	delta.y = this.properties.verticalEnabled ? delta.y : 0;
	var position = {
		left : off.left + delta.x,
		top : off.top + delta.y
	};
	this.element.trigger('dragging', [ ptr, delta, position ]);
	this._lastPoint = ptr;
	return false;
};

/******************************************************************************
 * ScrollBarView
******************************************************************************/
PT.views.ScrollBarView = function(element, props) {
	PT.views.View.call(this, element, $.extend(true, {
		direction : PT.consts.Orientation.Vertical
	}, props));
	this.element.addClass('scrollbar ' + this.properties.direction);
	this.children.indicator = $('<div/>').appendTo(this.element).addClass(
			'indicator');

	this.children.indicator.click(function(e) {
		e.stopPropagation();
		return false;
	});
	var self = this;
	this.element.mouseclick(function(e) {
		var off = self.children.indicator.position();
		if (self.properties.direction == PT.consts.Orientation.Vertical) {
			if (e.offsetY < off.top) {
				self.element.trigger('scrollbar.pageDown');
			} else {
				self.element.trigger('scrollbar.pageUp');
			}
		} else {
			if (e.offsetX < off.left) {
				self.element.trigger('scrollbar.pageDown');
			} else {
				self.element.trigger('scrollbar.pageUp');
			}
		}
		return false;
	});
	this._drag = new PT.views.Drag(
			this.children.indicator,
			{
				horizontalEnabled : self.properties.direction == PT.consts.Orientation.Horizontal,
				verticalEnabled : self.properties.direction == PT.consts.Orientation.Vertical,
			});

	this.children.indicator.bind('dragStart', function(e, ptr) {

	}).bind('dragging', function(e, ptr, delta, position) {
		var v = 0;
		if (self.properties.direction == PT.consts.Orientation.Horizontal) {
			v = position.left / self._viewSize * self._contentSize;
		} else {
			v = position.top / self._viewSize * self._contentSize;
		}
		self.element.trigger('scrollbar.dragging', [ v ]);
		return false;
	}).bind('dragEnd', function(e) {
		return false;
	})
};

PT.views.ScrollBarView.prototype = new PT.views.View();

PT.views.ScrollBarView.prototype.sizes = function() {
	return {
		contentSize : this._contentSize,
		viewSize : this._viewSize,
		pageSize : this._pageSize
	};
};

PT.views.ScrollBarView.prototype.contentOffset = function(v, bounce) {
	if (arguments.length) {
		this._contentOffset = arguments[0];
		var p;
		var css = {};
		var page = this._pageSize;
		var max = this._viewSize - (bounce ? 10 : this._pageSize);
		p = Math.max(0, Math.min(max, this._contentOffset / this._contentSize
				* this._viewSize));
		if (bounce) {
			if (v < 0) {
				page = Math.max(10, this._pageSize + v);
			} else if (v > this._contentSize - this._viewSize) {
				v -= this._contentSize - this._viewSize;
				page = Math.max(10, this._pageSize - v);
				p = this._viewSize - page;
			}
		}
		if (this.properties.direction == PT.consts.Orientation.Horizontal) {
			css.left = p;
			css.height = '100%';
			css.width = page;
		} else {
			css.top = p;
			css.width = '100%';
			css.height = page;
		}
		this.children.indicator.css(css);
		return;
	}
	return this._contentOffset;
};

PT.views.ScrollBarView.prototype.contentSize = function() {
	if (arguments.length) {
		this._viewSize = this.properties.direction == PT.consts.Orientation.Horizontal ? this.element.width() : this.element.height();
		this._contentSize = arguments[0];
		this._pageSize = this._viewSize / this._contentSize * this._viewSize;
		this.children.indicator.width(this._pageSize);
		return;
	}
	return this._contentSize;
};

/******************************************************************************
 * ScrollView
******************************************************************************/
PT.views.ScrollView = function(element, props) {
	if (!arguments.length)
		return;
	PT.views.View.call(this, element, $.extend(true, {
		showHorizontalScrollIndicator : true,
		showVerticalScrollIndicator : true,
		horizontalMousewheel : false,
		pagingEnabled : false,
		velocityCoeff : 0.9,
		mouseWheelMultiply : 10,
		draggable : true,
		mousewheelStopPropagation : true
	}, props));
	var self = this;
	this.element.addClass('scroll');
	this._scrollable = {};
	if (this.properties.draggable) {
		this._drag = new PT.views.Drag(this.element, {
			binding : false
		});
	}
	this.element.scroll(function(e) {
		$(this).scrollTop(0).scrollLeft(0);
	});

	this._contentOffset = new PT.data.Point(0,0);
	this._contentSize = new PT.data.Size(0,0);
	this.children = {
		child: this.properties.child || this.element.children().eq(0),
		horizontalScrollIndicator: new PT.views.ScrollBarView( $('<div/>').appendTo(this.element), {
						direction: PT.consts.Orientation.Horizontal
					}),
		verticalScrollIndicator: new PT.views.ScrollBarView( $('<div/>').appendTo(this.element), {
						direction: PT.consts.Orientation.Vertical
					})
	};
	if ( !this.properties.showHorizontalScrollIndicator ) {
		this.children.horizontalScrollIndicator.element.hide();
	} else {
		this.children.horizontalScrollIndicator.element.bind('scrollbar.pageUp', function(e){
			self.pageUp(true,false);
			self.element.trigger('scrollview.offsetChanged', self._contentOffset);
			return false;
		}).bind('scrollbar.pageDown', function(e){
			self.pageDown(true,false);
			self.element.trigger('scrollview.offsetChanged', self._contentOffset);
			return false;
		}).bind('scrollbar.dragging', function(e,v){
			self.contentOffset( v, self._contentOffset.y );
			self.element.trigger('scrollview.offsetChanged', self._contentOffset);
			return false;
		});
	}
	if ( !this.properties.showVerticalScrollIndicator ) {
		this.children.verticalScrollIndicator.element.hide();
	} else {
		this.children.verticalScrollIndicator.element.bind('scrollbar.pageUp', function(e){
			self.pageUp(false,true);
			self.element.trigger('scrollview.offsetChanged', self._contentOffset);
			return false;
		}).bind('scrollbar.pageDown', function(e){
			self.pageDown(false,true);
			self.element.trigger('scrollview.offsetChanged', self._contentOffset);
			return false;
		}).bind('scrollbar.dragging', function(e,v){
			self.contentOffset( self._contentOffset.x, v);
			self.element.trigger('scrollview.offsetChanged', self._contentOffset);
			return false;
		});
	}
	this.element.mousewheel(function(e) {
		var mul = self.properties.mouseWheelMultiply;
		var deltaY = e.deltaY;
		var deltaX = e.deltaX;

		deltaY = isNaN(deltaY) ? 0 : deltaY;
		deltaX = isNaN(deltaX) ? 0 : deltaX;
		var pos = {
			x: self._contentOffset.x,
			y: self._contentOffset.y
		};
		if ( self.properties.horizontalMousewheel && self._scrollable.horizontal ) {
			if ( deltaY != 0 ) {
				self._moveBy(-deltaY*mul, 0 );
				self.element.trigger('scrollview.offsetChanged', self._contentOffset);
				if ( pos.x == self._contentOffset.x )
				{
					return !self.properties.mousewheelStopPropagation;
				}
				return false;
			}
			else if ( deltaX != 0 ) {
				self._moveBy(-deltaX*mul/50, 0 );
				self.element.trigger('scrollview.offsetChanged', self._contentOffset);
				if ( pos.y == self._contentOffset.y )
				{
					return !self.properties.mousewheelStopPropagation;
				}
				return false;
			}

		} else if ( (deltaX != 0 || deltaY != 0) && self._scrollable.vertical ) {
			self._moveBy( -deltaX*mul, -deltaY*mul);
			self.element.trigger('scrollview.offsetChanged', self._contentOffset);
			if (  pos.x == self._contentOffset.x &&  pos.y == self._contentOffset.y ) {
				return !self.properties.mousewheelStopPropagation;
			}
			return false;
		}
	});

	if (this.properties.draggable) {
		var draggingPos;
		var lastTime = 0;
		this._timer = null;
		var dragging = false;

		this.children.child.mouseup(function(e) {
			if (!self.properties.draggable)
				return;
			if (PT.js.dragObject) {
				PT.js.dragObject.dragDone(e.clientX, e.clientY, e);
				return !dragging;
			}
		});

		this.element.bind('dragStart', function(e, ptr, obj) {
			lastTime = Date.now();
			draggingPos = ptr;
		}).bind(
				'dragging',
				function(e, ptr, delta, position) {
					if (!self.properties.draggable)
						return;
					dragging = true;
					self._stopKineticScroll();
					self._moveBy(-delta.x, -delta.y, true);
					self.element.trigger('scrollview.offsetChanged',
							self._contentOffset);
					return false;
				}).bind('dragDone',
				function(e, ptr, delta, position, lastDelta) {
					if (!self.properties.draggable)
						return;
					var sec = (Date.now() - lastTime) / 1000;
					if (sec > 0.5) {
						self._checkBounce();
						return;
					}
					var diff = Math.max(10, sec);
					var lastVelocity = {
						x : (draggingPos.x - ptr.x) / diff,
						y : (draggingPos.y - ptr.y) / diff
					};
					if (!self.properties.showHorizontalScrollIndicator) {
						lastVelocity.x = 0;
					}
					if (!self.properties.showVerticalScrollIndicator) {
						lastVelocity.y = 0;
					}
					self._kineticScroll(lastVelocity);
					dragging = false;
					return false;
				});
	}
	this._animate = new Animation();
};

PT.views.ScrollView.prototype = new PT.views.View();

PT.views.ScrollView.prototype.frame = function() {
	PT.views.View.prototype.frame.apply(this, arguments);
	this.contentSize(this._contentSize.width, this._contentSize.height);
	this.contentOffset(this._contentOffset.x, this._contentOffset.y);
};

PT.views.ScrollView.prototype._stopKineticScroll = function() {
	this._animate.stop();
};

PT.views.ScrollView.prototype.contentSize = function(width, height) {
	if (arguments.length) {
		this._contentSize = new PT.data.Size(width, height);
		this._sizes = {};
		this._bounceRange = {};
		if (this.properties.showHorizontalScrollIndicator) {
			if (this.element.width() >= width) {
				this.element.removeClass('horizontal');
				this.children.horizontalScrollIndicator.hide();
				this._bounceRange.x = [ 0, 0 ];
			} else {
				this.element.addClass('horizontal');
				this.children.horizontalScrollIndicator.show();
				this.children.horizontalScrollIndicator.contentSize(width);
				this._sizes.horizontal = this.children.horizontalScrollIndicator.sizes();
				var hpad = this._sizes.horizontal.viewSize * 2 / 3;
				this._bounceRange.x = [-hpad, this._sizes.horizontal.contentSize - this._sizes.horizontal.viewSize + hpad ];
			}
		} else {
			this._bounceRange.x = [ 0, 0 ];
		}
		if (this.properties.showVerticalScrollIndicator) {
			if (this.element.height() >= height) {
				this.element.removeClass('vertical');
				this.children.verticalScrollIndicator.hide();
				this._bounceRange.y = [ 0, 0 ];
			} else {
				this.element.addClass('vertical');
				this.children.verticalScrollIndicator.show();
				this.children.verticalScrollIndicator.contentSize(height);
				this._sizes.vertical = this.children.verticalScrollIndicator.sizes();
				var vpad = this._sizes.vertical.viewSize * 2 / 3;
				this._bounceRange.y = [-vpad, this._sizes.vertical.contentSize - this._sizes.vertical.viewSize + vpad ];
			}
		} else {
			this._bounceRange.y = [ 0, 0 ];
		}
		this._scrollable = {
			vertical : this._contentSize.height > this.element.height(),
			horizontal : this._contentSize.width > this.element.width()
		};
		this._layoutSubviews();
		this.contentOffset(this._contentOffset.x, this._contentOffset.y, false);
		return;
	}
	return this._contentSize;
};

PT.views.ScrollView.prototype.measureContentSize = function() {
	this._contentOffset.x = 0;
	this._contentOffset.y = 0;
	this.contentSize(this.children.child.width(), this.children.child.height());
}

PT.views.ScrollView.prototype.contentOffset = function(x, y, animated) {
	if (arguments.length) {
		this._stopKineticScroll();
		this._moveTo(x, y);
		return;
	}
	return this._contentOffset;
};

PT.views.ScrollView.prototype.pageUp = function(x, y, animated) {
	this._stopKineticScroll();
	if (x) {
		this.contentOffset(this._contentOffset.x + this._sizes.horizontal.viewSize, this._contentOffset.y, animated);
	}
	if (y) {
		this.contentOffset(this._contentOffset.x, this._contentOffset.y + this._sizes.vertical.viewSize, animated);
	}
};

PT.views.ScrollView.prototype.pageDown = function(x, y, animated) {
	this._stopKineticScroll();
	if (x) {
		this.contentOffset(this._contentOffset.x - this._sizes.horizontal.viewSize, this._contentOffset.y, animated);
	}
	if (y) {
		this.contentOffset(this._contentOffset.x, this._contentOffset.y - this._sizes.vertical.viewSize, animated);
	}
};

PT.views.ScrollView.prototype._layoutSubviews = function() {

};

PT.views.ScrollView.prototype._moveTo = function(x,y, bounce) {
	var vsize = this._sizes.vertical || { viewSize: this._contentSize.height };
	var hsize = this._sizes.horizontal || { viewSize: this._contentSize.width };
	if ( bounce ) {
		this._contentOffset.x = Math.max( this._bounceRange.x[0],
									Math.min( x, this._bounceRange.x[1]));
		this._contentOffset.y = Math.max( this._bounceRange.y[0],
									Math.min( y, this._bounceRange.y[1]));
	} else {
		this._contentOffset.y = Math.min( Math.max(0, y), this._contentSize.height - (vsize.viewSize || this._contentSize.height));
		this._contentOffset.x = Math.min( Math.max(0, x), this._contentSize.width - (hsize.viewSize || this._contentSize.width));
	}
	this.children.child.css({
		marginTop: this._scrollable.vertical ? -this._contentOffset.y : 0,
		marginLeft: this._scrollable.horizontal ? -this._contentOffset.x : undefined
	});
	if (this.properties.showHorizontalScrollIndicator) {
		this.children.horizontalScrollIndicator.contentOffset(x, bounce);
	}
	if (this.properties.showVerticalScrollIndicator) {
		this.children.verticalScrollIndicator.contentOffset(y, bounce);
	}
};

PT.views.ScrollView.prototype._moveBy = function(dx, dy, bounce) {
	this._moveTo(this._contentOffset.x + dx, this._contentOffset.y + dy, bounce);
};

PT.views.ScrollView.prototype._kineticScroll = function(velocity) {
	var self = this;
	var coeff = this.properties.velocityCoeff;
	this._animate.start(function() {
		if (Math.abs(velocity.x) >= 2 || Math.abs(velocity.y) >= 2) {
			velocity.x *= coeff;
			velocity.y *= coeff;
			velocity.x = Math.abs(velocity.x) >= 1 ? velocity.x : 0;
			velocity.y = Math.abs(velocity.y) >= 1 ? velocity.y : 0;
			self._moveBy(velocity.x, velocity.y, true);
			if (Math.abs(velocity.x) > 0
					&& (self._contentOffset.x <= self._bounceRange.x[0] || self._contentOffset.x >= self._bounceRange.x[1])) {
				velocity.x = 0;
			}
			if (Math.abs(velocity.y) > 0
					&& (self._contentOffset.y <= self._bounceRange.y[0] || self._contentOffset.y >= self._bounceRange.y[1])) {
				velocity.y = 0;
			}
		} else {
			self._stopKineticScroll();
			self._checkBounce();
		}
	});
};

PT.views.ScrollView.prototype._checkBounce = function() {
	var self = this;
	var vsize = this._sizes.vertical || {
		viewSize : this._contentSize.height
	};
	var hsize = this._sizes.horizontal || {
		viewSize : this._contentSize.width
	};
	var targetX = self._contentOffset.x;
	var targetY = self._contentOffset.y;
	if (self._contentOffset.x < 0) {
		targetX = 0;
	} else if (self._contentOffset.x > hsize.contentSize - hsize.viewSize) {
		targetX = hsize.contentSize - hsize.viewSize;
	}
	if (self._contentOffset.y < 0) {
		targetY = 0;
	} else if (self._contentOffset.y > vsize.contentSize - vsize.viewSize) {
		targetY = vsize.contentSize - vsize.viewSize;
	}
	if (targetX != self._contentOffset.x || targetY != self._contentOffset.y) {
		var roomX = self._contentOffset.x - targetX;
		var roomY = self._contentOffset.y - targetY;
		var duration = Math.max(Math.abs(roomX) / hsize.viewSize, Math.abs(roomY) / vsize.viewSize) * 400;
		var startTime = Date.now();
		var beginPoint = {
			x : self._contentOffset.x,
			y : self._contentOffset.y
		};
		this._animate.start(function() {
			var p = (Date.now() - startTime) / duration;
			if (p >= 1) {
				self._stopKineticScroll();
				self._moveTo(targetX, targetY);
				self.element.trigger('scrollview.offsetChanged', self._contentOffset);
			} else {
				self._moveTo(beginPoint.x - roomX * p, beginPoint.y - roomY * p, true);
			}
		});
	}
};

/******************************************************************************
 * Tabbar
******************************************************************************/
PT.views.TabBarView = function(element,props) {
	PT.views.View.call( this, element, $.extend(true,{
		icon: '&#x2603',
		showContextmenu: false,
		direction: 'horizontal',
		position: 'top',
		margin: 2,
		close: undefined
	}, props));
	this.element.addClass('tabbar ' + this.properties.direction + ' ' + this.properties.position);
	if (this.properties.margin) {
		if (this.properties.direction == 'horizontal') {
			this.element.css({
				marginLeft : this.properties.margin,
				marginRight : this.properties.margin
			});
		} else {
			this.element.css({
				marginTop : this.properties.margin,
				marginBottom : this.properties.margin
			});
		}
	}

	this.children.container = this.element;
	if (this.properties.icon) {
		var icon = $('<div/>').css({
			display : 'table-cell'
		}).addClass('icon').appendTo(this.children.container);
		if (this.properties.icon.indexOf('.jpg') > 0
				|| this.properties.icon.indexOf('.png') > 0) {
			$('<img/>', {
				src : this.properties.icon,
				alt : '탭아이콘'
			}).appendTo(icon);
		} else {
			icon.html(this.properties.icon);
		}
	}
	var self = this;
	var txt = this.properties.data.title || this.properties.data.name;
	txt = txt.replace('/', '&#47' );
	var title = $('<a/>', { href: '#'}).css({display:'table-cell'})
				.css({display:'table-cell'})
				.addClass('title')
				.html( txt ).appendTo(this.children.container).click(function(e){
					e.preventDefault();
					self.element.trigger('tabbar.selected');
					return false;
				});
	this.element.attr('title',txt);
	var self = this;
	if (this.properties.close) {
		var close = $('<a/>', {
			href : '#'
		}).css({
			display : 'table-cell'
		}).addClass('close').appendTo(this.children.container);
		if (this.properties.close.indexOf('.jpg') > 0
				|| this.properties.close.indexOf('.png') > 0) {
			$('<img/>', {
				src : this.properties.icon,
				alt : '탭닫기'
			}).appendTo(close);
		} else {
			close.html(this.properties.close);
		}
		close.click(function(e) {
			e.preventDefault();
			self.element.trigger('tabbar.close');
			return false;
		});
	}

	this.children.container.hover(function() {
		self.children.container.addClass('hover');
	}, function() {
		self.children.container.removeClass('hover');
	});
};

PT.views.TabBarView.prototype = new PT.views.View();

PT.views.TabView = function(element,props) {
	var self = this;
	PT.views.View.call( this, element, $.extend(true,{
		direction: 'horizontal',
		position: 'top',
		hasMore: true,
		tabbar: {
			icon: undefined,
			margin: 2,
			close: undefined
		},
		sortable: true
	}, props));
	this.element.addClass('tabview ' + this.properties.direction +  ' ' + this.properties.position);
	this.activatedTabsInOrder = [];
	if (this.properties.tabbar.margin == 0) {
		this.element.addClass('nomargin');
	}
	this.children.tabbars = $('<div/>').addClass('tabbars').appendTo(
			this.element);
	if (this.properties.hasMore) {
		this.children.more = $('<a/>', {
			href : '#'
		}).addClass('more').click(function(e) {
			e.preventDefault();
			self._showHiddenTabBarList();
			return false;
		});
	}
	this.children.extraButtons = this.element.find('.buttons');
	if (this.children.extraButtons.children().length) {
		this.children.extraButtons.appendTo(this.element);
		this.children.buttonCloseAll = this.element.find('.closeall.button');
		if (this.children.buttonCloseAll.length) {
			this.children.buttonCloseAll.click(function(e) {
				self.closeAll();
			});
		}
	}

	this._selectedIndex = -1;
	this._tabbars = [];

	if (this.properties.showContextmenu) {
		this.children.contextmenu = $('<div/>').JSMenuView({
			direction : 'vertical',
			plugin : 'standard',
			data : [ {
				id : 0,
				name : '닫기'
			}, {
				id : 1,
				name : '다른탭 닫기'
			}, {
				id : 2,
				name : '모든탭 닫기'
			}, {
				id : 3,
				name : '왼쪽 모든탭 닫기'
			}, {
				id : 4,
				name : '오른쪽 모든탭 닫기'
			}, ]
		}).addClass('contextmenu').bind('dismiss', function(e) {
			self.element.find('.popup').removeClass('popup');
		}).bind('menu.itemClicked', function(e, item) {
			var tabbar = $(this).data('item');
			var idx;
			switch (item.id) {
			case 0: // close it
				self.removeTabBar(tabbar, self.properties.animated);
				break;
			case 1: // close the others
				self.removeTabBarsExceptFor([ tabbar ],
						self.properties.animated);
				break;
			case 2: // close all
				self.closeAll();
				break;
			case 3: // close left
				idx = self._tabbars.indexOf(tabbar);
				self.removeTabBarsExceptFor(self._tabbars.slice(idx),
						self.properties.animated);
				break;
			case 4: // close right
				idx = self._tabbars.indexOf(tabbar);
				self.removeTabBarsExceptFor(self._tabbars.slice(0,
						idx + 1), self.properties.animated);
				break;
			}
		});
	}
	if ( this.properties.direction == 'horizontal' ) {
		self._width = -1;
		PT.events.NotificationCenter.addObserver( this, 'WindowResized', function(e){
			self._width = -1;
			self._layoutSubviews(true);
		});
	}
	this.element.trigger('initialized');
};

PT.views.TabView.prototype = new PT.views.View();

PT.views.TabView.prototype.destroy = function() {
	PT.views.View.prototype.destroy.call(this);
	PT.events.NotificationCenter.removeObserver( this );
};

PT.views.TabView.prototype.closeAll = function() {
	this.element.trigger('tabview.closeAll');
	this._selectedIndex = -1;
	this.activatedTabsInOrder = [];
};

PT.views.TabView.prototype.frame = function(value) {
	if (this.properties.direction == 'vertical') {
		return PT.views.View.prototype.frame.apply(this, arguments);
	}
	if (arguments.length) {
		if (typeof arguments[0] == 'object') {
			this._width = value.width || -1;
		} else {
			this._width = arguments[2] || -1;
		}
		return PT.views.View.prototype.frame.apply(this, arguments);
	}
	return PT.views.View.prototype.frame.call(this);
};

PT.views.TabView.prototype._resetTabIndex = function() {
	if (this.properties.tabIndexBase !== undefined) {
		for (var i = 0; i < this.shownTabbars.length; i++) {
			this.shownTabbars[i].element.attr('tabindex', i + this.properties.tabIndexBase);
		}
	}
}

PT.views.TabView.prototype.forEach = function(callback) {
	this.hiddenTabbars.forEach(function(v,idx){
		callback(v._tabbar,idx,true);
	});

	this.shownTabbars.forEach(function(v,idx){
		callback(v,idx,false);
	});
}

PT.views.TabView.prototype._layoutSubviews = function(forcefully,firstItemAnimated) {
	if (this.properties.direction == 'vertical' || !this.properties.hasMore) {
		this.shownTabbars = this._tabbars.map(function(v) {
			return v._tabbar;
		});
		this._resetTabIndex();
		return;
	}
	if (this._width == -1) {
		this._width = this.element.width();
	}
	var width = this._width - this.children.more.outerWidth(true)
			- this.children.extraButtons.outerWidth(true) - 40;
	if (!forcefully && this._lastWidth == width)
		return;
	this._lastWidth = width;
	var i;
	this.hiddenTabbars = [];
	this.shownTabbars = [];
	this.children.more.detach();
	var cnt = 0;
	for (i = 0; i < this._tabbars.length; i++) {
		var tbar = this._tabbars[i]._tabbar;
		tbar.element.show();
		var right = tbar.element.position().left + tbar.element.width();
		if (right > width) {
			var tbar = this._tabbars[i]._tabbar;
			tbar.hide();
			this.hiddenTabbars.push(this._tabbars[i]);
			cnt++;
		} else {
			this.shownTabbars.push(tbar);
		}
	}
	if (cnt > 0) {
		this.children.tabbars.append(this.children.more);
		this.children.more.html('••• ' + cnt);
	}
	if (firstItemAnimated) {
		var self = this;
		var tab = self._tabbars[0]._tabbar;
		var w = tab.element.width();
		tab.element.width(0).height(0);
		tab.element.animate({
			width : w
		}, {
			duration : 200
		}).animate({
			height : '100%'
		}, {
			duration : 200
		});
	}
	this._resetTabIndex();
};

PT.views.TabView.prototype.addTabBar = function(item, animated, append, noSelection ) {
	this._stopEffectOnSelectedItem();
	PT.js.popup.hide();

	var idx = this._tabbars.indexOf(item);
	if (idx >= 0) {
		if (this._tabbars[idx]._tabbar.element.is(':visible')) {
			this.selectedIndex(idx);
		} else {
			this.unshiftTabBar(item);
		}
		return;
	}
	this.hiddenTabbars = [];
	this.shownTabbars = [];

	var self = this;
	var tbar = new PT.views.TabBarView($('<div/>'), {
		data : item,
		direction : this.properties.direction,
		position : this.properties.position,
		icon : this.properties.tabbar.icon,
		margin : this.properties.tabbar.margin,
		close : this.properties.tabbar.close,
	});
	tbar.element.data('item', item).bind('tabbar.close', function(e) {
		var idx = self._tabbars.indexOf(item);
		$(this).stop(false, true);
		self.removeTabBarAt(idx, self.properties.animated, true);
		return false;
	}).mouseclick(function(e) {
		if ($(e.target).hasClass('close'))
			return;
		e.preventDefault();
		var idx = self._tabbars.indexOf(item);
		self.selectedIndex(idx, true);
		return true;
	}).keypress(function(e) {
		if (e.which == 13) {
			var idx = self._tabbars.indexOf(item);
			self.selectedIndex(idx, true);
		}
	}).bind('tabbar.selected', function(e) {
		var idx = self._tabbars.indexOf(item);
		self.selectedIndex(idx, true);
	});
	if (this.properties.sortable) {
		new PT.views.Drag(tbar.element, {
			verticalEnabled : false,
			copy : true
		});
		tbar.element.bind('dragStart', function(e, p, target) {
			tbar.element.width(tbar.element.width()).height(
					tbar.element.height());
			tbar.element.children().hide();
			target.css({
				display : 'inline-block',
				zIndex : 1
			});
			tbar.element.addClass('dragging');
			return false;
		}).bind('dragging', function(e, ptr, delta, position) {
			var loc = position.left;
			if (delta.left > 0) {
				var pos, t, i;
				var pos = tbar.element.position();
				pos.right = pos.left + tbar.element.width();
				pos.left += tbar.element.width() / 3;
				if (pos.left < loc && loc < pos.right) {
					pos.left = loc + tbar.element.width();
					for (var i = 0; i < self.shownTabbars.length; i++) {
						t = self.shownTabbars[i];
						if (tbar == t)
							continue;
						var p = t.element.position();
						p.right = p.left + t.element.width();
						if (p.left <= pos.left && pos.left <= p.right) {
							tbar.element.insertAfter(t.element);
							break;
						}
					}
				}
			} else if (delta.left < 0) {
				for (var i = 0; i < self.shownTabbars.length; i++) {
					var t = self.shownTabbars[i];
					if (tbar == t)
						continue;
					var pos = t.element.position();
					pos.right = pos.left + t.element.width() / 3 * 2;
					if (pos.left < loc && loc < pos.right) {
						tbar.element.insertBefore(t.element);
						break;
					}
				}
			}
			return false;
		}).bind('dragDone', function(e) {
			tbar.element.children().show();
			tbar.element.removeClass('dragging');
			tbar.element.css({
				width : '',
				height : '',
				zIndex : ''
			});
			self.shownTabbars = self.shownTabbars.sort(function(arg1,
					arg2) {
				return arg1.element.position().left
						- arg2.element.position().left;
			});
			self._resetTabIndex();
			return false;
		});
	}

	if (!append) {
		tbar.element.prependTo(this.children.tabbars);
		this._tabbars.unshift(item);
	} else {
		tbar.element.appendTo(this.children.tabbars);
		this._tabbars.push(item);
	}

	if (this.properties.showContextmenu) {
		tbar.element.bind('tabbar.contextmenu', function(e, x, y) {
			var offset = tbar.offset();
			var pos = {
				left : x + 5 + offset.left,
				top : y + 5 + self.element.offset().top
			};
			self.children.contextmenu.css(pos);
			self.children.contextmenu.data('item', item);
			var idx = self._tabbars.indexOf(item);
			self.children.contextmenu.JSMenuView('allItemsEnabled');
			if (self._tabbars.length == 1) {
				self.children.contextmenu.JSMenuView('itemDisabledAt', [ 1, 3,
						4 ]);
			} else if (idx == 0) {
				self.children.contextmenu.JSMenuView('itemDisabledAt', 3);
			} else if (idx == self._tabbars.length - 1) {
				self.children.contextmenu.JSMenuView('itemDisabledAt', 4);
			}
			PT.js.popup.show(self.children.contextmenu);
			item._tabbar.element.addClass('popup');
		});
	}
	item._tabbar = tbar;
	this._layoutSubviews(true, animated);
	this.children.tabbars.find('.selected').removeClass('selected');
	this.selectedIndex(0);
	this.element.trigger('tabview.added', item);
};

PT.views.TabView.prototype.removeTabBar = function(item, animated) {
	this.removeTabBarAt( this._tabbars.indexOf(item), animated );
};

PT.views.TabView.prototype.removeTabBarsExceptFor = function(itemsExcluded, animated) {
	var self = this;
	itemsExcluded.forEach(function(v) {
		v._tabbar.element.addClass('remain');
	});
	var tlist = self.children.tabbars.find('.tabbar').not('.remain');
	if (animated) {
		var cnt = 0;
		tlist.animate({
			height : 0
		}, {
			duration : 300,
			complete : function() {
				cnt++;
				var item = $(this).data('item');
				self.element.trigger('tabview.close', [ item ]);
				var aIdx = self.activatedTabsInOrder.indexOf(item);
				if (aIdx >= 0) {
					self.activatedTabsInOrder.splice(aIdx, 1);
				}
				$(this).remove();
				delete item._tabbar;
				if (cnt == tlist.length) {
					self._tabbars = itemsExcluded;
					self.selectedIndex(0);
					self.children.tabbars.find('.tabbar').removeClass(
							'remain');
					self._layoutSubviews();
				}
			}
		});
	} else {
		tlist.each(function(idx, v) {
			var item = $(v).data('item');
			self.element.trigger('tabview.close', [ item ]);
			item._tabbar.element.remove();
			var aIdx = self.activatedTabsInOrder.indexOf(item);
			if (aIdx >= 0) {
				self.activatedTabsInOrder.splice(aIdx, 1);
			}
			delete item._tabbar;
		});
		self._tabbars = itemsExcluded;
		self.selectedIndex(0);
		self.children.tabbars.children().removeClass('remain');
		setTimeout(function() {
			self._layoutSubviews();
		}, 0);
	}
	if (this._tabbars.length == 0) {
		this.element.trigger('tabview.closeAll');
	}
};

PT.views.TabView.prototype.removeTabBarAt = function(idx, animated, byClick) {
	PT.js.popup.hide();
	var self = this;
	var item = this._tabbars[idx];
	this._tabbars.splice(idx, 1);
	var aIdx = this.activatedTabsInOrder.indexOf(item);
	if (aIdx >= 0) {
		this.activatedTabsInOrder.splice(aIdx, 1);
	}
	if (this._tabbars.length == 0) {
		this.element.trigger('tabview.closeAll');
		return;
	}
	if (animated) {
		item._tabbar.element.animate({
			height : 0
		}, {
			duration : 200,
			easing : 'pow2In'
		}).animate({
			width : 0
		}, {
			duration : 100,
			easing : 'pow2Out',
			complete : function() {
				self.element.trigger('tabview.close', [ item ]);
				item._tabbar.element.remove();
				delete item._tabbar;
				if (self._selectedIndex == idx) {
					idx = Math.min(idx, self._tabbars.length - 1);
					self.selectedIndex(idx);
				}
				self._layoutSubviews(true);
			}
		});
	} else {
		self.element.trigger('tabview.close', [ item ]);
		item._tabbar.element.remove();
		delete item._tabbar;
		if (this._selectedIndex != idx) {
			if (this._selectedIndex > idx) {
				this._selectedIndex--;
			}
		} else {
			this.selectedIndex(Math.min(idx, this._tabbars.length - 1), byClick);
		}
		self._layoutSubviews(true);
	}
};

PT.views.TabView.prototype.selectedTabbar = function() {
	return this._selectedIndex >= 0 ? this._tabbars[this._selectedIndex] : undefined;
}

PT.views.TabView.prototype.selectedIndex = function(idx, byClick) {
	if (arguments.length) {
		this.children.tabbars.find('.tabbar.selected').removeClass('selected')
				.stop(false, true);
		if (idx < this._tabbars.length) {
			if (idx >= 0) {
				this._selectedIndex = idx;
				var item = this._tabbars[this._selectedIndex];
				item._tabbar.element.addClass('selected');
				var aIdx = this.activatedTabsInOrder.indexOf(item);
				if (aIdx >= 0) {
					this.activatedTabsInOrder.splice(aIdx, 1);
				}
				this.activatedTabsInOrder.unshift(item);
			}
			this.element.trigger('tabview.selectionChanged', [ idx,
					this._tabbars[idx], byClick ]);
		} else {
			this._selectedIndex = -1;
		}
		return;
	}
	return this._selectedIndex;
};

PT.views.TabView.prototype.tabbars = function() {
	return this._tabbars;
};

PT.views.TabView.prototype._showHiddenTabBarList = function() {
	if (this.properties.popover.element.is(":visible"))
		return;
	var self = this;
	if (this.children.hiddenList) {
		this.children.hiddenList.empty();
		delete this.children.hiddenList;
	}
	if (this.properties.moreListview) {
		this.children.hiddenList = this.properties
				.moreListview(this.hiddenTabbars.sort());
		this.children.hiddenList.appendTo($('body'));
	} else {
		this.children.hiddenList = $('<div/>').JSListView({
			plugin : 'detail',
			pluginOptions : {
				style : 'div',
			}
		}).bind('listview.itemClicked', function(e, item, view) {
			PT.js.popup.hide(true);
			self.unshiftTabBar(item, view);
		}).addClass('tabview');
		this.children.hiddenList.JSListView('items', this.hiddenTabbars.sort());
	}
	this.properties.popover.contentView(this.children.hiddenList,
			this.children.more, PT.consts.ArrowDirection.Top);
	this.element.trigger('tabview.showHiddenList');
};

PT.views.TabView.prototype.unshiftTabBar = function(item) {
	this._stopEffectOnSelectedItem();
	var idx = this._tabbars.indexOf(item);
	this._tabbars.splice(idx, 1);
	this.children.tabbars.prepend(item._tabbar.element);
	this._tabbars.unshift(item);
	this._layoutSubviews(true, this.properties.animated);
	this.children.tabbars.find('.selected').removeClass('selected');
	this.selectedIndex(0);
};

PT.views.TabView.prototype._stopEffectOnSelectedItem = function() {
	if (this._selectedIndex == -1 || this._tabbars.length == 0) {
		return;
	}
	var item = this._tabbars[this._selectedIndex]._tabbar.element;
	item.find('.container').stop(false, true);
	item.stop(false, true);
};

PT.views.TabView.prototype.indexOnActivationList = function(item) {
	return this.activatedTabsInOrder.indexOf(item);
}

/******************************************************************************
 * TreeBase
******************************************************************************/

PT.views.TreeBase = function(element, props) {
	if (arguments.length == 0) {
		return;
	}
	PT.views.View.call(this, element, props);
};

PT.views.TreeBase.prototype = new PT.views.View();

PT.views.TreeBase.prototype.data = function(value) {
	if (arguments.length) {
		if (this._tree == value)
			return;
		if (this._tree) {
			this.reset(true);
		}
		if (value instanceof PT.data.Tree) {
			this._tree = value;
		} else {
			this._tree = new PT.data.Tree();
			this._tree.root(value);
		}
		this.draw();
		return;
	}
	return this._tree;
};

PT.views.TreeBase.prototype.isAncestor = function(qItem, item) {
	var p = item.parent;
	while (p) {
		if (p == qItem)
			return true;
		p = p.parent;
	}
	return false;
};

PT.views.TreeBase.prototype.reset = function(notDraw) {
	var self = this;
	this._tree.traverse(function(item) {
		self._clearItem(item);
		delete item._hidden;
	}, PT.consts.TreeTraversalOrder.Post);
	if (!notDraw) {
		this.draw();
	} else {
		this.element.empty();
	}
};

PT.views.TreeBase.prototype.filter = function(cb) {
	var self = this;
	this._tree.traverse(function(item) {
		item._hidden = !cb(item);
	});
	this._tree.traverse(function(item) {
		if (!item._hidden && item._parent) {
			item._parent._hidden = false;
		}
	}, PT.consts.TreeTraversalOrder.Post);
	if (this._filterTimer) {
		clearTimeout(this._filterTimer);
		this._filterTimer = null;
	}
	this._filterTimer = setTimeout(function() {
		self._filterTimer = null;
		self._tree.traverse(function(item) {
			if (!item._treeItem) {
				return;
			}
			if (item._hidden) {
				item._treeItem.hide();
			} else {
				item._treeItem.show();
				if (item._html) {
					item._treeItem.find('.name').html(item._html);
				}
			}
		});
	}, 100);
};

PT.views.TreeBase.prototype._getIcon = function(item, state, hobj) {
	var icon = null;
	if (typeof this.properties.icon == 'function') {
		return this.properties.icon(item, state, hobj);
	} else if ($.isPlainObject(this.properties.icon)) {
		if (hobj)
			hobj.empty();
		icon = hobj ? hobj : $('<div/>').addClass('icon');
		if (item.children) {
			if (this.properties.icon[state].indexOf('.jpg') > 0
					|| this.properties.icon[state].indexOf('.png') > 0) {
				$('<img/>', {
					src : this.properties.icon[state],
					alt : state + ' 아이콘'
				}).appendTo(icon);
			} else {
				icon.html(this.properties.icon[state]);
			}
		} else if (this.properties.icon.leaf) {
			if (this.properties.icon.leaf.indexOf('.jpg') > 0
					|| this.properties.icon.leaf.indexOf('.png') > 0) {
				$('<img/>', {
					src : this.properties.leaf,
					alt : "Leaf 아이콘"
				}).appendTo(icon);
			} else {
				icon.html(this.properties.icon.leaf);
			}
		}
	}
	return icon;
};

/*******************************************************************************
 * TreeView
 ******************************************************************************/

PT.views.TreeView = function(element, props) {
	if (arguments.length == 0)
		return;
	PT.views.TreeBase.call(this, element, $.extend(true, {
		icon : {
			open : '▼',
			close : '►'
		},
		indent : 25,
		openAll : false,
		openSingleLeaf : false,
		checkable : false,
		contentNode : 'div',
		columns : undefined
	// draw additional columns into tree items
	}, props));
	this.element.addClass('tree');
	if (this.properties.data) {
		this.data(this.properties.data);
	}
	if (this.properties.openAll) {
		this.openAll();
	}
};

PT.views.TreeView.prototype = new PT.views.TreeBase();

PT.views.TreeView.prototype.openAll = function() {
	var self = this;
	var os = this.properties.openSingleLeaf;
	this.properties.openSingleLeaf = false;
	this._tree.traverse(function(item) {
		self.open(item, false);
	});
	this.properties.openSingleLeaf = os;
};

PT.views.TreeView.prototype._clearItem = function(item) {
	if (item._treeItem) {
		delete item._html;
		item._treeItem.empty();
		delete item._treeItem;
	}
	if (item._subtree) {
		item._subtree.empty();
		delete item._subtree;
	}
};

PT.views.TreeView.prototype.closeAll = function() {
	var self = this;
	this._tree.traverse(function(item) {
		if (item._treeItem) {
			self.close(item, false);
		}
	});
}

PT.views.TreeView.prototype._openSubItems = function(item) {
	if (!item._treeItem)
		return;
	item._treeItem.show();
	if (item.children && item._treeItem.hasClass('open')) {
		item.children.forEach(function(v) {
			this._openSubItems(v);
		}, this);
	}
};

PT.views.TreeView.prototype.open = function(item, animated) {
	if (item.children == null || item.children.length == 0)
		return;

	if (!item._subtree && !item.children[0]._treeItem) {
		this.draw(item);
	}

	if (this.properties.openSingleLeaf) {
		var cur = item;
		var node = item.parent;
		while (node) {
			var clist = node.children;
			for (var i = 0; i < clist.length; i++) {
				if (clist[i] != cur) {
					this.close(clist[i]);
				}
			}
			cur = node;
			node = node.parent;
		}
	}

	if (!item._treeItem)
		return;
	item._treeItem.addClass('open');
	this._getIcon(item, 'open', item._treeItem.find('.icon:first'));
	if (this.properties.columns) {
		this._openSubItems(item);
	} else if (item._treeItem && item._subtree) {
		item._subtree.show();
		if (animated) {
			var h = item._subtree.height();
			item._subtree.height(0);
			item._subtree.stop();
			item._subtree.animate({
				height : h
			}, {
				duration : 300,
				easing : 'backOut',
				complete : function() {
					item._subtree.css({
						height : ''
					});
				}
			});
		}
	}
};

PT.views.TreeView.prototype.openParents = function(item, animated) {
	item.parents().forEach(function(n) {
		this.open(n, animated);
	}, this);
};

PT.views.TreeView.prototype.close = function(item, animated) {
	if (this.properties.columns) {
		if (item._treeItem.hasClass('open')) {
			item._treeItem.removeClass('open');
			this._tree.traverse(function(pitem) {
				if (pitem == item || !pitem._treeItem)
					return;
				pitem._treeItem.hide();
			}, PT.consts.TreeTraversalOrder.Pre, item);
		}
	} else if (item._subtree
			&& (item._treeItem.hasClass('open') || item._subtree.is(':visible'))) {
		item._treeItem.removeClass('open');
		if (animated) {
			item._subtree.stop();
			item._subtree.animate({
				height : 0
			}, {
				duration : 300,
				easing : 'pow2Out',
				complete : function() {
					item._subtree.css({
						height : ''
					});
					item._subtree.hide();
				}
			});
		} else {
			item._subtree.css({
				height : ''
			});
			item._subtree.hide();
		}
	}
	this._getIcon(item, 'close', item._treeItem.find('.icon:first'));
};

PT.views.TreeView.prototype.toggle = function(item) {
	if (item._treeItem.hasClass('open')) {
		this.close(item, this.properties.animated);
	} else {
		this.open(item, this.properties.animated);
	}
};


PT.views.TreeView.prototype._drawItem = function(item) {
	var self = this;
	var node = $('<div/>').addClass('item').data('item', item);
	var container = $('<div/>').appendTo(node).addClass('content');
	var num = item._depth - this.properties.startDepth;
	if (num) {
		var w = this.properties.indent;
		for (var i = 0; i < num; i++) {
			container.append($('<div/>').addClass('pad').width(w));
		}
	}

	var icon = this._getIcon(item, 'close');
	if (icon) {
		icon.appendTo(container).addClass('icon');
	}
	node.addClass(item.children ? 'node' : 'leaf');
	if (this.properties.checkable) {
		var lbl = $('<label/>').appendTo(container);
		var checkbox = $('<input/>', {
			type : 'checkbox'
		}).appendTo(lbl);
		if (item._checked) {
			checkbox.prop('checked', item._checked);
		}
	}

	var clickfunc = function(e) {
		if (PT.js.dragObject && PT.js.dragObject._isDragging)
			return;
		e.preventDefault();
		e.stopPropagation();
		if (item.children) {
			self.toggle(item);
			if (item._treeItem.hasClass('open')) {
				self.element.trigger('tree.itemOpened', [ item ]);
			} else {
				self.element.trigger('tree.itemClosed', [ item ]);
			}
		} else {
			self.element.trigger('tree.itemClicked', [ item ]);
		}
		return false;
	};
	node.mouseclick(clickfunc);
	$('<a/>', {
		href : "#",
		title : item.name
	}).html(item.name).addClass('name').appendTo(container).keyup(function(e) {
		if (e.which == 13) {
			clickfunc(e);
		}
	}).mouseclick(clickfunc).click(function(e) {
		e.preventDefault();
		return false;
	});
	if (this.properties.columns) {
		node.append(this.properties.columns(item));
	}
	return node;
};

PT.views.TreeView.prototype.draw = function(parentNode) {
	if (arguments.length) {
		if (parentNode.children && parentNode.children.length > 0) {
			var depth = parentNode._depth + 1;
			var cnt = 0;
			var item;
			if (this.properties.columns) {
				for (var i = parentNode.children.length - 1; i >= 0; i--) {
					item = parentNode.children[i];
					item.parent = parentNode;
					if (item._hidden)
						continue;
					var left = this.properties.indent * depth;
					var tItem = this._drawItem(item);
					item._treeItem = tItem;
					tItem.insertAfter(parentNode._treeItem);
					if (cnt == 0) {
						tItem.addClass('last');
					}
					cnt++;
				}
			} else {
				parentNode._subtree = $('<div/>').addClass(
						'subtree depth' + depth);
				for (var i = 0; i < parentNode.children.length; i++) {
					item = parentNode.children[i];
					item.parent = parentNode;
					if (item._hidden)
						continue;
					var left = this.properties.indent * depth;
					// item._depth = depth;
					var tItem = this._drawItem(item);
					item._treeItem = tItem;
					parentNode._subtree.append(tItem);
					cnt++;
				}
				if (item._treeItem) {
					item._treeItem.addClass('last');
				}
				if (!this.properties.columns) {
					if (cnt > 0) {
						parentNode._subtree.insertAfter(parentNode._treeItem);
					} else {
						parentNode._subtree.remove();
						delete parentNode._subtree;
					}
				}
			}
		}
	} else {
		this.element.empty();
		var children = this._tree.children;
		if (children) {
			this.properties.startDepth = children[0]._depth;
			for (var i = 0; i < children.length; i++) {
				var item = children[i];
				if (item._hidden)
					continue;
				item._treeItem = this._drawItem(item);
				this.element.append(item._treeItem);
			}
		}
	}
};


/*******************************************************************************
 * ProgressView
 ******************************************************************************/
PT.views.ProgressBarView = function(element, props) {
	PT.views.View.call(this, element, $.extend({
		minValue : 0,
		maxValue : 1
	}, props));
	this.element.addClass('progressbar');
	this.children.bar = $('<span/>').addClass('bar').appendTo(this.element);
}

PT.views.ProgressBarView.prototype = new PT.views.View();

PT.views.ProgressBarView.prototype.value = function(v) {
	if (arguments.length) {
		this.properties.value = v;
		var p = Math.max(0, Math.min(1, v / (this.properties.maxValue - this.properties.minValue)));
		this.children.bar.width((p * 100) + '%');
		return;
	}
	return this.properties.value;
}


/******************************************************************************
 * PagingScrollView
******************************************************************************/
PT.views.PagingScrollView = function(element, props) {
	PT.views.View.call(this, element, $.extend({
		sortable : false,
		itemSpacing : 20,
		animated : true,
		autoAjdust : true
	}, props));
	this.element.addClass('pagingscroll');

	this._items = [];
	this.children.btnGoBack = this.element.find('.button.back').hide();
	this.children.btnGoNext = this.element.find('.button.next').hide();
	this.children.container = this.element.find('.container');
	if (this.properties.content) {
		this.children.body = $(this.properties.content);
		this.children.body.appendTo(this.children.container);
	} else {
		this.children.body = this.children.container.children().eq(0);
	}

	this.properties.contentWidth = this.children.body.outerWidth();

	var self = this;
	this.children.btnGoBack.click(function(e) {
		e.preventDefault();
		self.goBack();
		return false;
	});

	this.children.btnGoNext.click(function(e) {
		e.preventDefault();
		self.goNext();
		return false;
	});

	if (this.properties.autoAdjust) {
		this.children.body.children().hover(function() {
			self.adjustScroll($(this));
		}, function() {
		}).focus(function(e) {
			self.adjustScroll($(this));
		});
	}
	if (this.properties.sortable) {
		this.children.body.children().each(function(idx, view) {
			self._registerDrag($(view));
		});
	}

	if (this.properties.contentWidth > this.children.container.outerWidth()) {
		this.children.btnGoNext.show();
		this.children.btnGoBack.show();
	} else {
		this.children.btnGoNext.hide();
		this.children.btnGoBack.hide();
	}

	this.children.container.css({
		overflow : 'hidden'
	});

	this.children.container.mousewheel(function(e) {
		if (self._items.length > 0
				&& self.properties.contentWidth > self.children.container
						.outerWidth() + 2) {
			var deltaY = e.deltaY;
			var deltaX = e.deltaX;
			deltaY = isNaN(deltaY) ? 0 : deltaY;
			deltaX = isNaN(deltaX) ? 0 : deltaX;
			var delta = -deltaX || -deltaY;
			self.scroll(self.scroll() + delta * self.children.container.outerWidth() / 3);
			return false;
		}
	});
};

PT.views.PagingScrollView.prototype = new PT.views.View();

PT.views.PagingScrollView.prototype.adjustScroll = function(view, forcefully) {
	if (!this.properties.autoAjdust
			|| this.children.btnGoNext.css('display') == 'none')
		return;
	if (!forcefully) {
		if (this.properties.animating)
			return;
	}
	var off = view.position();
	var w = 0;
	if (this.properties.itemSpacing) {
		w = view.width() + this.properties.itemSpacing;
	} else {
		w = view.outerWidth();
	}
	var scrollX = this.scroll();
	var x = off.left;
	if (scrollX > x) {
		this.scroll(x);
	} else if (x + w >= scrollX + this.children.container.outerWidth()) {
		var p = (x + w - scrollX) % this.children.container.outerWidth();
		this.scroll(scrollX + p);
	}
};

PT.views.PagingScrollView.prototype.layoutSubviews = function() {
	if (this._items.length > 0
			&& this.properties.contentWidth > this.children.container.outerWidth() + 2) {
		this.children.btnGoNext.show();
		this.children.btnGoBack.show();
	} else {
		this.children.btnGoNext.hide();
		this.children.btnGoBack.hide();
	}
};

PT.views.PagingScrollView.prototype._registerDrag = function(view) {
	var self = this;

	new PT.views.Drag(view, {
		verticalEnabled : false,
		copy : true
	});
	view.bind('dragStart', function(e, p, target) {
		view.width(view.width()).height(view.height());
		view.children().hide();
		target.css({
			display : 'inline-block',
			zIndex : 1
		});
		view.addClass('dragging');
		return false;
	}).bind('dragging', function(e, ptr, delta, position) {
		var loc = position.left;
		if (delta.left > 0) {
			var pos, t, i;
			var pos = view.position();
			pos.right = pos.left + view.outerWidth();
			pos.left += view.outerWidth() / 3;
			if (pos.left < loc && loc < pos.right) {
				pos.left = loc + view.width();
				for (i = 0; i < self._items.length; i++) {
					t = self._items[i];
					if (view == t)
						continue;
					var p = t.position();
					p.right = p.left + t.outerWidth();
					if (p.left <= pos.left && pos.left <= p.right) {
						self.adjustScroll(t);
						view.insertAfter(t);
						break;
					}
				}
			}
		} else if (delta.left < 0) {
			for (var i = 0; i < self._items.length; i++) {
				t = self._items[i];
				if (view == t)
					continue;
				var pos = t.position();
				pos.right = pos.left + t.outerWidth() / 3 * 2;
				if (pos.left < loc && loc < pos.right) {
					self.adjustScroll(t);
					view.insertBefore(t);
					break;
				}
			}
		}
		return false;
	}).bind('dragDone', function(e) {
		view.children().show();
		view.removeClass('dragging');
		view.css({
			width : '',
			height : '',
			zIndex : ''
		});
		return false;
	});
};

PT.views.PagingScrollView.prototype.addView = function(view) {
	var self = this;
	this._items.push(view);
	if (this.properties.itemSpacing) {
		view.css({
			marginLeft : this.properties.itemSpacing / 2,
			marginRight : this.properties.itemSpacing / 2
		});
	} else {
		view.css({
			marginLeft : undefined,
			marginRight : undefined
		});
	}
	this.children.body.append(view);
	if (this.properties.autoAdjust) {
		view.hover(function() {
			self.adjustScroll($(this));
		}, null);
	}
	if (this.properties.sortable) {
		this._registerDrag(view);
	}
	this.properties.contentWidth = this.children.body.outerWidth();
	if (this.properties.contentWidth > this.children.container.outerWidth()) {
		this.children.btnGoNext.show();
		this.children.btnGoBack.show();
	}
};

PT.views.PagingScrollView.prototype.measureContentSize = function() {
	this.properties.contentWidth = this.children.body.outerWidth();
	this.layoutSubviews();
}

PT.views.PagingScrollView.prototype.scroll = function(x) {
	if (arguments.length) {
		var self = this;
		x = Math.max(0, Math.min(x, this.properties.contentWidth
				- this.children.container.width()));
		if (this.properties.animated) {
			this.children.body.stop();
			self.properties.animating = true;
			this.children.body.animate({
				marginLeft : -x
			}, {
				duration : 300,
				complete : function(e) {
					self.properties.animating = false;
				}
			});
		} else {
			this.children.body.css('marginLeft', -x);
		}
		return;
	}
	return -parseInt(this.children.body.css('marginLeft').replace('px', ''));
};

PT.views.PagingScrollView.prototype.moveToAtIndex = function(idx) {
	this.adjustScroll(this._items[idx], true);
}

PT.views.PagingScrollView.prototype.goBack = function() {
	var p = -this.children.body.css('marginLeft').replace('px', '');
	this.scroll(p - this.children.container.outerWidth());

};

PT.views.PagingScrollView.prototype.goNext = function() {
	var p = -this.children.body.css('marginLeft').replace('px', '');
	this.scroll(p + this.children.container.outerWidth());
};

PT.views.PagingScrollView.prototype.clear = function() {
	this.children.body.empty();
	this.children.body.css({
		margin : ''
	})
	this._items = [];
	this.children.btnGoNext.hide();
	this.children.btnGoBack.hide();
}

/*******************************************************************************
 * SimpleListView
 ******************************************************************************/
PT.views.SimpleListView = function(element, props) {
	if (props.sortable) {
		// props.draggable = false;
	}
	PT.views.ScrollView.call(this, element, $.extend({
		sortable : false,
		itemSpacing : 20,
		animated : true,
		draggable : true,
		mousewheelStopPropagation : false
	}, props));
	this.element.addClass('simplelistview');
	this._items = [];
	if (this.properties.content) {
		this.children.child = $(this.properties.content);
		this.children.child.prependTo(this.element);
	} else {
		this.children.child = $('<div/>').prependTo(this.element);
	}
};

PT.views.SimpleListView.prototype = new PT.views.ScrollView();

PT.views.SimpleListView.prototype._registerDrag = function(view) {
	var self = this;
	new PT.views.Drag(view, {
		horizontalEnabled : false,
		verticalEnabled : true,
		copy : true
	});
	view.bind('dragStart', function(e, p, target) {
		if (!self.properties.sortable || !self.properties.rearrangeable)
			return;
		view.width(view.width()).height(view.height());
		view.children().hide();
		target.css({
			display : view.css('display') || 'block',
			zIndex : 1,
			width : view.width(),
			border : '0px solid transparent'
		});
		view.addClass('dragging');
		return false;
	}).bind('dragging', function(e, ptr, delta, position) {
		if (!self.properties.sortable || !self.properties.rearrangeable)
			return;
		var loc = position.top;
		if (delta.top > 0) {
			var pos, t, i;
			var pos = view.position();
			pos.bottom = pos.top + view.outerHeight();
			pos.top += view.height() / 3;
			if (pos.top < loc && loc < pos.bottom) {
				pos.top = loc + view.height();
				for (i = 0; i < self._items.length; i++) {
					t = self._items[i];
					if (view == t)
						continue;
					var p = t.position();
					p.bottom = p.top + t.outerHeight();
					if (p.top <= pos.top && pos.top <= p.bottom) {
						view.insertAfter(t);
						break;
					}
				}
			}
		} else if (delta.top < 0) {
			for (var i = 0; i < self._items.length; i++) {
				t = self._items[i];
				if (view == t)
					continue;
				var pos = t.position();
				pos.bottom = pos.top + t.outerHeight() / 3 * 2;
				if (pos.top < loc && loc < pos.bottom) {
					view.insertBefore(t);
					break;
				}
			}
		}
		return false;
	}).bind('dragDone', function(e) {
		if (!self.properties.sortable || !self.properties.rearrangeable)
			return;
		view.children().show();
		view.removeClass('dragging');
		view.css({
			width : '',
			height : '',
			zIndex : ''
		});
		return false;
	});
};

PT.views.SimpleListView.prototype.addView = function(view) {
	var self = this;
	view.addClass('item');
	this._items.push(view);
	this.children.child.append(view);
	if (this.properties.sortable) {
		this._registerDrag(view);
	}
};

PT.views.SimpleListView.prototype.rearrangeable = function(v) {
	if (arguments.length) {
		this.properties.rearrangeable = v;
		if (this._drag) {
			this._drag.properties.enabled = !v;
		}
		return;
	}
	return this.properties.rearrangeable;
}

PT.views.SimpleListView.prototype.emptyConatiner = function() {
	this.children.child.empty();
}

PT.views.SimpleListView.prototype.visablize = function(item) {
	var y = item.position().top;
	if (y <= this._contentOffset.y) {
		this.contentOffset(0, y, true);
	} else if (y >= (this._contentOffset.y + this.element.outerHeight(true))) {
		this.contentOffset(0, this._contentOffset.y + item.outerHeight(true));
	}
}

/*******************************************************************************
 * PageControlView
 ******************************************************************************/

PT.views.PageControlView = function(element, props) {
	PT.views.View.call(this, element, $.extend({
		type : 'circle',
		numPagingUnit : 10,
		icons : {

		}
	}, props));
	this._selectedPage = -1;
	this._totalPages = 0;
	this.element.addClass('pagecontrol ' + this.properties.type);
}

PT.views.PageControlView.prototype = new PT.views.View();

PT.views.PageControlView.prototype.totalPages = function(value) {
	if (arguments.length) {
		if (this._totalPages == value) {
			return;
		}
		this._totalPages = value;
		this.element.empty();
		this.children.pages = [];
		if (this.properties.type == 'circle') {
			var self = this;
			for (var i = 0; i < value; i++) {
				this.children.pages.push($('<div/>').addClass('page').appendTo(
						this.element).click(i, function(e) {
					self.selectedPage(e.data);
					return false;
				}));
			}
		} else {

		}
		this.selectedPage(0);
		return;
	}
	return this._totalPages;
}

PT.views.PageControlView.prototype.selectedPage = function(value) {
	if (arguments.length) {
		if (!this._totalPages || this._selectedPage == value)
			return;
		if (this._selectedPage != -1) {
			this.children.pages[this._selectedPage].removeClass('selected');
		}
		this._selectedPage = value;
		this.element.trigger('pagecontrol.valueChanged', [ value ]);
		this.children.pages[value].addClass('selected');
		return;
	}
	return this._selectedPage;
}

/*******************************************************************************
 * Slideshow
 ******************************************************************************/
PT.views.SlideshowView = function(element, props) {
	PT.views.View.call(this, element, $.extend(true, {
		plugin : 'horizontal',
		items : undefined,
		initSelectedIndex : 0
	}, props));
	this.element.addClass('slideshow');
	this.children.items = [];
	this.children.container = $('<div/>').appendTo(this.element).addClass(
			'container');
	if (typeof this.properties.plugin == 'string') {
		var plugin = PT.views.SlideshowView.plugins[this.properties.plugin] ? this.properties.plugin
				: 'horizontal';
		this.properties.plugin = new PT.views.SlideshowView.plugins[plugin](
				this, this.properties.pluginOptions);
	} else if (this.properties.plugin) {
		this.properties.plugin.init(this, this.properties.pluginOptions);
	}
}

PT.views.SlideshowView.prototype = new PT.views.View();

PT.views.SlideshowView.prototype._layoutSubview = function() {
	this.properties.plugin._reset();
}

PT.views.SlideshowView.prototype.play = function(duration) {
	if (this._interval) {
		clearInterval(this._interval);
	}
	if (this._selectedIndex == -1) {
		this.selectedIndex(0);
	}
	var self = this;
	this._interval = setInterval(function() {
		self.selectedIndex((self._selectedIndex + 1) % self._items.length);
	}, duration || 1000);
}

PT.views.SlideshowView.prototype.stop = function() {
	if (this._interval) {
		this.properties.plugin.stop();
		clearInterval(this._interval);
		this._interval = undefined;
	}
}

PT.views.SlideshowView.prototype._createItemFactory = function(idx) {
	var item = null;
	if (typeof this._items == 'function') {
		return this._items(idx).addClass('item').appendTo(
				this.children.container);
	} else {
		item = this._items[idx];
	}
	if (item == null)
		return null;
	var obj;
	if (this.properties.template) {
		obj = this.drawTemplate(item);
	} else if (typeof this.properties.itemFactory == 'function') {
		obj = this.properties.itemFactory(item, idx);
	} else {
		obj = this._items[idx];
	}
	return obj.addClass('item').appendTo(this.children.container);
}

PT.views.SlideshowView.prototype.items = function() {
	if (arguments.length) {
		this.children.items.forEach(function(v) {
			v.remove();
		});
		this.children.container.empty();
		this._items = arguments[0];
		this._selectedIndex = -1;
		this.selectedIndex(this.properties.initSelectedIndex);
		return;
	}
	return this._items;
}

PT.views.SlideshowView.prototype.itemAt = function(idx) {
	if (typeof this._items == 'function') {
		return this._items(idx);
	} else {
		if (this.properties.rotate) {
			idx = this._rotationIndex(idx);
		}
		return 0 <= idx && idx < this._items.length ? this._items[idx] : null;
	}
}

PT.views.SlideshowView.prototype.canGoForward = function() {
	return this.itemAt(this._selectedIndex + 1) != null;
}

PT.views.SlideshowView.prototype.canGoBack = function() {
	return this.itemAt(this._selectedIndex - 1) != null;
}

PT.views.SlideshowView.prototype.goForward = function() {
	if (this.canGoForward()) {
		this.selectedIndex(this._selectedIndex + 1);
	}
}

PT.views.SlideshowView.prototype.goBack = function() {
	if (this.canGoBack()) {
		this.selectedIndex(this._selectedIndex - 1);
	}
}

PT.views.SlideshowView.prototype._rotationIndex = function(idx, offset) {
	offset = offset || 0;
	if (!Array.isArray(this._items)) {
		return this.properties.item(idx, offset);
	}
	idx += offset;
	if (idx < 0) {
		return this._items.length + idx;
	}
	return idx % this._items.length;
}

PT.views.SlideshowView.prototype.selectedIndex = function(idx, forcefully) {
	if (arguments.length) {
		if (!this._items)
			return;
		if (forcefully) {
			this._selectedIndex = -1;
		}
		idx = this._rotationIndex(idx);

		var dir = 0;
		if (this._selectedIndex != -1) {
			if (this.properties.distance) {
				dir = this.properties.distance(idx, this._selectedIndex);
			} else if (this._selectedIndex == this._items.length - 1
					&& idx == 0) {
				dir = 1;
			} else if (this._selectedIndex == 0
					&& idx == this._items.length - 1) {
				dir = -1;
			} else {
				dir = idx - this._selectedIndex;
			}
		} else {
			dir = 2;
		}

		if (dir == 0)
			return;
		if (Array.isArray(this._items)) {
			if (this._selectedIndex != -1 && this.properties.rotate
					&& Math.abs(dir) == this._items.length - 1) {
				dir = dir > 0 ? -1 : 1;
			}
		}
		if (this._selectedIndex == -1 || Math.abs(dir) > 1) {
			this.children.items.forEach(function(v) {
				v.remove();
			});
			this.children.items[0] = this._createItemFactory(this
					._rotationIndex(idx, -1));
			this.children.items[1] = this._createItemFactory(idx);
			this.children.items[2] = this._createItemFactory(this
					._rotationIndex(idx, 1));
			dir = dir > 0 ? 2 : -2;
		} else if (dir == 1) // forward
		{
			this.children.container.stop(false, true);
			this.children.items[0].remove();
			this.children.items[0] = this.children.items[1];
			this.children.items[1] = this.children.items[2];
			this.children.items[2] = this._createItemFactory(this
					._rotationIndex(idx, 1));
		} else if (dir == -1) // backword
		{
			this.children.container.stop(false, true);
			this.children.items[2].remove();
			this.children.items[2] = this.children.items[1];
			this.children.items[1] = this.children.items[0];
			this.children.items[0] = this._createItemFactory(this._rotationIndex(idx, -1));
		}
		this._selectedIndex = idx;
		if (this._items.length > 1) {
			this.properties.plugin.transition(dir);
		}
		this.element.trigger('slideshow.selectionChanged', [ idx ]);
	}
	return this._selectedIndex;
}


/*******************************************************************************
 * Slideshow plugin horizontal
 ******************************************************************************/
if (!PT.views.SlideshowView.plugins) {
	PT.views.SlideshowView.plugins = {};
}

PT.views.SlideshowView.plugins.horizontal = function(slideshow, props) {
	this.init(slideshow, props);
}

PT.views.SlideshowView.plugins.horizontal.prototype.init = function(slideshow,
		props) {
	this.slideshow = slideshow;
	this.properties = $.extend({

	}, props);
	this.slideshow.element.addClass('horizontal');
}

PT.views.SlideshowView.plugins.horizontal.prototype._goForward = function(
		easing) {
	var w = this.slideshow.element.width();
	var self = this;
	this.slideshow.children.items[1].css({
		zIndex : 0
	});
	this.slideshow.children.items[0].css({
		zIndex : 0
	});
	this.slideshow.children.items[2].css({
		zIndex : 0,
		left : 2 * w
	});

	this.slideshow.children.container.stop(false, true);
	this.slideshow.children.container.animate({
		marginLeft : -w
	}, {
		duration : 500,
		easing : easing || this.properties.easing,
		complete : function(e) {
			self.slideshow.children.container.css({
				marginLeft : 0
			});
			self._reset(1);
		}
	});
}

PT.views.SlideshowView.plugins.horizontal.prototype._goBack = function(easing) {
	var w = this.slideshow.element.width();
	var self = this;
	this.slideshow.children.items[1].css({
		zIndex : 0
	});
	this.slideshow.children.items[2].css({
		zIndex : 0
	});
	this.slideshow.children.items[0].css({
		zIndex : 0,
		left : -2 * w
	});
	this.slideshow.children.container.stop(true, true);
	this.slideshow.children.container.animate({
		marginLeft : w
	}, {
		duration : 500,
		easing : easing || this.properties.easing,
		complete : function(e) {
			self.slideshow.children.container.css({
				marginLeft : 0
			});
			self._reset(-1);
		}
	});
}

PT.views.SlideshowView.plugins.horizontal.prototype.stop = function() {
	this.slideshow.children.container.stop(true, true);
}

PT.views.SlideshowView.plugins.horizontal.prototype._reset = function(dir,
		animated) {
	var w = this.slideshow.element.width();
	this.slideshow.children.items.forEach(function(v, idx) {
		v.css({
			left : w * (idx - 1)
		});
	}, this);
}

PT.views.SlideshowView.plugins.horizontal.prototype.transition = function(dir) {
	switch (dir) {
	case 1:
		this._goForward();
		break;
	case -1:
		this._goBack();
		break;
	default:
		this._reset(dir);
		break;
	}
}

/******************************************************************************
 * External Functions
******************************************************************************/
function nexacro_call(args) {
	PT.utils.nexacro.invoke(args);
}

// 포털에서 넥사크로 함수 호출 객체 파라미터 전달
this.fn_portal2NexaCall = function() {
	document.getElementById("nexaIfm").contentWindow.application
			.application_Call({
				"method" : "getFormSize"
			});
};

// 넥사크로에서 포털에서 제공하는 함수 호출 파라미터 전달
this.fn_nexa2PortalCall = function(objParam) {
	PT.utils.nexacro.portalCall(objParam);
};

// 넥사크로 프레임 사이즈 조절
this.fn_setNexaIfmSize = function(param) {
	PT.utils.nexacro.resize(param);
};

function resizeContentFrameBlock(h, iframe) {
	PT.utils.portal.resizeContentFrameBlock(h, iframe);
};

function notifyMessage(msg) {
	PT.utils.portal.notifyMessage(msg);
};

PT.data.TreeNode = function(props) {
	if (!arguments.length)
		return;
	this.properties = props;
};

Object.defineProperties(PT.data.TreeNode.prototype, {
	name : {
		get : function() {
			return this.properties.name;
		}
	},
	children : {
		get : function() {
			return this._children;
		}
	},
	parent : {
		get : function() {
			return this._parent;
		},
		set : function(v) {
			this._parent = v;
		}
	},
	siblings : {
		get : function() {
			return this._root ? this._root.children : this._parent.childre;
		}
	}
});

PT.data.TreeNode.prototype.parents = function() {
	var queue = [];
	var p = this._parent;
	while (p) {
		queue.unshift(p);
		p = p._parent;
	}
	queue.shift();
	return queue;
}

PT.data.TreeNode.prototype.nodePath = function() {
	var queue = [ this ];
	var p = this.parent;
	while (p) {
		queue.unshift(p);
		p = p._parent;
	}
	return queue;
}


PT.data.TreeNode.prototype.getTop = function() {
	var p = this._parent;
	while (p) {
		if (!p._parent)
			return p;
		p = p._parent;
	}
	return this;
};

PT.data.TreeNode.prototype.graft = function(node) {
	if (this._children) {
		this._children = this._children.concat(menu._children);
	} else {
		this._children = node._children;
	}
	if (this._children) {
		for (var i = 0; i < this._children; i++) {
			this._children[i]._parent = this;
		}
	}
	return this;
};

PT.data.TreeNode.prototype.addNode = function(node) {
	if (!this._children) {
		this._children = [ node ];
	} else {
		this._children.push(node);
	}
	node._parent = this;
	return this;
};

PT.data.TreeNode.prototype.toArray = function(order, mitem) {
	var list = [];
	this.traverse(function(item) {
		list.push(item);
	}, order, mitem);
	return list;
};

PT.data.TreeNode.prototype.traverse = function(cb, order, item, endCallback) {
	var self = this;
	if (item) {
		if (!order) {
			cb(item);
		}
		if (item.children) {
			var children = item.children;

			if (endCallback) {
				(function __eachSerial(idx) {
					if (idx == children.length) {
						endCallback();
					} else {
						setTimeout(
								function() {
									self
											.traverse(
													cb,
													order,
													children[idx],
													function() {
														if (idx == 0
																&& order == PT.consts.TreeTraversalOrder.In) {
															cb(item);
														}
														__eachSerial(idx + 1);
													});
								}, 0);
					}
				})(0);
			} else {
				for (var i = 0; i < children.length; i++) {
					this.traverse(cb, order, children[i]);
					if (i == 0 && order == PT.consts.TreeTraversalOrder.In) {
						cb(item);
					}
				}
			}
			if (order == PT.consts.TreeTraversalOrder.Post) {
				cb(item);
			}
		} else {
			if (order) {
				cb(item);
			}
			if (endCallback) {
				endCallback();
			}
		}
	} else {
		var children = this.children;
		if (children) {
			if (endCallback) {
				(function __eachSerial(idx) {
					if (idx == childeren.length) {
						endCallback();
					} else {
						setTimeout(function() {
							self.traverse(cb, order, children[idx], function() {
								__eachSerial(idx + 1);
							});
						});
					}
				})(0);
			} else {
				for (var i = 0; i < children.length; i++) {
					this.traverse(cb, order, children[i]);
				}
			}
		} else if (endCallback) {
			endCallback();
		}
	}
};

PT.data.TreeNode.prototype.path = function(delimit) {
	delimit = delimit || '/';
	var names = [ this.name ];
	var p = this._parent;
	while (p) {
		names.unshift(p.name);
		p = p._parent;
	}
	return names.join(delimit);
};

PT.data.TreeNode.prototype.toString = function(delimit) {
	return this.name;
};

PT.data.Tree = function(props) {
	if (!arguments.length)
		return;
	PT.data.TreeNode.call(this, props);
	this.properties = props || {};
	this._children = [];
}

PT.data.Tree.prototype = new PT.data.TreeNode();

PT.data.Tree.prototype.init = function() {
	var children = this.children;
	if (children) {
		for (var i = 0; i < children.length; i++) {
			children[i]._root = this;
		}
	}
	this.traverse(function(item) {
		item._depth = item._parent ? item._parent._depth + 1 : 0;
		var children = item.children;
		if (!children || children.length == 0)
			return;
		for (var i = 0; i < children.length; i++) {
			children[i]._parent = item;
		}
	});
};

PT.data.Tree.prototype.root = function(value) {
	if (value instanceof PT.data.TreeNode) {
		this.properties = value.properties;
		this._children = value._children;
	} else if (Array.isArray(value)) {
		this._children = value;
	}
	this.init();
};

PT.data.Menu = function(props) {
	PT.data.Tree.call(this, props);
};

PT.data.Menu.prototype = new PT.data.Tree();

Object.defineProperty(PT.data.Menu.prototype, 'items', {
	get : function() {
		return this._children;
	}
});

PT.data.MenuItem = function(props) {
	PT.data.TreeNode.call(this, props);
};

PT.data.MenuItem.prototype = new PT.data.TreeNode();

PT.data.Size = function(width, height) {
	this.width = width;
	this.height = height;
};

PT.data.Size.prototype.css = function() {
	return {
		width : this.width,
		height : this.height
	};
};

PT.data.Point = function(x, y) {
	if (arguments.length == 1) {
		this.x = arguments[0].x;
		this.y = arguments[0].y;
	} else {
		this.x = x;
		this.y = y;
	}
}

PT.data.Point.prototype.fromAbsRadian = function(r, theta) {
	return new PT.data.Point(r * Math.cos(theta), r * Math.sin(theta));
}

Object.defineProperties(PT.data.Point.prototype, {
	absolute : {
		get : function() {
			return Math.sqrt(this.x * this.x + this.y * this.y);
		}
	},
	left : {
		get : function() {
			return this.x;
		},
		set : function(value) {
			this.x = value;
		}
	},
	top : {
		get : function() {
			return this.y;
		},
		set : function(value) {
			this.y = value;
		}
	}
});

PT.data.Point.prototype.distance = function(ptr) {
	var x, y;
	if (arguments.length == 1) {
		x = arguments[0].x;
		y = arguments[0].y;
	} else {
		x = arguments[0];
		y = arguments[1];
	}
	return Math.sqrt(Math.pow(this.x - x, 2) + Math.pow(this.y - y, 2));
};

PT.data.Point.prototype['+'] = PT.data.Point.prototype.add = function(ptr) {
	return new PT.data.Point(this.x + ptr.x, this.y + ptr.y);
};

PT.data.Point.prototype['-'] = PT.data.Point.prototype.sub = function(ptr) {
	return new PT.data.Point(this.x - ptr.x, this.y - ptr.y);
};

PT.data.Point.prototype['.'] = PT.data.Point.prototype.dotProduct = function(
		ptr) {
	return this.x * ptr.x + this.y * ptr.y;
};

PT.data.Point.prototype.radian = function(ptr) {
	if (arguments.length) {
		return Math.acos(this['.'](ptr) / this.absolute * ptr.absolute);
	}
	return Math.atan2(this.y, this.x);
};

PT.data.Point.prototype.degree = function(ptr) {
	var rad = ptr ? this.radian(ptr) : this.radian();
	return rad * 180 / Math.PI;
};

PT.data.Point.prototype.css = function() {
	return {
		left : this.x,
		top : this.y
	};
};

PT.data.Rectangle = function(x, y, width, height) {
	this.left = x;
	this.top = y;
	this.width = width;
	this.height = height;
};

Object.defineProperties(PT.data.Rectangle.prototype, {
	x : {
		get : function() {
			return this.left;
		},
		set : function(value) {
			this.left = value;
		}
	},
	y : {
		get : function() {
			return this.top
		},
		set : function(value) {
			this.top = value;
		}
	},
	right : {
		get : function() {
			return this.left + this.width;
		},
		set : function(value) {
			this.width = value - this.left;
		}
	},
	bottom : {
		get : function() {
			return this.top + this.height;
		},
		set : function(value) {
			this.height = value - this.top;
		}
	}
});

PT.data.Rectangle.Zero = new PT.data.Rectangle(0, 0, 0, 0);

Object.freeze(PT.data.Rectangle.Zero);

PT.data.Rectangle.prototype.css = function() {
	return {
		left : this.left,
		top : this.top,
		width : this.width,
		height : this.height
	};
};

PT.data.Rectangle.prototype.containsPoint = function(ptr) {
	return (this.left <= ptr.x && ptr.x <= this.right)
			&& (this.top <= ptr.y && ptr.y <= this.bottom);
};

PT.data.Rectangle.prototype.intersect = function(rect) {
	var left, top, right, bottom;
	left = Math.max(this.left, rect.left);
	top = Math.max(this.top, rect.top);
	right = Math.min(this.right, rect.right);
	bottom = Math.min(this.bottom, rect.bottom);
	if (left < right && top < bottom) {
		return new PT.data.Rectangle(left, top, right - left, bottom - top);
	} else {
		return PT.data.Rectangle.Zero;
	}
};

/******************************************************************************
 * Object
******************************************************************************/
Object.extract = function(data) {
	var obj = {};
	if (arguments.length > 1) {
		var list = Array.isArray(arguments[0]) ? arguments[0] : arguments;
		for (var i = 1; i < list.length; i++) {
			var k = list[i];
			obj[k] = data[k];
		}
	}
	return obj;
}

/*******************************************************************************
 * Array
 ******************************************************************************/

if (!Array.prototype.lastElement) {
	Array.prototype.lastElement = function() {
		return this.length > 0 ? this[this.length - 1] : undefined;
	};
};

/*******************************************************************************
 * Date
 ******************************************************************************/
Date.isIntervalValid = function(begin, until) {
	if (!begin && !until)
		return true;
	if (typeof begin == 'string') {
		begin = Date.parseString(begin);
	}
	if (typeof until == 'string') {
		until = Date.parseString(until);
	}
	return begin <= until;
}

Date.prototype.compare = function(v) {
	if (typeof v == 'string')
		v = Date.parseString(v);
	return this - v;
}

Date.prototype.toString = function(fmt) {
	if ( arguments.length ) {
		return fmt.replace(/YYYY/i, this.getFullYear())
		.replace(/YY/i, "%02d".sprintf(this.getFullYear()%100))
		.replace('mm', "%02d".sprintf(this.getMonth()+1))
		.replace('dd', "%02d".sprintf(this.getDate()))
		.replace('HH', "%02d".sprintf(this.getHours()))
		.replace('MM', "%02d".sprintf(this.getMinutes()))
		.replace('ss', "%02d".sprintf(this.getSeconds()))
		.replace('w',  N.message.get(PT.messages, "weeks")[ this.getDay()] );
	}
	return "%04d-%02d-%02d %02d:%02d:%02d".sprintf( this.getFullYear(), this.getMonth() + 1, this.getDate(),
			this.getHours(), this.getMinutes(), this.getSeconds() );
}

if ( !Date.parseString ) {
	Date.parseString = function(v, delimiters) {
		if (!v)
			return undefined;
		delimiters = delimiters || [ '-', ':' ];
		var list = v.split(' ').map(function(v, idx) {
			return v.split(delimiters[idx]);
		});
		if (list.length == 1 && list[0].length == 1) {
			list[0] = [ v.substr(0, 4), v.substr(4, 2), v.substr(6, 2) ];
			if (v.length > 8) {
				list[1] = [ v.substr(8, 2), v.substr(10, 2), v.substr(12, 2) ];
			}
		}
		list[0][1]--;
		return list.length == 1 ? new Date( list[0][0], list[0][1], list[0][2] )
			: new Date( list[0][0], list[0][1], list[0][2], list[1][0], list[1][1], list[1][2]  );
	}
}

/******************************************************************************
 * String
******************************************************************************/
if ( !String.prototype.sprintf ){
	String.prototype.pad = function( chr, count ){
		var p = '';
		for ( var i = 0 ; i < count ; i++ ){
			p += chr;
		}
		return (p + this).slice(-count);
	};

	String.prototype.sprintf = function() {
		var args = Array.prototype.slice.call(arguments,0);
		return this.replace(/%%/g, '%')
			.replace(/%([+\.\-\d]*)([dxXobfs])/g, function(match,opt,type) {
			var v = args.shift();
			switch( type ){
				case 'd':
					v = parseInt(v).toString(10);
					break;
				case 's':
					break;
				case 'x':
					v = parseInt(v).toString(16);
					break;
				case 'X':
					v = parseInt(v).toString(16).toUpperCase();
					break;
				case 'o':
					v = parseInt(v).toString(8);
					break;
				case 'b':
					v = parseInt(v).toString(2);
					break;
				case 'f':
					v = parseFloat(v);
					break;
				default:
					v = null;
					break;
			}
			if ( opt.length ){
				var opt_0 = opt.charAt(0);
				switch(type){
					case 'd':
					case 'x':
					case 'X':
					case 'o':
					case 'b':
						if ( opt_0 === '0' ) {
							v = v.pad('0', parseInt(opt.slice(1)));
						} else {
							v = v.pad(' ', parseInt(opt));
						}
						break;
					case 'f':
						var numdigits = Math.floor(opt);
						var numfloat = Math.round((opt-numdigits)*10);
						if ( Math.floor(v) != v ) numdigits++;
						v = v.toFixed(numfloat);
						if ( v.len < numdigits ) v.pad(' ', numdigits);
						break;
					case 's':
						var align = 1;
						var idx = 0;
						if ( opt_0 == '+' || opt_0 == '-' ){
							align = opt_0 == '+' ? 1 : -1;
							idx++;
						}
						var len = parseInt(opt.slice(idx));
						if ( align == 1 ){
							v = v.pad(' ', len);
						} else {
							v = v.slice(0,len);
							for ( var i = v.length; i < len ; i++ ) {
								v += ' ';
							}
						}
						break;
				}
			}
			return v;
		});
	};
};

if (!String.prototype.format) {
	String.prototype.format = function(type) {
		switch (type) {
		case 'phone': {
			var p = this.replace(/-/g, '');

			if (p.length > 4) {
				var area = '';
				var middle = '';
				var last = p.substr(p.length - 4);
				if (p[0] == '0') {
					if (p[1] == '2') {
						area = p.substr(0, 2);
					} else {
						area = p.substr(0, 3);
					}
				}
				middle = p.substring(area.length, p.length - 4);
				if (area.length > 0)
					area += '-';
				return area + middle + '-' + last;
			}
			return p;
		}
			break;
		}
		return this;
	}
}

/*******************************************************************************
 * Password
 ******************************************************************************/
PT.text.englishToKorean = (function() {
	var en_h = "rRseEfaqQtTdwWczxvg";
	var reg_h = "[" + en_h + "]";

	var en_b = {k:0,o:1,i:2,O:3,j:4,p:5,u:6,P:7,h:8,hk:9,ho:10,hl:11,y:12,n:13,nj:14,np:15,nl:16,b:17,m:18,ml:19,l:20};
	var reg_b = "hk|ho|hl|nj|np|nl|ml|k|o|i|O|j|p|u|P|h|y|n|b|m|l";

	var en_f = {"":0,r:1,R:2,rt:3,s:4,sw:5,sg:6,e:7,f:8,fr:9,fa:10,fq:11,ft:12,fx:13,fv:14,fg:15,a:16,q:17,qt:18,t:19,T:20,d:21,w:22,c:23,z:24,x:25,v:26,g:27};
	var reg_f = "rt|sw|sg|fr|fa|fq|ft|fx|fv|fg|qt|r|R|s|e|f|a|q|t|T|d|w|c|z|x|v|g|";

	var reg_exp = new RegExp("("+reg_h+")("+reg_b+")(("+reg_f+")(?=("+reg_h+")("+reg_b+"))|("+reg_f+"))","g");

	var replace = function(str,h,b,f) {
		return String.fromCharCode(en_h.indexOf(h) * 588 + en_b[b] * 28 + en_f[f] + 44032);
	};

	return (function(str) {
		return str.replace(reg_exp,replace);
	});
})();

PT.text.Password = function(props) {
	this.properties = $.extend( {
		check: {
			length: 8,
			typeOfCharacter: true,
			dictionary: undefined,
			alphaNumericPattern: true,
			keyboardPattern: false
		},
		dictionary: null,
		fields: null
	}, props);

	this._keyboardLayouts = [
		[ "1234567890-=", "qwertyuiop[]\\", "asdfghjkl;'", "zxcvbnm,./" ],
		[ "!@#$%^&*()_+", "QWERTYUIOP{}|", 'ASDFGHJKL:"', "ZXCVBNM<>?" ]
	];
}

PT.text.Password.prototype.compile = function(value) {
	var words = [];
	var lastType = -1;
	var item = '';
	var types = {
		alphaUpper: {
			test: function(v) { return 'A' <= v && v <= 'Z'; },
			type: 1,
			count: 0,
		},
		alphaLower: {
			test: function(v) { return 'a' <= v && v <= 'z'; },
			type: 1,
			count: 0,
		},
		number: {
			test: function(v) { return '0' <= v && v <= '9'; },
			type: 2,
			count: 0,
		},
		special : {
			test: function(v) { return true; },
			type: 3,
			count: 0
		}
	};
	for( var i = 0 ; i < value.length; i++ ) {
		for( var k in types )
		{
			if ( types[k].test(value[i]) )
			{
				types[k].count++;
				if ( lastType != -1 && lastType != types[k].type )
				{
					words.push(item);
					item = '';
				}
				lastType = types[k].type;
				break;
			}
		}
		item += value[i];
	}
	words.push(item);
	this._parsedInfo = {
		words: words,
		count: {
			alphaUpper: types.alphaUpper.count,
			alphaLower: types.alphaLower.count,
			number: types.number.count,
			special: types.special.count
		}
	};
}

PT.text.Password.prototype.test = function(value) {
	this.compile(value);
	for ( var key in this.properties.check) {
		if (!this.properties.check[key])
			continue;
		var fname = '_test' + key[0].toUpperCase() + key.substr(1);
		if (!this[fname](value)) {
			return {
				result : 'fail',
				test : key
			};
		}
	}
	return {
		result : 'success'
	};
}

PT.text.Password.prototype._testLength = function(value) {
	return value.length >= this.properties.check.length;
}

PT.text.Password.prototype._testTypeOfCharacter = function(value) {
	var self = this;
	var numTypes = Object.keys(this._parsedInfo.count).reduce(
			function(acc, key) {
				return acc + (self._parsedInfo.count[key] && 1);
			}, 0, this);
	return numTypes >= 3; //  value.length < 10 ? (numTypes >= 3) : (numTypes >=2);
}

PT.text.Password.prototype._testDictionary = function(value) {
	return true;
}

PT.text.Password.prototype._entropy = function(list) {
	var obj = {};
	for (var i = 0; i < list.length; i++) {
		var v = list[i];
		if (obj[v]) {
			obj[v]++;
		} else {
			obj[v] = 1;
		}
	}
	var keys = Object.keys(obj);
	if (keys.length == 1)
		return 0;
	var denom = Math.log(list.length);
	var sum = 0;
	for ( var k in obj) {
		obj[k] /= list.length;
		sum += -obj[k] * Math.log(obj[k]) / denom;
	}
	return sum;
}

PT.text.Password.prototype._testAlphaNumericPattern = function(value) {
	var words = this._parsedInfo.words;

	var dic = {};
	for (var i = 0; i < words.length; i++) {
		if (dic[words[i]]) {
			dic[words[i]]++;
		} else {
			dic[words[i]] = 1;
		}
	}

	for ( var k in dic) {
		if (dic[k] > 1) {
			return false;
		}
	}
	return true;
}

PT.text.Password.prototype._keyLocation = function(v) {
	var layouts = this._keyboardLayouts;
	for (var k = 0; k < layouts.length; k++) {
		var list = layouts[k];
		for (var r = 0; r < list.length; r++) {
			var c = list[r].indexOf(v);
			if (c != -1) {
				return {
					type : k,
					row : r,
					column : c
				};
			}
		}
	}
	return null;
}

PT.text.Password.prototype._testKeyboardPattern = function(value) {
	var words = this._parsedInfo.words;
	for (var i = 0; i < words.length; i++) {
		var chars = words[i];
		if (chars.length <= 3)
			continue;
		var p, c;
		for (c = 0; c < chars.length; c++) {
			p = this._keyLocation(chars[c]);
			if (p != null)
				break;
		}
		var list = [];
		for (c = 1; c < chars.length; c++) {
			var p1 = this._keyLocation(chars[c]);
			if (p1 && p.type == p1.type && p.row == p1.row) {
				list.push(Math.abs(p.column - p1.column));
				p = p1;
			} else {
				list = null;
				break;
			}
		}
	}
	return true;
}

/*******************************************************************************
 * Calendar
 ******************************************************************************/
PT.views.CalendarView = function(element, props) {
	if (arguments.length == 0)
		return;
	PT.views.View.call(this, element, $.extend({
		weeks : [ '일', '월', '화', '수', '목', '금', '토' ],
		data : undefined
	}, props));
	this.element.addClass('calendar');
}

PT.views.CalendarView.prototype = new PT.views.View();

PT.views.CalendarView.prototype.year = function(v) {
	if (arguments.length) {
		this._selectedDate.setFullYear(v);
		this.date(this._selectedDate);
		return;
	}
	return this._selectedDate.getFullYear();
}

PT.views.CalendarView.prototype.date = function(v) {
	if (arguments.length) {
		var self = this;
		this._selectedDate = v;
		if (typeof this.properties.data == 'function') {
			this.properties.data(function() {
				self.draw();
				self.element.trigger('calendar.valueChanged',
						[ this._selectedDate ]);
			});
		} else {
			this.draw();
			this.element.trigger('calendar.valueChanged',
					[ this._selectedDate ]);
		}
		return;
	}
	return this._selectedDate;
}

PT.views.CalendarView.prototype.goNextMonth = function() {
	this.date(new Date(this._selectedDate.getFullYear(), this._selectedDate.getMonth() + 1));
}

PT.views.CalendarView.prototype.goPreviousMonth = function() {
	this.date(new Date(this._selectedDate.getFullYear(), this._selectedDate.getMonth() - 1));
}

PT.views.CalendarView.prototype.dayRangeOnMonth = function() {
	var begin = new Date(this._selectedDate.getFullYear(), this._selectedDate.getMonth(), 1);
	begin.setDate(-begin.getDay() + 1);

	var end = new Date(this._selectedDate.getFullYear(), this._selectedDate
			.getMonth() + 1, 1);
	end.setDate(1);
	end.setDate(7 - end.getDay());

	return [ begin, end ];
}

PT.views.CalendarView.prototype.refresh = function() {
	if (this.properties.data) {
		var self = this;
		this.properties.data(function() {
			self.draw();
			self.element.trigger('calendar.valueChanged',
					[ this._selectedDate ]);
		});
	} else {
		this.draw();
	}
}

PT.views.CalendarView.prototype.draw = function() {
	var body = this.element.empty();
	var sDate = this._selectedDate;
	var m = sDate.getMonth();

	var date = new Date(sDate.getFullYear(), sDate.getMonth(), 1);
	date.setDate(-date.getDay() + 1);

	var now = new Date();
	if (now.getMonth() != m || now.getFullYear() != sDate.getFullYear()) {
		now = null;
	}

	var self = this;
	var clickEvent = function(e) {
		self.element.trigger('calendar.itemClicked', [ e.data ]);
	}
	var row = $('<div/>').addClass('header title').appendTo(body);
	for (var w = 0; w < 7; w++) {
		$('<div/>').addClass('hcol title').appendTo(row).text(
				this.properties.weeks[w]);
	}
	this.children.days = {};
	for (var w = 0; w < 6; w++) {
		var row = $('<div/>').addClass('row week').appendTo(body);
		for (var c = 0; c < 7; c++) {
			var d = date.getDate();
			var dclone = new Date(date.getFullYear(), date.getMonth(), date
					.getDate());

			var col = $('<div/>').addClass('col date item').appendTo(row);
			var day = $('<div/>').addClass('day').text(d);
			this.children.days[date.toString('YYYYmmdd')] = col;
			if (this.properties.renderer) {
				var dayBox = $('<div/>').addClass('dayContainer').appendTo(col);
				day.appendTo(dayBox);

				if (this.properties.holiday) {
					var tb = this.properties.holiday(dclone, col);
					if (tb) {
						tb.appendTo(dayBox);
					}
				}

				if (this.properties.toolbox) {
					var tb = this.properties.toolbox(dclone, col);
					if (tb) {
						tb.appendTo(dayBox);
					}
				}
				var cbody = this.properties.renderer(dclone, col);
				if (cbody) {
					if (cbody.parent() == null) {
						cbody.appendTo(col);
					}
				}
			} else {
				day.appendTo(col)
			}
			if (date.getMonth() != m) {
				col.addClass('not').addClass(w == 0 ? 'before' : 'next');
				if (w > 0) {
					w = 6;
				}
			} else {
				switch (date.getDay()) {
				case 0:
					col.addClass('sunday');
					break;
				case 6:
					col.addClass('saturday');
					break;
				default:
					break;
				}

				if (now && w < 6 && now.getDate() == date.getDate()) {
					col.addClass('now');
				}
			}
			date.setDate(d + 1);
		}
		if (date.getMonth() != m) {
			break;
		}
	}
}

PT.views.CalendarView.prototype.setIntervalHighlighted = function(begin, until) {
	var cur = new Date(begin.getFullYear(), begin.getMonth(), begin.getDate());
	while (cur <= until) {
		var col = this.children.days[cur.toString('YYYYmmdd')];
		if (col) {
			col.addClass('highlighted');
			col.find('.day').css({
				opacity : 0
			}).animate({
				opacity : 1
			}, {
				duration : 500
			});
		}
		cur.setDate(cur.getDate() + 1);
	}
}

PT.views.CalendarView.prototype.turnOffHighlights = function() {
	this.element.find('.highlighted').removeClass('highlighted');
}

/******************************************************************************
 * ColorPicker
******************************************************************************/
PT.views.ColorPicker = function(element, props) {
	PT.views.View.call(this, element, $.extend({
		size : 200,
	}, props));
	this.element.addClass('colorpicker');
	var h = this.properties.size;
	this.element.height(h);
	this.children.hsvPanel = this.element.find('.hsvPanel').height(h).width(h);
	this.children.hsvPanel.find('img').width(h);
	this.children.huePanel = this.element.find('.huePanel').height(h);
	this.children.hsvIndicator = $('<div/>').addClass('hsv indicator')
			.appendTo(this.children.hsvPanel);
	this.children.hueIndicator = $('<div/>').addClass('hue indicator')
			.appendTo(this.children.huePanel);

	if (this.properties.rgbColor) {
		this.rgb(this.properties.rgbColor);
	} else if (this.properties.hsvColor) {
		this.hsv(this.properties.hsvColor);
	} else {
		this._hsv = {
			h : 0,
			s : 50,
			v : 50
		};
		this.hsv(this._hsv.h, this._hsv.s, this._hsv.v);
	}
	this.registerEvents();
}

PT.views.ColorPicker.prototype = new PT.views.View();

PT.views.ColorPicker.prototype.registerEvents = function() {
	var self = this;
	$('.gradient', this.children.hsvPanel).click(function(e) {
		var h = self._hsv.h;
		var s = e.offsetX / $(this).width() * 100;
		var v = 100 - (e.offsetY / $(this).height() * 100);
		self.properties.animated = true;
		self.hsv(h, s, v);
		self.properties.animated = false;
		return false;
	}).mousedown(function(e) {
		self.isMousePressed = true;
	}).mouseup(function(e) {
		self.isMousePressed = false;
	}).mousemove(function(e) {
		var h = self._hsv.h;
		var s = e.offsetX / $(this).width() * 100;
		var v = 100 - (e.offsetY / $(this).height() * 100);
		if (self.isMousePressed) {
			self.hsv(h, s, v);
			return false;
		} else {
			var rgb = PT.views.ColorPicker.HSVToRGB(h, s, v);
			self.element.trigger('colorpicker.move', [ {
				x : e.offsetX,
				y : e.offsetY
			}, {
				h : h,
				s : s,
				v : v
			}, rgb ]);
		}
	});
	this.element.mouseleave(function(e) {
		self.isMousePressed = false;
	});
	this.children.hsvIndicator.mouseup(function(e) {
		self.isMousePressed = false;
	});
	this.children.huePanel.click(function(e) {
		if (!$(e.toElement).hasClass('huePanel'))
			return;
		var h = e.offsetY / $(this).height() * 360;
		self.properties.animated = true;
		self.hsv(h, self._hsv.s, self._hsv.v);
		self.properties.animated = false;
		return false;
	}).mousedown(function(e) {
		self.isMousePressed = true;
	}).mouseup(function(e) {
		self.isMousePressed = false;
	}).mousemove(function(e) {
		if (!$(e.toElement).hasClass('huePanel'))
			return;
		if (self.isMousePressed) {
			var h = e.offsetY / $(this).height() * 360;
			self.hsv(h, self._hsv.s, self._hsv.v);
		}
		return false;
	});
}

/*
  h : 0 ~ 360
  s : 0 ~ 100
  v : 0 ~ 100
*/
PT.views.ColorPicker.HSVToRGB = function(h, s, v) {
	var r, g, b, i, f, p, q, t;
	h /= 360;
	s /= 100;
	v /= 100;
	i = Math.floor(h * 6);
	f = h * 6 - i;
	p = v * (1 - s);
	q = v * (1 - f * s);
	t = v * (1 - (1 - f) * s);
	switch (i % 6) {
	case 0:
		r = v;
		g = t;
		b = p;
		break;
	case 1:
		r = q;
		g = v;
		b = p;
		break;
	case 2:
		r = p;
		g = v;
		b = t;
		break;
	case 3:
		r = p;
		g = q;
		b = v;
		break;
	case 4:
		r = t;
		g = p;
		b = v;
		break;
	case 5:
		r = v;
		g = p;
		b = q;
		break;
	}
	return {
		r : Math.round(r * 255),
		g : Math.round(g * 255),
		b : Math.round(b * 255)
	};
}

/*
   r,g,b : 0 ~ 255
*/

PT.views.ColorPicker.ColorToRGB = function(value) {
	if (value[0] == '#')
		value = value.substr(1);
	var v = parseInt(value, 16);
	return {
		r : (v >> 16) & 0x0FF,
		g : (v >> 8) & 0x0FF,
		b : v & 0x0FF
	};
}

PT.views.ColorPicker.RGBToHSV = function(r, g, b) {
	var min, max, delta;
	var h, s, v;
	r /= 255;
	g /= 255;
	b /= 255;
	min = Math.min(r, g, b);
	max = Math.max(r, g, b);
	v = max;
	delta = max - min;
	if (max != 0) {
		s = delta / max;
	} else {
		s = 0;
		h = -1;
	}
	if (r == max) {
		h = g == b ? 0 : ((g - b) / delta);
	} else if (g == max) {
		h = 2 + (b - r) / delta;
	} else {
		h = 4 + (r - g) / delta;
	}
	h *= 60;
	if (h < 0) {
		h += 360;
	}
	return {
		h : h,
		s : s * 100,
		v : v * 100
	};
}

PT.views.ColorPicker.prototype.hsv = function(h, s, v) {
	if (arguments.length) {
		var bColor = (100 - v) / 100 * 255;
		bColor = bColor > 70 ? 255 : bColor;
		this.children.hsvIndicator.css({
			borderColor : 'rgb(%d,%d,%d)'.sprintf(bColor, bColor, bColor)
		});
		var r = this.children.hsvIndicator.width() / 2;
		var css = {
			left : s / 100 * this.children.hsvPanel.width() - r,
			top : this.children.hsvPanel.height() - v / 100
					* this.children.hsvPanel.height() - r
		};
		if (this.properties.animated) {
			this.children.hsvIndicator.stop().animate(css, {
				easing : 'pow2In',
				duration : 100
			});
		} else {
			this.children.hsvIndicator.css(css);
		}
		css = {
			top : this.children.huePanel.height() * h / 360
		};
		if (this.properties.animated) {
			this.children.hueIndicator.animate(css, {
				easing : 'pow2In',
				duration : 200
			});
		} else {
			this.children.hueIndicator.css(css);
		}
		this._hsv = {
			h : h,
			s : s,
			v : v
		};
		this._rgb = PT.views.ColorPicker.HSVToRGB(h, s, v);
		var hue = PT.views.ColorPicker.HSVToRGB(h, 100, 100);
		{
			this.children.hsvPanel.css({
				backgroundColor : 'rgb(%d,%d,%d)'.sprintf(hue.r, hue.g, hue.b)
			});
		}
		this.element.trigger('colorpicker.valueChanged',
				[ this._hsv, this._rgb ]);
		return;
	}
	return this._hsv;
}

PT.views.ColorPicker.prototype.rgb = function(r, g, b) {
	if (arguments.length) {
		if (arguments.length == 1) {
			if (typeof r == 'number') {
				var c = r;
				r = (c >> 16) & 0x0FF;
				g = (c >> 8) & 0x0FF;
				b = c & 0x0FF;
			} else {
				g = r.g;
				b = r.b;
				r = r.r;
			}
		}
		var hsv = PT.views.ColorPicker.RGBToHSV(r, g, b);
		this.hsv(hsv.h, hsv.s, hsv.v);
		this._rgb = {
			r : r,
			g : g,
			b : b
		};
		return;
	}
	return this._rgb;
}


/******************************************************************************
 * Portlet
******************************************************************************/
PT.views.PortletAlarmView = function(element, props) {
	if (!arguments.length)
		return;
	if (props) {
		props.badge = parseInt(props.badge);
	}
	PT.views.View.call(this, element, props);
	this.element.addClass('alarm');
}

PT.views.PortletAlarmView.prototype.initialize = function(callback) {
	var self = this;
	this.element.comm(PT.consts.context + "/" + this.properties.linkUrlAddr).submit(function() {
		var cont = $(this).find('.__portletAlarm').instance('cont');
		self.controller = cont;
		if (cont) {
			cont.setPortlet(self);
		}
		callback(self, $(this));
	});
}

PT.views.PortletAlarmEmptyView = function(element, props) {
	PT.views.PortletAlarmView.call(this, element, props);
	this.element.addClass('empty');
	this.children.buttonAdd = $('<div/>').appendTo(this.element).addClass(
			'button add');
}

PT.views.PortletAlarmEmptyView.prototype = new PT.views.PortletAlarmView();

PT.views.PortletAlarmEmptyView.prototype.initialize = function(callback) {

}

PT.views.PortletView = function(element, props) {
	if (arguments.length == 0)
		return;
	PT.views.View.call(this, element, props);
	this.element.addClass('portlet');
	this.target = this.element;
	this._position = {
		x : 0,
		y : 0,
		width : 4 - this.properties.prtletSz.indexOf('1'),
		height : 1
	};
	this.properties.title = this.properties.prtletNm;
	this._drag = new PT.views.Drag(this.element);
	this.element.bind('dragStart', function(e) {
		$(this).css("z-index", 1);
		return false;
	}).bind('dragDone', function(e) {
		$(this).css("z-index", '');
		return false;
	});
	this._availableSizes = [];
	if (!this.properties.prtletExtnPosblSz) {
		this.properties.prtletExtnPosblSz = '1111';
	}
	for (var i = 0; i < 4; i++) {
		if (this.properties.prtletExtnPosblSz[i] == '1') {
			this._availableSizes.push(4 - i);
		}
	}
}

PT.views.PortletView.prototype = new PT.views.View();

PT.views.PortletView.createFactory = function(p) {
	var div = $('<div/>');
	switch (p.prtletSeCode) {
	case 'NCMB0011N00010': // 알림 포트릿
		return new PT.views.PortletAlarmView(div, p)
		break;
	case 'NCMB0011N00020': // 일반 포트릿
		return new PT.views.PortletView(div, p)
		break;
	case 'NCMB0011N00030': // 슬라이드 포트릿
		return new PT.views.PortletSlideShowView(div, p)
		break;
	case 'NCMB0011N00040': // 게시판
		return new PT.views.PortletBoardView(div, p)
		break;
	case 'NCMB0011N00050': // 이미지
		return new PT.views.PortletImageView(div, p)
		break;
	case 'NCMB0011N00060': // 사용자
		return new PT.views.PortletUserView(div, p)
		break;
	case 'empty':
		return new PT.views.PortletEmptyView(div, p);
		break;
	default:
		return new PT.views.PortletView(div, p);
	}
}

PT.views.PortletView.prototype.position = function() {
	if (arguments.length) {
		var w = this._position.width;
		if (arguments[0].width && w != arguments[0].width && this.controller
				&& this.controller.draw) {
			this.controller.draw();
		}
		$.extend(this._position, arguments[0]);
		return;
	}
	return this._position;
}

PT.views.PortletView.prototype.positionIndex = function(numCols) {
	return this._position.x + this._position.y * numCols;
}

PT.views.PortletView.prototype.initialize = function(callback) {
	var self = this;
	this.element.comm(PT.consts.context + "/" + this.properties.linkUrlAddr).submit(
			function() {
				var cont = $(this).find('.__portletController')
						.instance('cont');
				self.controller = cont;
				$(this).find('.__headerViewRegion .__titleView').text(
						self.properties.title);
				if (cont) {
					cont.setPortlet(self);
				}
				callback(self, $(this), cont);
			});
}

PT.views.PortletView.prototype.load = function(callback) {
	if (callback) {
		callback();
	}
}

PT.views.PortletView.prototype.dragEnabled = function(value) {
	this._drag.enabled(value);
}

PT.views.PortletView.prototype.checkResizeable = function(size) {
	return this._availableSizes.indexOf(size) >= 0;
}

PT.views.PortletView.prototype.remove = function() {
	if (this.controller && this.controller.dispose) {
		this.controller.dispose();
	}
	this.element.empty();
	this.status = 'delete';
}

PT.views.PortletEmptyView = function(element, props) {
	PT.views.PortletView.call(this, element, $.extend({
		prtletSz : '0001',
		prtletExtnPosblSz : '0001'
	}, props));
	var self = this;
	this.element.addClass('empty');
	this.children.controller = $('<div/>').addClass('__portletController').appendTo(this.element);
	this.children.buttonAdd = $('<div/>').addClass('button add')
	.appendTo(this.children.controller)
	.click(function(e) {
		self.element.trigger('portlet.add');
	});
}


PT.views.PortletEmptyView.prototype.remove = function() {
	this.element.empty();
}

PT.views.PortletEmptyView.prototype = new PT.views.PortletView();

PT.views.PortletBoardView = function(element, props) {
	PT.views.PortletView.call(this, element, props);
	var match = props.linkUrlAddr.match("bbsId=([^&]+)");
	if (match) {
		this.properties.bbsId = match[1];
	}
}

PT.views.PortletBoardView.prototype = new PT.views.PortletView();

PT.views.PortletImageView = function(element, props) {
	delete props.sysMenuNo;
	PT.views.PortletView.call(this, element, props);
}

PT.views.PortletImageView.prototype = new PT.views.PortletView();

PT.views.PortletImageView.prototype.load = function(callback) {
	var self = this;
	N({
		prtletId : this.properties.prtletId
	}).comm(PT.consts.context + '/pt/PrtletCtr/getPrtletMedia.json').submit(
			function(data) {
				self.media = data;
				callback(data);
			});
}


PT.views.PortletSlideShowView = function(element, props) {
	PT.views.PortletView.call(this, element, props);
}

PT.views.PortletSlideShowView.prototype = new PT.views.PortletView();

PT.views.PortletSlideShowView.prototype.load = function(callback, forSettings) {
	var self = this;
	N({
		_t : '1',
		forSettings : forSettings
	}).comm(PT.consts.context + '/pt/PrtletCtr/getUnivSlideShowList.json')
	.submit(function(data) {
		self.items(data, 4);
		callback(self._groups);
	});
}

PT.views.PortletSlideShowView.prototype.items = function(data, unitW) {
	if (arguments.length) {
		var list = data.map(function(v) {
			return new PT.data.PortletSlideShowItem(v);
		});

		this._items = list.filter(function(v) {
			return v.canBeShown();
		});
		this._items = this._items.concat(list.filter(function(v) {
			return !v.canBeShown();
		}));

		var grp = [];
		this._groups = [ grp ];
		var gIdx = 0;
		var gx = 0;
		for (var i = 0; i < this._items.length; i++) {
			var item = this._items[i];
			if (!item.canBeShown()) {
				item.properties.hidden = true;
				continue;
			}

			item._position.x = gx;
			if (gx + item._position.width > unitW) {
				gx = 0;
				item._position.x = 0;
				var newGrp = [];
				this._groups.push(newGrp);
				grp = newGrp;
			}
			grp.push(item);
			gx += item._position.width;
			item.properties.groupIndex = this._groups.length - 1;
			item.properties.hidden = false;
		}
		return;
	}
	return this._items;
}

PT.views.PortletSlideShowView.prototype.groups = function() {
	return this._groups;
}

PT.data.PortletSlideShowItem = function(props) {
	this.properties = props;
	this._position = {
		x : 0,
		width : 4 - this.properties.slideSz.indexOf('1')
	};
	if (this.properties.slideBeginDt) {
		this.properties.beginDate = new Date(
				parseInt(this.properties.slideBeginDt));
	}
	if (this.properties.slideEndDt) {
		this.properties.untilDate = new Date(
				parseInt(this.properties.slideEndDt));
	}
}

PT.data.PortletSlideShowItem.prototype.canBeShown = function() {
	var now = new Date();
	now.setHours(0, 0, 0, 0);
	return this.properties.useAt == '1'
			&& (!this.properties.beginDate || this.properties.beginDate <= now)
			&& (!this.properties.untilDate || this.properties.untilDate >= now);
}

PT.data.PortletSlideShowItem.prototype.save = function(callback)
{
	var props = {};
	[ "slideBlckId", "prtletId", "slideBcrnId", "slideBeginDt", "slideEndDt", "slideCn", "slideSj", "slideSz",
	 "linkSeCode", "linkInfoCn", "useAt", "fixingAt", "sortOrdr", "nwwnOpenAt" ].forEach(function(k){
		if (this.properties[k]) {
			props[k] = this.properties[k];
		}
	}, this);
	props.rowStatus = this.properties.slideBlckId ? 'update' : 'insert';
	N({'slideshowItems':[props]}).comm(PT.consts.context + "/pt/PrtletCtr/saveSlideShowItems.json").submit(callback);
}

PT.views.PortletUserView = function(element, props) {
	delete props.sysMenuNo;
	PT.views.PortletView.call(this, element, props);
	this.media = {
		mediaId : undefined,
		prtmdCntntsCn : ''
	};
}

PT.views.PortletUserView.prototype = new PT.views.PortletView();

PT.views.PortletUserView.prototype.load = function(callback) {
	if (!this.properties.prtletId) {
		callback(this.media);
		return;
	}
	var self = this;
	N({
		prtletId : this.properties.prtletId
	}).comm(PT.consts.context + '/pt/PrtletCtr/getPrtletMedia.json').submit(
			function(data) {
				self.media = data;
				callback(data);
			});
}

PT.data.Portlet = function(props) {
	this.setProperties(props);
}

PT.data.Portlet.AccessRight = undefined;
PT.data.Portlet.drawAccessRightTable = function(prefix) {
	prefix = prefix || '';
	var table = $('<table/>', {
		cellPadding : 0,
		cellSpacing : 0,
		width : '100%'
	});
	var keys = Object
			.keys(PT.data.Portlet.AccessRight)
			.filter(function(v) {
				return v.indexOf('N0000') == -1;
			})
			.sort(
					function(arg1, arg2) {
						return PT.data.Portlet.AccessRight[arg1] > PT.data.Portlet.AccessRight[arg2] ? 1
								: -1;
					});
	var tr;
	for (var i = 0; i < keys.length; i++) {
		var k = keys[i];
		if (i % 4 == 0) {
			tr = $('<tr/>').appendTo(table);
		}
		var td = $('<td/>').appendTo(tr);
		var chk = $('<input/>', {
			id : prefix + k,
			name : k,
			type : 'checkbox',
		}).appendTo(td);
		var lbl = $('<label/>', {
			'for' : prefix + k
		}).text(PT.data.Portlet.AccessRight[k]).appendTo(td);
	}
	return table;
}

PT.data.Portlet.prototype.setProperties = function(data) {
	var self = this;
	this.properties = $.extend({
		prtletNm : '',
		prtletBassSz : '0001',
		prtletExtnPosblSz : '1111',
		useAt : '1',
		mobileUseAt : '1',
		bcrnUseAt : '1'
	}, data);
	this.properties.prtletSz = this.properties.prtletBassSz || data.prtletSz;
	this.accessRights = data.prscnSclpstSeCodes ? data.prscnSclpstSeCodes
			.split(',') : [];
	for ( var key in PT.data.Portlet.AccessRight) {
		this.properties[key] = '2';
	}
	this.accessRights.forEach(function(v) {
		if (self.properties[v]) {
			self.properties[v] = '1';
		}
	});
	if (this.properties.linkUrlAddr) {
		var match = this.properties.linkUrlAddr.match(/(\w+=[^&]+)+/g);
		if (match) {
			for (var i = 0; i < match.length; i++) {
				var entry = match[i].match(/(\w+)=(.+)/);
				self.properties[entry[1]] = entry[2];
			}
		}
	}
}

PT.data.Portlet.prototype.load = function(view, callback) {
	var self = this;
	N({
		prtletId: this.properties.prtletId,
		prtletSeCode: this.properties.prtletSeCode,
	}).comm(PT.consts.context + '/pt/PrtletCtr/getPrtletInfo.json').submit(function(data){
		if ( data.length == 1 && self.properties.prtletId ) {
			data = data[0];
			self.setProperties(data);

			$('.accessright',view).prop('checked', false);
			var size = $('td[data-property=size]', view);

			if ( data.prtletBassSz == '0000' ) {
				size.text("Small");
			} else {
				var list = [];
				for ( var i = 0 ; i < data.prtletExtnPosblSz.length; i++ ) {
					if( data.prtletExtnPosblSz[i] == 1 ) {
						var txt = "1x%d%s".sprintf( data.prtletExtnPosblSz.length - i, data.prtletBassSz[i] == '1' ? "(기본)" : "" );
						list.unshift(txt);
					}
				}
				size.text( list.join(", ") );
			}
			["useAt", "mobileUseAt", "bcrnUseAt"].forEach(function(v){
				$('td[data-property=' + v + ']',view).text( N.message.get(PT.messages,  data[v] == '1' ? 'yes' : 'no'));
			});
		} else {
			self.items = data.map(function(v){
				return new PT.data.Portlet(v);
			});
		}
		callback(self, data);
	});
}

PT.data.Portlet.prototype.save = function(extraData, callback) {
	var self = this;
	var keys = Object.keys(PT.data.Portlet.AccessRight);
	if (keys.every(function(v) {
		return self.properties[v] == '2';
	})) {
		N(window).alert({
			msg : N.message.get(PT.messages, "portletAccessRightMsg"),
			title : N.message.get(PT.messages, "error")
		}).show();
		return false;
	}
	var self = this;

	var accessRights = keys.filter(function(v) {
		return self.accessRights.indexOf(v) != -1 && self.properties[v] == '2';
	}).map(function(v) {
		return {
			rowStatus : 'delete',
			prtletId : self.properties.prtletId,
			prscnSclpstSeCode : v
		}
	});

	accessRights = accessRights.concat(keys.filter(function(v) {
		return self.accessRights.indexOf(v) == -1 && self.properties[v] == '1';
	}).map(function(v) {
		return {
			rowStatus : 'insert',
			prtletId : self.properties.prtletId,
			prscnSclpstSeCode : v
		}
	}));

	var params = {
		prtletId : this.properties.prtletId,
		prtletNm : this.properties.prtletNm,
		prtletEngNm : this.properties.prtletEngNm,
		prtletSetupCn : this.properties.prtletSetupCn,
		accessright : accessRights,
		useAt : this.properties.useAt,
		mobileUseAt : this.properties.mobileUseAt,
		bcrnUseAt : this.properties.bcrnUseAt,
		menuNo : this.properties.sysMenuNo
	};
	if (!params.prtletId) {
		params.prtletSeCode = this.properties.prtletSeCode;
		params.linkUrlAddr = this.properties.linkUrlAddr;
		params.sysMenuNo = this.properties.sysMenuNo;
		params.prtletExtnPosblSz = this.properties.prtletExtnPosblSz;
		params.prtletBassSz = this.properties.prtletBassSz;
	}
	N($.extend(params, extraData))
	.comm(PT.consts.context + '/pt/PrtletCtr/savePrtletInfo.json')
	.submit(callback);
}


/***********************************************************************************************************/
// Survey
/***********************************************************************************************************/
PT.views.QuestionView = function(element, props) {
	if (arguments.length == 0)
		return;
	PT.views.View.call(this, element, props);
	if (!props.qustnrId) {
		this.properties.rowStatus = 'insert';
	}
	this.element.addClass('surveyitem');
	var numColumns = 1;
	switch (this.properties.answerTyCode) {
	case 'NCMB0005N00010':
		this.numColumns = 2;
		break;
	case 'NCMB0005N00020':
		this.numColumns = 1;
		break;
	case 'NCMB0005N00030':
		this.numRows = 1;
		break;
	case 'NCMB0005N00040':
		this.numRows = 3;
		break;
	case 'NCMB0005N00050':
		this.numRows = 10;
		break;
	}
}

PT.views.QuestionView.prototype = new PT.views.View();

PT.views.QuestionView.prototype.draw = function(tmpl) {
	var self = this;
	var header = $('<div/>').addClass("surveyhead").appendTo(this.element);
	var question = $('<p/>').addClass('question').appendTo(header);
	$('<span/>').addClass('index').text(this.properties.index).appendTo(
			question);
	var desc = this.properties.iemSj;
	if (this.properties.mode == 'report'
			&& this.properties.qustnrIemTyCode == 'NCMB0007N00020') {
		desc += '(다중선택가능)';
	}
	$('<span/>').html(desc).appendTo(question);
	var answers = $('<div/>').addClass('surveyanswers ' + this.properties.mode)
			.appendTo(this.element);
	switch (this.properties.mode) {
	case 'done':
		this.drawInDoneMode(answers);
		break;
	case 'edit':
		this.drawInEditMode(answers);
		break;
	case 'report':
		this.drawInReportMode(answers);
		break;
	case 'progress':
	case 'preview':
	default:
		this.drawInProgressMode(answers);
		break;
	}
}

PT.views.QuestionView.prototype.answer = function() {

}

PT.views.QuestionView.createFactory = function(data) {
	var div = $('<div/>');
	switch (data.qustnrIemTyCode) {
	case 'NCMB0007N00010': // 단일선택형
		return new PT.views.QuestionSingleChoiceView(div, data);
	case 'NCMB0007N00020': // 복수선택형
		return new PT.views.QuestionMultipleChoiceView(div, data);
	case 'NCMB0007N00030': // 기호선택형
		return new PT.views.QuestionOrdinalChoiceView(div, data);
	case 'NCMB0007N00040': // 서술형
		return new PT.views.QuestionOpenEndedView(div, data);
	case 'NCMB0007N00050': // 순서형
		return new PT.views.QuestionRankView(div, data);
	}
	return undefined;
}

PT.views.QuestionMultipleChoiceOptionView = function(element,props) {
	if ( !arguments.length ) return;
	PT.views.View.call(this, element, $.extend({type:'checkbox'},props));
	this.element.addClass('option');
}

PT.views.QuestionMultipleChoiceOptionView.prototype = new PT.views.View();

PT.views.QuestionMultipleChoiceOptionView.isValid = function() {
	return this.formInstance.validate();
}

PT.views.QuestionMultipleChoiceOptionView.prototype.drawInDoneMode = function(idx) {
	$('<span/>').addClass('number').appendTo(this.element).text(idx||this.properties.index);
	$('<span/>').appendTo(this.element).text('.');
	$('<span/>').addClass('text').appendTo(this.element).text(this.properties.answerCn);
}

PT.views.QuestionMultipleChoiceOptionView.prototype.drawInEditMode = function() {
	var self = this;
	var lbl = $('<label/>').appendTo(this.element);
	var chker = $('<input/>',{
		type: this.properties.type == 'select' ? 'text' : this.properties.type,
		name: this.properties.name,
		maxlength: this.properties.type == 'select' ? 2 : undefined
	}).appendTo(lbl);

	lbl = $('<label/>').appendTo(this.element);
	var box = $('<input id="answerCn" class="description" type="text" data-validate=\'[["required"],["maxbyte",2000]]\'/>')
	.data('index', this.properties.index)
	.appendTo(lbl);

	if (this.properties.type == 'select') {
		chker.prop('disabled', true).attr('size', 2).addClass('order');
	}

	if (this.properties.readonly) {
		chker.prop('disabled', true);
		box.prop('disabled', true);
	} else {
		$('<span/>').addClass('ico_del').text('삭제').appendTo(this.element)
		.click(function(e) {
			if (self.properties.answerSn) {
				self.properties.rowStatus = 'delete';
			}
			self.element.trigger('option.removed');
			self.element.remove();
		});
	}
	if (!this.formInstance) {
		this.formInstance = N([]).form(this.element).bind(0, [ this.properties ]);
	}
}

PT.views.QuestionMultipleChoiceOptionView.prototype.drawInProgressMode = function(
		idx, cnt) {
	var self = this;
	var label = $('<label/>').appendTo(this.element);
	var input;

	if (this.properties.type == 'select') {
		input = $('<select/>', {
			name : this.properties.name,
		});
		for (var i = 1; i <= cnt; i++) {
			$('<option/>', {
				value : i
			}).text(i).appendTo(input);
		}
		input.val(idx + 1);
	} else {
		input = $('<input/>', {
			type : this.properties.type,
			name : this.properties.name,
		});
	}

	input.appendTo(label)
	.data({
		index : this.properties.index,
		answerSn : this.properties.answerSn
	})
	.change(function(e) {
		if (!self.parentview.properties.rowStatus) {
			self.parentview.properties.rowStatus = self.parentview.properties.answerAt == '1' ? 'update'
					: 'insert';
		}
	});
	if (this.properties.type == 'select') {
		input.addClass('order');
	}
	$('<span/>').text(this.properties.answerCn).appendTo(label);
}

PT.views.QuestionMultipleChoiceOptionView.prototype.drawInReportMode = function() {
	var dt = $('<dt/>').appendTo(this.element);
	var ans = $('<span/>').addClass('answer').text(this.properties.answerCn).appendTo(dt);
	var barChart = new PT.views.ProgressBarView($('<span/>').appendTo(dt));
	barChart.value(this.properties.percent);
	var dd = $('<dd/>').appendTo(this.element).html("<b>%5.2f%%</b>(%d)".sprintf(this.properties.percent * 100, this.properties.numParticipants));
}

PT.views.QuestionMultipleChoiceOptionView.prototype.isValid = function() {
	if (this.formInstance)
		return this.formInstance.validate();
	return true;
}

PT.views.QuestionMultipleChoiceOptionView.prototype.value = function(v) {
	if (arguments.lenght > 0) {
		this.element.find('input').val(v);
		return;
	}
	return this.element.find('input').val();
}

PT.views.QuestionMultipleChoiceView = function(element, props) {
	if (!arguments.length)
		return;
	PT.views.QuestionView.call(this, element, $.extend({
		type : 'checkbox'
	}, props));
	if (props.answerCns) {
		this.answerSns = {};
		var self = this;
		var name = props.qustnrId + '_' + props.iemSn;
		this.options = props.answerCns
				.split(/\t/)
				.map(function(v, idx) {
					var sidx = v.indexOf(':');
					var item = new PT.views.QuestionMultipleChoiceOptionView(
							$('<li/>'), {
								type : self.properties.type,
								name : name,
								qustnrId : props.qustnrId,
								iemSn : props.iemSn,
								answerCn : v.substr(sidx + 1),
								index : idx + 1
							});
					if (props.mode == 'report') {
						item.properties.numParticipants = v.substr(0,
								sidx);
						if (self instanceof PT.views.QuestionRankView) {
							item.properties.percent = item.properties.numParticipants;
						} else {
							item.properties.percent = props.numSubmits ? item.properties.numParticipants
									/ props.numSubmits
									: 0;
						}
					} else {
						item.properties.answerSn = v.substr(0, sidx);
					}
					item.parentview = self;
					return item;
				});
		this.options.forEach(function(v, idx) {
			self.answerSns[v.properties.answerSn] = idx;
		});
	}
	this.element.addClass('multiplechoice');
}

PT.views.QuestionMultipleChoiceView.prototype = new PT.views.QuestionView();

PT.views.QuestionMultipleChoiceView.prototype.answer = function(values) {
	if (arguments.length) {
		var self = this;
		$('.surveyanswers', this.element).find('input:checked').prop('checked',
				false);
		var inputs = $('.surveyanswers', this.element).find('input');
		values.split(',').forEach(function(v) {
			var idx = self.answerSns[v];
			inputs.eq(idx).prop('checked', true);
		});
		return;
	}
	return $('.surveyanswers', this.element).find('input:checked').map(
			function() {
				return $(this).data('answerSn');
			}).toArray().join(",");
}

PT.views.QuestionMultipleChoiceView.prototype.drawInDoneMode = function(answers) {
	var ul = $('<ol/>').appendTo(answers).addClass(
			'col' + (this.numColumns || 1));
	var self = this;
	var userAnswers = [];
	if (this.properties.choiseAnswerCn) {
		userAnswers = this.properties.choiseAnswerCn.split(',');
	}
	for (var i = 0; i < this.options.length; i++) {
		this.options[i].element.appendTo(ul);
		this.options[i].drawInDoneMode();
	}
	userAnswers.forEach(function(v) {
		var idx = self.answerSns[v];
		self.options[idx].addClass('selected');
	});
	return answers;
}

PT.views.QuestionMultipleChoiceView.prototype.append = function(item) {
	item.element.appendTo(this.container);
	item.drawInEditMode();
}

PT.views.QuestionMultipleChoiceView.prototype.drawInEditMode = function(answers) {
	var self = this;
	if (this.container) {
		this.container.empty();
	} else {
		answers.empty();
		var ul = $('<ul/>').appendTo(answers).addClass(
				'col' + (this.numColumns || 1));
		this.container = ul;
	}
	for (var i = 0; i < this.options.length; i++) {
		if (this.options[i].properties.rowStatus == 'delete')
			continue;
		this.options[i].element.appendTo(this.container);
		this.options[i].drawInEditMode();
	}
}

PT.views.QuestionMultipleChoiceView.prototype.drawInProgressMode = function(
		answers) {
	var qname = 'survey%02d'.sprintf(this.properties.index);
	var self = this;
	var ul = $('<ul/>').appendTo(answers).addClass('col' + this.numColumns);
	for (var i = 0; i < this.options.length; i++) {
		this.options[i].element.appendTo(ul);
		this.options[i].drawInProgressMode(i, this.options.length);
	}
	if (this.properties.choiseAnswerCn) {
		this.answer(this.properties.choiseAnswerCn);
	}
	return answers;
}

PT.views.QuestionMultipleChoiceView.prototype.drawInReportMode = function(
		answers) {
	var ul = $('<ul/>').appendTo(answers).addClass(
			'col' + (this.numColumns || 1));
	for (var i = 0; i < this.options.length; i++) {
		this.options[i].element.appendTo(ul);
		this.options[i].drawInReportMode();
	}
	return answers;
}

PT.views.QuestionRankView = function(element, props) {
	PT.views.QuestionMultipleChoiceView.call(this, element, $.extend(props, {
		type : 'select'
	}));
	if (props.mode == 'report') {
		var sum = this.options.reduce(function(sum, v) {
			return sum + parseInt(v.properties.percent);
		}, 0);
		var idxs = this.options.map(function(v, idx) {
			return idx;
		});
		if (sum > 0) {
			this.options.forEach(function(v, idx) {
				v.properties.percent = 0.5 - v.properties.percent / sum;
			});
		}
		var self = this;
		idxs = idxs.sort(function(a1, a2) {
			return self.options[a2].properties.percent
					- self.options[a1].properties.percent;
		});
		idxs.forEach(function(v, idx) {
			self.options[idx].properties.numParticipants = v + 1;
		});
	}
	this.element.addClass('rank');
}

PT.views.QuestionRankView.prototype = new PT.views.QuestionMultipleChoiceView();

PT.views.QuestionRankView.prototype.answer = function(values) {
	if (arguments.length) {
		var self = this;
		var inputs = $('.surveyanswers', this.element).find('select.order');
		values.split(',').forEach(function(v, idx) {
			inputs.eq(idx).val(v);
		});
		return;
	}
	return $('.surveyanswers', this.element).find('select.order').map(
			function() {
				return $(this).val()
			}).toArray().join(",");
}

PT.views.QuestionRankView.prototype.drawInDoneMode = function(answers) {
	var ul = $('<ol/>').appendTo(answers).addClass(
			'col' + (this.numColumns || 1));
	var self = this;
	var userAnswers = [];
	if (this.properties.choiseAnswerCn) {
		userAnswers = this.properties.choiseAnswerCn.split(',');
	}
	for (var i = 0; i < this.options.length; i++) {
		this.options[i].element.appendTo(ul);
		this.options[i].drawInDoneMode(userAnswers[i]);
	}
	return answers;
}

PT.views.QuestionSingleChoiceView = function(element, props) {
	if (!arguments.length)
		return;
	props.type = "radio";
	PT.views.QuestionMultipleChoiceView.call(this, element, props);
	this.element.removeClass('multiplechoice').addClass('singlechoice');
}

PT.views.QuestionSingleChoiceView.prototype = new PT.views.QuestionMultipleChoiceView();

PT.views.QuestionSingleChoiceView.prototype.answer = function(value) {
	if (arguments.length) {
		var idx = this.answerSns[value];
		$('.surveyanswers', this.element).find('input:checked').prop('checked',
				false);
		$('.surveyanswers', this.element).find('input').eq(idx).prop('checked',
				true);
		return;
	}
	return $('.surveyanswers', this.element).find('input:checked').data(
			'answerSn');
}

PT.views.QuestionOrdinalChoiceView = function(element, props) {
	if (!arguments.length)
		return;
	PT.views.QuestionSingleChoiceView.call(this, element, props);
	this.element.addClass('ordinal');
}

PT.views.QuestionOrdinalChoiceView.prototype = new PT.views.QuestionSingleChoiceView();

PT.views.QuestionOpenEndedView = function(element, props) {
	if (!arguments.length)
		return;
	PT.views.QuestionView.call(this, element, props);
	this.element.addClass('openended');
}

PT.views.QuestionOpenEndedView.prototype = new PT.views.QuestionView();

PT.views.QuestionOpenEndedView.prototype.answer = function(value) {
	if (arguments.length) {
		return;
	}
	return $('.surveyanswers textarea', this.element).val();
}

PT.views.QuestionOpenEndedView.prototype.drawInDoneMode = function(answers) {
	$('<div/>').text(this.properties.dscrpAnswerCn).appendTo(answers);
}

PT.views.QuestionOpenEndedView.prototype.drawInEditMode = function(answers) {
	answers.empty();
	if (this.container)
		delete this.container;
	var lbl = $('<label/>').appendTo(answers);
	$('<textarea/>', {
		rows : this.numRows,
		maxlength : 1000
	}).appendTo(lbl);
}

PT.views.QuestionOpenEndedView.prototype.drawInProgressMode = function(answers) {
	var self = this;
	var lbl = $('<label/>').appendTo(answers);
	var ta = $('<textarea/>', {
		rows : this.numRows
	}).val(this.properties.dscrpAnswerCn || '').appendTo(lbl);

	if (this.properties.mode == 'progress') {
		ta.change(function(e) {
			if (!self.properties.rowStatus) {
				self.properties.rowStatus = self.properties.answerAt == '1' ? 'update'
						: 'insert';
			}
		});
	}
}

PT.views.QuestionOpenEndedView.prototype.drawInReportMode = function(answers) {
	if (this.properties.dscrpAnswerCns) {
		for (var i = 0; i < this.properties.dscrpAnswerCns.length; i++) {
			var txt = this.properties.dscrpAnswerCns[i];
			$('<p/>').text(txt).appendTo(answers);
		}
	} else {
		answers.addClass('empty');
		$('<p/>').text("설문된 내용이 없습니다.").appendTo(answers);
	}
}


PT.views.QuestionEditView = function(element, props) {
	if (!arguments.length)
		return;

	PT.views.QuestionView.call(this, element, $.extend({
		type : 'checkbox'
	}, props));
	this.element.addClass('question');
	this.selQuestionType = $('.questionTypes select', this.element);
	this.selAnswerType = $('.answerTypes select', this.element);
	this.groupName = 'Q_' + Date.now();
	this.formInstance = N([]).form(this.element).bind(0, [ this.properties ]);
	this.questionType(this.properties.qustnrIemTyCode);
	var self = this;

	this.element.find('span.index').click(function(e) {
		self.element.trigger('question.indexClicked', [ self ]);
	});

	if (this.properties.readonly) {
		$('.surveyhead .rightPanel', this.element).hide();
		$('input, textarea', this.element).prop('disabled', true);
		$('.surveyhead .leftPanel .type', this.element).hide();
		$('.surveyhead .leftPanel .options', this.element).hide();
	} else {
		$('.serveyDel a', this.element).click(function(e) {
			e.preventDefault();
			self.remove();
			return false;
		});
		$('.__btnAddOption', this.element).click(function(e) {
			e.preventDefault();
			self.addOption();
			return false;
		});
		$('.tfQuestion', this.element).keypress(function(e) {
			if (e.which == 13) {
				$('.tfOption:visible', self.element).focus();
			}
		})
		$('.tfOption', this.element).keypress(function(e) {
			if (e.which == 13) {
				self.addOption();
			}
		});

		this.selQuestionType.change(function(e) {
			self.questionType($(this).val());
		});
		this.selAnswerType.change(function(e) {
			self.answerType($(this).val());
		});

	}
}

PT.views.QuestionEditView.prototype.valueOf = function() {
	var obj = Object.extract(this.properties, "qustnrIemTyCode",
			"answerTyCode", "iemSj");
	switch (this.properties.qustnrIemTyCode) {
	case 'NCMB0007N00040':
		obj.answerCns = "1:";
		break;
	default:
		var list = this.options.filter(function(v) {
			return v.rowStatus != 'delete';
		});
		obj.answerCns = list.map(function(v, idx) {
			return (v.properties.answerSn || 0) + ":" + v.properties.answerCn
		}).join("\t");
		break;
	}
	return obj;
}

PT.views.QuestionEditView.prototype.isValid = function() {
	if (!this.formInstance.validate())
		return {
			valid : false,
			errcode : "question"
		}
	if (this.properties.qustnrIemTyCode != 'NCMB0007N00040') {
		if (this.options.length < 2)
			return {
				valid : false,
				errcode : 'numoptions'
			}
		return this.options.every(function(v) {
			return v.isValid();
		}) ? {
			valid : true
		} : {
			valid : false,
			errcode : "options"
		}
	}
	return {
		valid : true
	}
}

PT.views.QuestionEditView.questionTypes = [];
PT.views.QuestionEditView.answerChoiceTypes = [];
PT.views.QuestionEditView.answerWriteTypes = [];

PT.views.QuestionEditView.prototype.remove = function() {
	if (this.properties.iemSn) {
		this.properties.rowStatus = 'delete';
	}
	this.element.trigger('question.removed');
	this.element.remove();
}

PT.views.QuestionEditView.prototype.addOption = function() {
	var self = this;
	var type;
	switch (this.selQuestionType.val()) {
	case 'NCMB0007N00050': // 순서형
		type = "text";
		break;
	case 'NCMB0007N00020': // 복수선택형
		type = 'checkbox';
		break;
	case 'NCMB0007N00010': // 단일선택형
	default:
		type = 'radio';
		break;
	}
	var value = $('.tfOption', this.element).val();

	if (value.length == 0) {
		N(window).alert(N.message.get(PT.messages, "surveyOptionMsg")).show();
		return;
	}

	var item = new PT.views.QuestionMultipleChoiceOptionView($('<li/>'), {
		rowStatus : 'insert',
		type : type,
		name : this.groupName,
		readonly : this.properties.readonly,
		qustnrId : this.properties.qustnrId,
		iemSn : this.properties.iemSn,
		answerCn : value
	});
	item.bind('option.removed', function(e) {
		var idx = self.options.indexOf(item);
		self.options.splice(idx, 1);
	});
	this.options.push(item);
	$('.tfOption', this.element).val('');
	PT.views.QuestionMultipleChoiceView.prototype.append.call(this, item);
	PT.utils.portal.resizeContentFrameBlock();
}

PT.views.QuestionEditView.prototype.questionType = function(value) {
	this.selQuestionType.val(value);
	var sel;
	var type;
	switch (value) {
	case 'NCMB0007N00010': // 단일선택형
	case 'NCMB0007N00020': // 복수선택형
	case 'NCMB0007N00030': // 기호선택형
	case 'NCMB0007N00050': // 순서형
		var props = this.properties;
		if (this.options && this.options.length) {
			props.answerCns = this.options.map(function(v) {
				return v.properties.answerSn + ":" + v.properties.answerCn
			}).join("\t");
			this.options.forEach(function(v) {
				v.remove();
			});
			delete this.options;
		}
		switch (value) {
		case 'NCMB0007N00020':
			type = 'checkbox';
			break;
		case 'NCMB0007N00050':
			type = 'select';
			break;
		case 'NCMB0007N00010':
		default:
			type = 'radio';
			break;
		}
		if (props.answerCns) {
			var self = this;
			this.options = props.answerCns
					.split(/\t/)
					.map(function(v, idx) {
						var sidx = v.indexOf(':');
						var item = new PT.views.QuestionMultipleChoiceOptionView(
								$('<li/>'), {
									type : type,
									name : self.groupName,
									readonly : props.readonly,
									qustnrId : props.qustnrId,
									iemSn : props.iemSn,
									answerSn : v.substr(0, sidx),
									answerCn : v.substr(sidx + 1),
									rowStatus : props.rowStatus
								});
						item.parentview = self;
						return item;
					});
		} else {
			this.options = [];
		}
		$('.surveyhead .options', this.element).show();
		sel = N().select($('.answerTypes select', this.element).empty()).bind(
				PT.views.QuestionEditView.answerChoiceTypes);
		if (this.properties.answerTyCode == 'NCMB0005N00010'
				|| this.properties.answerTyCode == 'NCMB0005N00020') {
			sel.val(this.properties.answerTyCode);
		} else {
			sel.val('NCMB0005N00010');
		}
		break;
	case 'NCMB0007N00040': // 서술형
		$('.surveyhead .options', this.element).hide();
		sel = N().select($('.answerTypes select', this.element).empty()).bind(
				PT.views.QuestionEditView.answerWriteTypes);
		if (this.properties.readonly) {
			$('textarea', this.element).prop('disabled', true);
		}
		if (this.properties.answerTyCode == 'NCMB0005N00010'
				|| this.properties.answerTyCode == 'NCMB0005N00020') {
			sel.val('NCMB0005N00030');
		} else {
			sel.val(this.properties.answerTyCode);
		}
		break;
	}
	this.properties.qustnrIemTyCode = value;
	this.draw();
}

PT.views.QuestionEditView.prototype.answerType = function(value) {
	switch (value) {
	case 'NCMB0005N00010':
		this.numColumns = 2;
		this.answerView.children().removeClass('col1').addClass('col2');
		break;
	case 'NCMB0005N00020':
		this.numColumns = 1;
		this.answerView.children().removeClass('col2').addClass('col1');
		break;
	case 'NCMB0005N00030':
		this.numRows = 1;
		this.answerView.children().attr('rows', this.numRows);
		break;
	case 'NCMB0005N00040':
		this.numRows = 3;
		this.answerView.children().attr('rows', this.numRows);
		break;
	case 'NCMB0005N00050':
		this.numRows = 10;
		this.answerView.children().attr('rows', this.numRows);
		break;
	}
	this.properties.answerTyCode = value;
	PT.utils.portal.resizeContentFrameBlock();
}

PT.views.QuestionEditView.prototype.updateIndex = function() {
	$('.surveyhead .index', this.element).text(this.properties.index);
}

PT.views.QuestionEditView.prototype.draw = function() {
	if (!this.answerView) {
		this.answerView = $('<div/>').addClass(
				'surveyanswers ' + this.properties.mode).appendTo(this.element);
	}
	if (this.container) {
		this.container.empty();
	}
	this.updateIndex();
	switch (this.properties.qustnrIemTyCode) {
	case 'NCMB0007N00010': // 단일선택형
	case 'NCMB0007N00020': // 복수선택형
	case 'NCMB0007N00030': // 기호선택형
	case 'NCMB0007N00050': // 순서형
		PT.views.QuestionMultipleChoiceView.prototype.drawInEditMode.call(this,
				this.answerView);
		break;
	case 'NCMB0007N00040': // 서술형
		PT.views.QuestionOpenEndedView.prototype.drawInEditMode.call(this,
				this.answerView);
		break;
	}
}

PT.views.QuestionEditView.prototype.validate = function() {

}

window.requestNextAnimationFrame = (function() {
	var self = this;

	if (window.webkitRequestAnimationFrame) {
		var originalWebkitFunc = window.webkitRequestAnimationFrame;
		window.webkitRequestAnimationFrame = function(callback, element) {
			originalWebkitFunc(function(time) {
				if (time === undefined) {
					time = +new Date();
				}
				callback(time);
			}, element);
		};
	}

	if (window.mozRequestAnimationFrame) {
		var index = navigator.userAgent.indexOf('rv:');
		if (navigator.userAgent.indexOf('Gecko') != -1) {
			var gversion = navigator.userAgent.substr(index + 3, 3);
			if (gversion == '2.0') {
				window.mozRequestAnimationFrame = undefined;
			}
		}
	}

	return window.requestAnimationFrame || window.webkitRequestAnimationFrame
			|| window.mozRequestAnimationFrame
			|| window.msRequestAnimationFrame || function(callback) {
				var start, finish;
				return window.setTimeout(function() {
					start = +new Date();
					callback(start);
					finish = +new Date();
					self.timeout = 1000 / 60 - (finish - start);
				}, self.timeout);
			};
})();


window.cancelRequestAnimationFrame = (function() {
	return window.cancelRequestAnimationFrame || function(handle) {
		clearTimeout(handle);
	};
})();

function Animation(callback) {
	this._callback = callback;
}

Animation.prototype.start = function(cb) {
	var self = this;
	this._stop = false;
	cb = cb || this._callback;
	var animate = function(time) {
		if (!self._stop) {
			cb(time);
			self._timer = window.requestNextAnimationFrame(animate);
		}
	};
	this._timer = window.requestNextAnimationFrame(animate);
}

Animation.prototype.stop = function() {
	if (this._timer) {
		this._stop = true;
		window.cancelRequestAnimationFrame(this._timer);
		delete this._timer;
	}
}

function wipeoutScriptStyle(html) {
	if (!html || html.length == 0)
		return null;
	var obj = $('<div>' + html + '</div>').filter(function() {
		return this.nodeName != 'SCRIPT' && this.nodeName != 'STYLE'
	});
	obj.find('script').remove();
	obj.find('style').remove();
	return N.string.trim(obj.html());
}

PT.utils.editor = {
	isWysiwygareaAvailable : function() {
		// If in development mode, then the wysiwygarea must be available.
		// Split REV into two strings so builder does not replace it :D.
		if (CKEDITOR.revision == ('%RE' + 'V%')) {
			return true;
		}

		return !!CKEDITOR.plugins.get('wysiwygarea');
	},

	createHTMLEditor : function(id) {
		var wysiwygareaAvailable = this.isWysiwygareaAvailable();
		var editorElement = CKEDITOR.document.getById(id);
		// Depending on the wysiwygare plugin availability initialize classic or
		// inline editor.
		if (wysiwygareaAvailable) {
			CKEDITOR.replace(id);
		} else {
			editorElement.setAttribute('contenteditable', 'true');
			CKEDITOR.inline(id);

			// TODO we can consider displaying some info box that
			// without wysiwygarea the classic editor may not work.
		}
		CKEDITOR.on('instanceReady', function(e) {
			e.editor.ready = true;
			if (e.editor._html) {
				e.editor.setData(e.editor._html);
				delete e.editor._html;
			}
		});
		return CKEDITOR.instances[id];
	},

	setEditorContentOnIframe : function(html, parent, callback) {
		html = N.string.trim(html);
		if (html[0] != '<') {
			html = '<p>'
					+ html.replace(/&/g, '&amp;').replace(/>/g, '&gt;')
							.replace(/</g, '&lt;').replace(/\n/g, '<br>')
					+ '</p>';
		}
		var iframe = $('<iframe/>', {
			frameborder : 0,
			width : '100%',
			scrolling : 'no'
		}).css({
			backgroundColor : 'transparent'
		});
		parent.empty().append(iframe);
		var content = iframe.get(0).contentWindow
				|| (iframe.get(0).contentDocument.document || iframe.get(0).contentDocument);
		content.document.open();
		content.document.write('<link rel="stylesheet" href="'
				+ PT.consts.context + '/js/ckeditor/contents.css?_v=1">')
		content.document.write(html);
		content.document.close();

		if (content.document.body) {
			setTimeout(function() {
				iframe.height(content.document.body.scrollHeight + 5);
				if (callback) {
					callback();
				}
			}, 10);
		}
	},

	setHTMLEditorData : function(id, html) {
		if (!CKEDITOR.instances[id])
			return;
		if (html && html[0] != '<') {
			html = '<p>'
					+ html.replace(/&/g, '&amp;').replace(/>/g, '&gt;')
							.replace(/</g, '&lt;').replace(/\n/g, '<br>')
					+ '</p>';
		}
		if (!CKEDITOR.instances[id].ready) {
			CKEDITOR.instances[id]._html = html;
		} else {
			CKEDITOR.instances[id].setData(html);
		}
	},

	getHTMLEditorData : function(id) {
		if (!CKEDITOR.instances[id])
			return '';
		var html = $('<p/>').html(CKEDITOR.instances[id].getData());
		html.find('a').each(function() {
			if (!$(this).attr('target')) {
				$(this).attr('target', '_blank');
			}
		});
		return html.html();
	},

	destroyHTMLEditor : function(id) {
		if (typeof id != 'string') {
			$('.cke', id).each(function() {
				var cId = $(this).attr('id').substr(4);
				if (CKEDITOR.instances[cId]) {
					CKEDITOR.instances[cId].destroy(true);
				}
				$(this).remove();
			});
		} else {
			if (CKEDITOR.instances[id]) {
				CKEDITOR.instances[id].destroy(true);
			}
		}
	}
}

