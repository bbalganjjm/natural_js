URL : http://line6.com/support/topic/22726-best-irs/



Loving the Helix.

 

Created some cab IRs from a Friedman 2x12 (vintage 30s).

Wanted to share them with the community.

http://www.studiocat...an_2x12_cab.zip

 

Three basic mic positions for most of the IRs.

1 = center

2 = edge of cap

3 = cone

 

1o = center off-axis

2o = edge of cap off-axis

3o = cone off-axis

 

Multiple mics were used (SM57, SM7b, MD421, RE20, RE320, C414).

 

The center positions are bright.

If that's not to your liking, make sure to try the other positions.

 

Enjoy!