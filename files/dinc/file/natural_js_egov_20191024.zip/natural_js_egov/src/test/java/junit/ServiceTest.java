package junit;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import framework.naturaljs.app.sample.service.impl.SampleServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"file:src/main/resources/egovframework/spring/context-aspect.xml",
	"file:src/main/resources/egovframework/spring/context-common.xml",
	"file:src/main/resources/egovframework/spring/context-datasource.xml",
	"file:src/main/resources/egovframework/spring/context-mapper.xml",
	"file:src/main/resources/egovframework/spring/context-properties.xml",
	"file:src/main/resources/egovframework/spring/context-transaction.xml"
})
@WebAppConfiguration
@Profile("local")
public class ServiceTest {

	@Resource(name = "sampleService")
	private SampleServiceImpl sampleService;

	@Test
	public void testGetSampleList() {

		Map<String, Object> vo = new HashMap<>();

		List<Map<String, Object>> list = sampleService.getSampleList(vo);

		System.out.println(list);
	}

}