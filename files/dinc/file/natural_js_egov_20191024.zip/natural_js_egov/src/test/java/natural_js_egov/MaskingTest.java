package natural_js_egov;

import org.junit.Test;

import framework.utils.MaskingUtils;

public class MaskingTest {

	@Test
	public void test() {
		System.out.println("============성명");
		System.out.println(MaskingUtils.maskString("name", "홍철"));
		System.out.println(MaskingUtils.maskString("name", "홍길동"));
		System.out.println(MaskingUtils.maskString("name", "김박순희"));
		System.out.println(MaskingUtils.maskString("name", "Jeff Beck"));
		System.out.println(MaskingUtils.maskString("name", "J. H. Bill"));
		System.out.println("============주민등록번호");
		System.out.println(MaskingUtils.maskString("rrn", "123456-1234567"));
		System.out.println(MaskingUtils.maskString("rrn", "1234561234567"));
		System.out.println("============외국인등록번호");
		System.out.println(MaskingUtils.maskString("frn", "123456-1234567"));
		System.out.println(MaskingUtils.maskString("frn", "1234561234567"));
		System.out.println("============여권번호");
		System.out.println(MaskingUtils.maskString("pn", "A11111111"));
		System.out.println("============운전면허번호");
		System.out.println(MaskingUtils.maskString("dln", "서울 11-11111-11"));
		System.out.println(MaskingUtils.maskString("dln", "서울 111111111"));
		System.out.println("============전화번호");
		System.out.println(MaskingUtils.maskString("phone", "02-1111-1111"));
		System.out.println(MaskingUtils.maskString("phone", "0211111111"));
		System.out.println(MaskingUtils.maskString("phone", "032-1111-1111"));
		System.out.println(MaskingUtils.maskString("phone", "03211111111"));
		System.out.println(MaskingUtils.maskString("phone", "02-111-1111"));
		System.out.println(MaskingUtils.maskString("phone", "021111111"));
		System.out.println(MaskingUtils.maskString("phone", "032-111-1111"));
		System.out.println(MaskingUtils.maskString("phone", "0321111111"));
		System.out.println("============휴대폰번호");
		System.out.println(MaskingUtils.maskString("phone", "010-1111-1111"));
		System.out.println(MaskingUtils.maskString("phone", "01011111111"));
		System.out.println("============이메일");
		System.out.println(MaskingUtils.maskString("email", "abcdefg@abc.com"));
		System.out.println(MaskingUtils.maskString("email", "abefg@abc.com"));
		System.out.println(MaskingUtils.maskString("email", "efg@abc.com"));
		System.out.println(MaskingUtils.maskString("email", "fg@abc.com"));
		System.out.println(MaskingUtils.maskString("email", "g@abc.com"));
		System.out.println("============카드");
		System.out.println(MaskingUtils.maskString("card", "1111-1111-1111-1111"));
		System.out.println(MaskingUtils.maskString("card", "1111111111111111"));
		System.out.println("============계좌번호");
		System.out.println(MaskingUtils.maskString("an", "111-111-1111"));
		System.out.println(MaskingUtils.maskString("an", "1111111111"));
		System.out.println("============주소");
		System.out.println(MaskingUtils.maskString("address", "서울시 종로구 관철동 삼일빌딩 123-22 6층"));
		System.out.println(MaskingUtils.maskString("address", "서울시 노원구 공릉로 322 세이브존"));
		System.out.println("============인터넷주소");
		System.out.println(MaskingUtils.maskString("ip", "123.123.123.123"));
		System.out.println(MaskingUtils.maskString("ip", "123123123123"));
	}

}
