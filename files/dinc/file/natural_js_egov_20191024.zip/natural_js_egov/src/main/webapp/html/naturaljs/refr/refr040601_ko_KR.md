개요
===

Select(N.select) 는 select, input[type=checkbox], input[type=radio] 요소에 데이터를 바인딩 하여 선택요소를 만들어 주고 해당 컨트롤의 기능을 확장 해 주는 UI 컴포넌트입니다.