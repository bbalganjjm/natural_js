Overview
===

Notify(N.notify) is a UI component that displays a global notification message in a specified location that does not require user confirmation.

<p class="alert">Alert (N.alert) is for handling messages in the content area and N.notify is for handling messages throughout the site. Therefore, N.alert's component elements are created inside each View element and N.notify is created in the document.body element.</p>