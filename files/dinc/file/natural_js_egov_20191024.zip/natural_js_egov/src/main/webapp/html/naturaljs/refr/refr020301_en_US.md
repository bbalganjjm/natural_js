Overview
===

Communicator(N.comm) is a class that implements Communicator layer of ​​CVC Architecture Pattern.

![](images/intr/pic4.png)
<center>[ Natural-ARCHITECTURE ]</center>

N.comm is a library that supports Ajax communication with the server, such as requesting content or data from the server, or passing parameters.