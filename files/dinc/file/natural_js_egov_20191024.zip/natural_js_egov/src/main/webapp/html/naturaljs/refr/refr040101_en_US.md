Overview
===

Alert(N.alert) is a UI component that displays message dialogs such as window.alert or window.confirm in the form of layer popups.
<p class="alert">If the Alert dialog box is not displayed and an error occurs, you must specify the element where N.alert-related elements will be stored as a jQuery selector string in the N.context.attr("ui").alert.container property of <a href="#cmVmcjAxMDIlMjRDb25maWckaHRtbCUyRm5hdHVyYWxqcyUyRnJlZnIlMkZyZWZyMDEwMi5odG1s">Config(N.config)</a>.</p>