개요
===

Button(N.button) 은 context 옵션으로 지정된 "a, input[type=button], button" 요소를 사용하여 버튼을 만드는 UI 컴포넌트 입니다.

<p class="alert">버튼의 기본 스타일을 CSS 로 별도로 정의 하고 버튼의 기능(disable, enable 등)만 따로 사용 가능 합니다.</p>