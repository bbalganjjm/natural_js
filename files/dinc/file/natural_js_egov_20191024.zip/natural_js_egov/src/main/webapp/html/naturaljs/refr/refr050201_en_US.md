Overview
===

Documents(N.docs) is a page container that displays Natural-JS based menu pages in MDI(Multi Document Interface) or SDI(Single Document Interface) structure.

<p class="alert">You can specify options such as the maximum number of tabs and the maximum number of states and you can also display loading indicators for N.comm's requests and responses.</a>