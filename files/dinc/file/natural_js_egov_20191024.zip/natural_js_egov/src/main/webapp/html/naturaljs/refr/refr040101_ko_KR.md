개요
===

Alert(N.alert) 은 window.alert 이나 window.confirm 같은 메시지 대화상자를 레이어 팝업 형태로 표현 해 주는 UI 컴포넌트 입니다.
<p class="alert">Alert 대화 상자가 표시 되지 않고 오류가 발생 하면 <a href="#cmVmcjAxMDIlMjRDb25maWckaHRtbCUyRm5hdHVyYWxqcyUyRnJlZnIlMkZyZWZyMDEwMi5odG1s">Config(N.config)</a> 의 N.context.attr("ui").alert.container 속성에 jQuery selector 문자열로 N.alert 관련 요소들이 저장 될 요소를 지정 해야 합니다.</p>