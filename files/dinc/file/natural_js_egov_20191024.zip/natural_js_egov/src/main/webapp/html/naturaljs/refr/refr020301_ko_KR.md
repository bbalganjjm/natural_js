개요
===

Communicator(N.comm) 는 CVC Architecture Pattern 의 Communicator 레이어를 구현한 클래스 입니다.

![](images/intr/pic4.png)
<center>[ Natural-ARCHITECTURE ]</center>

N.comm 은 서버에 컨텐츠나 데이터를 요청하거나 파라미터를 전달 하는 등 서버와의 Ajax 통신을 지원하는 라이브러리 입니다.