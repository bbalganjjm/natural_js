Overview
===

N() is a Natural-JS core method. Return a collection of matched elements either found in the DOM based on passed argument(s) or created by passing an HTML string.

N is an object class that defines the core functions of Natural-JS.

<p class="alert">N() is an object that extends the jQuery() function. So you can use it by replacing it with $() or jQuery(). However, local functions of N objects cannot be used in jQuery or $ objects.</p>