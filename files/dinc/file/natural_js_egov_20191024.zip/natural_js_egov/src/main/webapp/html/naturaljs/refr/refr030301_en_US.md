Overview
===

The Natural-DATA library provides methods and functions for sorting, filtering, and refining data of type array[json object].