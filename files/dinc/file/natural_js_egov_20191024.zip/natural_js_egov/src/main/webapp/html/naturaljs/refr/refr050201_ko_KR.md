개요
===

Documents (N.docs)는 Natural-JS 기반의 메뉴 페이지를 MDI (Multi Document Interface) 또는 SDI (Single Document Interface) 구조로 표시하는 페이지 컨테이너입니다.

<p class="alert">최대 페이지 수 및 최대 상태 유지 페이지 수와 같은 옵션을 지정할 수 있으며 N.comm 의 요청 및 응답에 대한 로딩 인디케이터를 표시 할 수도 있습니다.</a>