Overview
===

Pagination(N.pagination) is a UI component that creates paging indexes from list data or the total count of rows.

<p class="alert">The context element of N.pagination consists of div> ul> li> a elements.</p> 
<p class="alert">With the N.pagination component, you can write parameters for SQL paging or page the entire list data of type array[json object].</p>
