개요
===

Notify(N.notify) 는 사용자의 확인 과정이 필요없는 전역 알림 메시지를 지정 한 위치에 표시 해주는 UI 컴포넌트 입니다.

<p class="alert">Alert(N.alert) 은 컨텐츠 영역의 메시지를 처리하는 용도이고 N.notify는 사이트 전역의 메시지를 처리 하는 용도 입니다. 때문에 N.alert 의 컴포넌트 요소는 각각의 View 요소 안에 생성 되고 N.notify 는 document.body 요소에 생성 됩니다.</p>