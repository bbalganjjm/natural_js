Overview
===

Formatter(N.formatter) is a library that formats the input data set(array [json object]) and returns the formatted data set.

<p class="alert">If you enter an element that wraps the elements in which the format rules are declared with the data-format attribute instead of the rule set, display a formatted string on an element. 
In this case, if the element is an element that inputs text, it displays the string of the original data when the cursor is focused, and the formatted string when the focus is out.</p>
<p class="alert">You can also format in strings, not in datasets.</p>