Overview
===

Validator(N.validator) is a library that validates the input data set(array [json object]) and returns a validation result data set.
<p class="alert">If you enter an element as an argument that wraps the input element where the validation rule is declared with the data-validate attribute instead of the rule set, When the cursor of an input element is focused out, the value entered in that element is validated and if validation fails, an error message is displayed in the form of a tooltip near the input element.</p>
<p class="alert">You can also validate by string, not by dataset.</p>


