Overview
===

Button(N.button) is a UI component that creates a button with a "a, input[type=button], button" element specified as a context option.

<p class="alert">You can define the basic style of the button separately in CSS and use only the button's functions (disable, enable, etc.)</p>