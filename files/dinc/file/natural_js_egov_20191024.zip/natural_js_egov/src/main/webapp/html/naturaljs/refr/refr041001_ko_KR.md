개요
===

Pagination(N.pagination) 은 목록 데이터나 전체 행 수로 페이징 인덱스를 생성 해 주는 UI 컴포넌트입니다.

<p class="alert">N.pagination 의 context 요소는 div>ul>li>a 요소들로 구성 됩니다.</p> 
<p class="alert">N.pagination 컴포넌트로 SQL 페이징에 대한 파라미터를 생성하거나 array[json object] 유형의 전체 목록 데이터를 페이징 할 수 있습니다.</p>
