(function(window, N) {

    var CommonPublishController = {

    };

    if (!window.APP) {
        window.APP = {};
    }
    window.APP.commpub = CommonPublishController;

})(window, N);