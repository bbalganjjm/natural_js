Overview
===

Tree(N.tree) is a UI component that makes hierarchical data into tree elements.

<p class="alert">You can append a checkbox to a node to make group selections.</p>